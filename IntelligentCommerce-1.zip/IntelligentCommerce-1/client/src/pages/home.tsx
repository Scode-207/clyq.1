import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trackPageView, trackChatInteraction } from "@/lib/tracking";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import ConversationArea from "@/components/chat/conversation-area";
import WelcomeWidget from "@/components/chat/welcome-widget";

type ActiveSection = 'chat' | 'marketplace';

export default function Home() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [activeSection, setActiveSection] = useState<ActiveSection>('chat');
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);

  // Create new conversation mutation
  const createConversationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/conversations", {});
      return await response.json();
    },
    onSuccess: (conversation) => {
      setCurrentConversationId(conversation.id);
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
  });

  // Auto-create conversation when user accesses home for the first time
  useEffect(() => {
    if (user && !currentConversationId && !createConversationMutation.isPending) {
      createConversationMutation.mutate();
    }
  }, [user, currentConversationId, createConversationMutation]);

  // Track page view when home loads
  useEffect(() => {
    if (user) {
      trackPageView('Home Page', '/');
    }
  }, [user]);

  const handleSectionChange = (section: ActiveSection) => {
    if (section === 'marketplace') {
      // Navigate to dedicated marketplace page
      navigate('/marketplace');
      return;
    }
    
    setActiveSection(section);
  };

  return (
    <div className="flex h-screen bg-[#0A0A0A] text-white overflow-hidden">
      {/* Sidebar with hover expansion */}
      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={handleSectionChange}
      />
      
      {/* Main Content Area */}
      <div className="flex-1 h-full flex overflow-hidden relative">
        <ConversationArea 
          conversationId={currentConversationId}
          domain={undefined}
        />
        
        {/* Welcome Widget */}
        <WelcomeWidget />
      </div>
    </div>
  );
}
