import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { Loader2, MapPin, Utensils, ShoppingBag, Plane, ChevronRight, ChevronLeft, Check } from "lucide-react";

export default function OnboardingPage() {
  const { user, updateProfileMutation } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;

  // Form state
  const [location, setLocation] = useState({
    city: "",
    state: "",
    country: "",
  });

  const [foodPreferences, setFoodPreferences] = useState({
    cuisine: [] as string[],
    dietary: [] as string[],
    spicePreference: "medium" as "mild" | "medium" | "spicy",
  });

  const [shoppingPreferences, setShoppingPreferences] = useState({
    budgetRange: [50, 500] as number[],
    sustainabilityImportance: 3,
    favoriteCategories: [] as string[],
    shoppingFrequency: "monthly" as string,
  });

  const [travelPreferences, setTravelPreferences] = useState({
    travelStyle: [] as string[],
    accommodationType: [] as string[],
    budgetPreference: "mid-range" as string,
  });

  // Redirect if not logged in
  if (!user) {
    return <Redirect to="/auth" />;
  }

  // Redirect if profile is already complete
  if (user.profileComplete) {
    return <Redirect to="/" />;
  }

  const cuisineOptions = [
    "Italian", "Chinese", "Japanese", "Mexican", "Indian", "Thai", "Mediterranean", 
    "American", "French", "Korean", "Vietnamese", "Middle Eastern"
  ];

  const dietaryOptions = [
    "Vegetarian", "Vegan", "Gluten-Free", "Dairy-Free", "Keto", "Low-Carb", 
    "Halal", "Kosher", "Nut-Free", "No restrictions"
  ];

  const shoppingCategories = [
    "Electronics", "Fashion", "Home & Garden", "Books", "Sports & Outdoors", 
    "Beauty", "Automotive", "Toys & Games", "Health", "Art & Crafts"
  ];

  const travelStyleOptions = [
    "Adventure", "Relaxation", "Cultural", "Business", "Family", 
    "Solo", "Romantic", "Backpacking", "Luxury", "Eco-friendly"
  ];

  const accommodationOptions = [
    "Hotels", "Vacation Rentals", "Hostels", "Bed & Breakfast", 
    "Boutique Hotels", "Resorts", "Camping", "Apartments"
  ];

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = async () => {
    const profileData = {
      location,
      preferences: {
        // Food preferences
        cuisine: foodPreferences.cuisine,
        dietary: foodPreferences.dietary,
        spicePreference: foodPreferences.spicePreference,
        
        // Shopping preferences
        budgetRange: { min: shoppingPreferences.budgetRange[0], max: shoppingPreferences.budgetRange[1] },
        sustainabilityImportance: shoppingPreferences.sustainabilityImportance,
        favoriteCategories: shoppingPreferences.favoriteCategories,
        shoppingFrequency: shoppingPreferences.shoppingFrequency,
        
        // Travel preferences
        travelStyle: travelPreferences.travelStyle,
        accommodationType: travelPreferences.accommodationType,
        budgetPreference: travelPreferences.budgetPreference,
        
        // Notification preferences
        notifications: {
          email: true,
          push: true,
          marketing: false,
        },
      },
      profileComplete: true,
    };

    updateProfileMutation.mutate(profileData);
  };

  const toggleArrayItem = (array: string[], item: string, setter: (arr: string[]) => void) => {
    if (array.includes(item)) {
      setter(array.filter(i => i !== item));
    } else {
      setter([...array, item]);
    }
  };

  const progress = (currentStep / totalSteps) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A0A0A] via-[#1A1A1A] to-[#0D0D0D] flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            Welcome, {user.firstName}!
          </h1>
          <p className="text-gray-400 mb-6">
            Let's personalize your AI shopping experience
          </p>
          <Progress value={progress} className="w-full h-2 bg-gray-800" />
          <p className="text-sm text-gray-500 mt-2">
            Step {currentStep} of {totalSteps}
          </p>
        </div>

        <Card className="border-gray-800 bg-gray-900/50 backdrop-blur-sm">
          <CardContent className="p-8">
            
            {/* Step 1: Location */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div className="text-center space-y-2">
                  <MapPin className="w-12 h-12 text-electric-blue mx-auto" />
                  <CardTitle className="text-white">Where are you located?</CardTitle>
                  <p className="text-gray-400">
                    This helps us find local restaurants and relevant products
                  </p>
                </div>

                <div className="grid gap-4">
                  <div>
                    <Label htmlFor="city" className="text-gray-300">City</Label>
                    <Input
                      id="city"
                      placeholder="New York"
                      value={location.city}
                      onChange={(e) => setLocation({...location, city: e.target.value})}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="state" className="text-gray-300">State/Province</Label>
                      <Input
                        id="state"
                        placeholder="NY"
                        value={location.state}
                        onChange={(e) => setLocation({...location, state: e.target.value})}
                        className="bg-gray-800 border-gray-700 text-white"
                      />
                    </div>

                    <div>
                      <Label htmlFor="country" className="text-gray-300">Country</Label>
                      <Input
                        id="country"
                        placeholder="United States"
                        value={location.country}
                        onChange={(e) => setLocation({...location, country: e.target.value})}
                        className="bg-gray-800 border-gray-700 text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Food Preferences */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div className="text-center space-y-2">
                  <Utensils className="w-12 h-12 text-electric-blue mx-auto" />
                  <CardTitle className="text-white">Food Preferences</CardTitle>
                  <p className="text-gray-400">
                    Tell us about your culinary preferences
                  </p>
                </div>

                <div className="space-y-6">
                  <div>
                    <Label className="text-gray-300 text-lg">Favorite Cuisines</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {cuisineOptions.map(cuisine => (
                        <Badge
                          key={cuisine}
                          variant={foodPreferences.cuisine.includes(cuisine) ? "default" : "outline"}
                          className={`cursor-pointer transition-colors ${
                            foodPreferences.cuisine.includes(cuisine) 
                              ? "bg-electric-blue text-white" 
                              : "border-gray-600 text-gray-300 hover:bg-gray-800"
                          }`}
                          onClick={() => toggleArrayItem(
                            foodPreferences.cuisine, 
                            cuisine, 
                            (arr) => setFoodPreferences({...foodPreferences, cuisine: arr})
                          )}
                        >
                          {cuisine}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300 text-lg">Dietary Restrictions</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {dietaryOptions.map(diet => (
                        <Badge
                          key={diet}
                          variant={foodPreferences.dietary.includes(diet) ? "default" : "outline"}
                          className={`cursor-pointer transition-colors ${
                            foodPreferences.dietary.includes(diet) 
                              ? "bg-electric-blue text-white" 
                              : "border-gray-600 text-gray-300 hover:bg-gray-800"
                          }`}
                          onClick={() => toggleArrayItem(
                            foodPreferences.dietary, 
                            diet, 
                            (arr) => setFoodPreferences({...foodPreferences, dietary: arr})
                          )}
                        >
                          {diet}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300 text-lg">Spice Preference</Label>
                    <RadioGroup 
                      value={foodPreferences.spicePreference} 
                      onValueChange={(value) => setFoodPreferences({
                        ...foodPreferences, 
                        spicePreference: value as "mild" | "medium" | "spicy"
                      })}
                      className="mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="mild" id="mild" />
                        <Label htmlFor="mild" className="text-gray-300">Mild</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="medium" id="medium" />
                        <Label htmlFor="medium" className="text-gray-300">Medium</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="spicy" id="spicy" />
                        <Label htmlFor="spicy" className="text-gray-300">Spicy</Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Shopping Preferences */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div className="text-center space-y-2">
                  <ShoppingBag className="w-12 h-12 text-electric-blue mx-auto" />
                  <CardTitle className="text-white">Shopping Preferences</CardTitle>
                  <p className="text-gray-400">
                    Help us curate the perfect products for you
                  </p>
                </div>

                <div className="space-y-6">
                  <div>
                    <Label className="text-gray-300 text-lg">Budget Range</Label>
                    <div className="mt-4 space-y-2">
                      <Slider
                        value={shoppingPreferences.budgetRange}
                        onValueChange={(value) => setShoppingPreferences({
                          ...shoppingPreferences, 
                          budgetRange: value
                        })}
                        min={10}
                        max={1000}
                        step={10}
                        className="w-full"
                      />
                      <div className="flex justify-between text-sm text-gray-400">
                        <span>${shoppingPreferences.budgetRange[0]}</span>
                        <span>${shoppingPreferences.budgetRange[1]}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300 text-lg">Favorite Categories</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {shoppingCategories.map(category => (
                        <Badge
                          key={category}
                          variant={shoppingPreferences.favoriteCategories.includes(category) ? "default" : "outline"}
                          className={`cursor-pointer transition-colors ${
                            shoppingPreferences.favoriteCategories.includes(category) 
                              ? "bg-electric-blue text-white" 
                              : "border-gray-600 text-gray-300 hover:bg-gray-800"
                          }`}
                          onClick={() => toggleArrayItem(
                            shoppingPreferences.favoriteCategories, 
                            category, 
                            (arr) => setShoppingPreferences({...shoppingPreferences, favoriteCategories: arr})
                          )}
                        >
                          {category}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300 text-lg">
                      Sustainability Importance: {shoppingPreferences.sustainabilityImportance}/5
                    </Label>
                    <Slider
                      value={[shoppingPreferences.sustainabilityImportance]}
                      onValueChange={(value) => setShoppingPreferences({
                        ...shoppingPreferences, 
                        sustainabilityImportance: value[0]
                      })}
                      min={1}
                      max={5}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Travel Preferences */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div className="text-center space-y-2">
                  <Plane className="w-12 h-12 text-electric-blue mx-auto" />
                  <CardTitle className="text-white">Travel Preferences</CardTitle>
                  <p className="text-gray-400">
                    Let us plan your perfect getaways
                  </p>
                </div>

                <div className="space-y-6">
                  <div>
                    <Label className="text-gray-300 text-lg">Travel Style</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {travelStyleOptions.map(style => (
                        <Badge
                          key={style}
                          variant={travelPreferences.travelStyle.includes(style) ? "default" : "outline"}
                          className={`cursor-pointer transition-colors ${
                            travelPreferences.travelStyle.includes(style) 
                              ? "bg-electric-blue text-white" 
                              : "border-gray-600 text-gray-300 hover:bg-gray-800"
                          }`}
                          onClick={() => toggleArrayItem(
                            travelPreferences.travelStyle, 
                            style, 
                            (arr) => setTravelPreferences({...travelPreferences, travelStyle: arr})
                          )}
                        >
                          {style}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300 text-lg">Accommodation Type</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {accommodationOptions.map(type => (
                        <Badge
                          key={type}
                          variant={travelPreferences.accommodationType.includes(type) ? "default" : "outline"}
                          className={`cursor-pointer transition-colors ${
                            travelPreferences.accommodationType.includes(type) 
                              ? "bg-electric-blue text-white" 
                              : "border-gray-600 text-gray-300 hover:bg-gray-800"
                          }`}
                          onClick={() => toggleArrayItem(
                            travelPreferences.accommodationType, 
                            type, 
                            (arr) => setTravelPreferences({...travelPreferences, accommodationType: arr})
                          )}
                        >
                          {type}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300 text-lg">Budget Preference</Label>
                    <RadioGroup 
                      value={travelPreferences.budgetPreference} 
                      onValueChange={(value) => setTravelPreferences({
                        ...travelPreferences, 
                        budgetPreference: value
                      })}
                      className="mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="budget" id="budget" />
                        <Label htmlFor="budget" className="text-gray-300">Budget-friendly</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="mid-range" id="mid-range" />
                        <Label htmlFor="mid-range" className="text-gray-300">Mid-range</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="luxury" id="luxury" />
                        <Label htmlFor="luxury" className="text-gray-300">Luxury</Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t border-gray-700">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 1}
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>

              {currentStep === totalSteps ? (
                <Button
                  onClick={handleComplete}
                  disabled={updateProfileMutation.isPending}
                  className="bg-electric-blue hover:bg-electric-blue/80"
                >
                  {updateProfileMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Completing Setup...
                    </>
                  ) : (
                    <>
                      Complete Setup
                      <Check className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              ) : (
                <Button
                  onClick={handleNext}
                  className="bg-electric-blue hover:bg-electric-blue/80"
                >
                  Next
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}