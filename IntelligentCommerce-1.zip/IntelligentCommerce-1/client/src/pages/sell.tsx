import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { 
  ArrowLeft, 
  Camera, 
  Upload, 
  Wand2, 
  Sparkles, 
  DollarSign, 
  Package, 
  Globe, 
  Eye, 
  TrendingUp, 
  Target, 
  Users, 
  ShoppingBag, 
  Tag, 
  MapPin, 
  Calendar, 
  Clock, 
  Star, 
  MessageSquare, 
  Shield, 
  Zap, 
  Brain, 
  CheckCircle, 
  AlertTriangle,
  CreditCard,
  Info,
  Plus,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ImageWithFallback from "@/components/image-with-fallback";

export default function SellPage() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [isAiAnalyzing, setIsAiAnalyzing] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<any>(null);
  const [showCreditDialog, setShowCreditDialog] = useState(false);
  const [credits, setCredits] = useState(10);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    subcategory: '',
    condition: '',
    price: '',
    originalPrice: '',
    brand: '',
    model: '',
    size: '',
    color: '',
    location: '',
    shipping: false,
    negotiable: false,
    tags: [] as string[],
    listingType: 'sell' as 'sell' | 'buy_request' | 'trade' | 'group_buy'
  });

  const categories = {
    'Electronics': ['Smartphones', 'Laptops', 'Cameras', 'Gaming', 'Audio', 'Accessories'],
    'Fashion': ['Clothing', 'Shoes', 'Accessories', 'Jewelry', 'Bags', 'Watches'],
    'Home & Garden': ['Furniture', 'Appliances', 'Decor', 'Tools', 'Kitchen', 'Outdoor'],
    'Sports & Outdoors': ['Fitness', 'Cycling', 'Team Sports', 'Water Sports', 'Winter Sports'],
    'Automotive': ['Cars', 'Motorcycles', 'Parts', 'Accessories', 'Tools'],
    'Books & Media': ['Books', 'Movies', 'Music', 'Games', 'Collectibles']
  };

  const conditions = [
    { value: 'like_new', label: 'Like New', description: 'Excellent condition, barely used' },
    { value: 'good', label: 'Good', description: 'Minor signs of wear, fully functional' },
    { value: 'fair', label: 'Fair', description: 'Noticeable wear but works well' },
    { value: 'needs_repair', label: 'Needs Repair', description: 'Has issues that need fixing' }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const newImages = Array.from(files).map(file => URL.createObjectURL(file));
      setUploadedImages(prev => [...prev, ...newImages].slice(0, 8));
    }
  };

  const analyzeWithAI = async () => {
    setIsAiAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      setAiSuggestions({
        suggestedTitle: `${formData.brand} ${formData.model} ${formData.category} - Excellent Condition`,
        suggestedPrice: {
          recommended: 1250,
          range: { min: 1100, max: 1400 },
          reasoning: "Based on current market analysis and similar listings"
        },
        suggestedTags: ['premium', 'authentic', 'fast-shipping', 'negotiable'],
        marketInsights: {
          demand: 'High',
          competition: 'Medium',
          bestTimeToSell: 'Now - Peak demand period',
          priceOptimization: 'Price is competitive, consider highlighting unique features'
        },
        optimizedDescription: `Premium ${formData.brand} ${formData.model} in ${formData.condition} condition. This highly sought-after item features exceptional build quality and performance. Perfect for professionals and enthusiasts alike. Includes original packaging and accessories. Ships same day with tracking.`,
        seoKeywords: ['premium', 'authentic', 'professional', 'fast shipping'],
        visibility: {
          score: 92,
          improvements: ['Add more specific keywords', 'Include detailed measurements', 'Highlight unique features']
        }
      });
      setIsAiAnalyzing(false);
    }, 2000);
  };

  const applySuggestion = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return !!(formData.title && formData.category && formData.subcategory && formData.condition && formData.description);
      case 2:
        return uploadedImages.length > 0;
      case 3:
        return !!(formData.price && parseFloat(formData.price) > 0);
      case 4:
        return true; // AI step is optional
      case 5:
        return true; // Preview step
      default:
        return false;
    }
  };

  const getStepRequirements = () => {
    switch (currentStep) {
      case 1:
        const missing1 = [];
        if (!formData.title) missing1.push('Product Title');
        if (!formData.category) missing1.push('Category');
        if (!formData.subcategory) missing1.push('Subcategory');
        if (!formData.condition) missing1.push('Condition');
        if (!formData.description) missing1.push('Description');
        return missing1;
      case 2:
        return uploadedImages.length === 0 ? ['At least 1 product image'] : [];
      case 3:
        const missing3 = [];
        if (!formData.price) missing3.push('Price');
        if (formData.price && parseFloat(formData.price) <= 0) missing3.push('Valid price greater than $0');
        return missing3;
      default:
        return [];
    }
  };

  const steps = [
    { id: 1, title: 'Product Details', icon: Package },
    { id: 2, title: 'Images & Media', icon: Camera },
    { id: 3, title: 'Pricing & Terms', icon: DollarSign },
    { id: 4, title: 'AI Optimization', icon: Sparkles },
    { id: 5, title: 'Preview & Publish', icon: Eye }
  ];

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title" className="text-white mb-2 block">Product Title *</Label>
                  <Input
                    id="title"
                    placeholder="e.g., iPhone 14 Pro Max 256GB Space Black"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white mb-2 block">Category *</Label>
                    <Select 
                      value={formData.category} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, category: value, subcategory: '' }))}
                    >
                      <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.keys(categories).map(cat => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-white mb-2 block">Subcategory *</Label>
                    <Select 
                      value={formData.subcategory} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, subcategory: value }))}
                      disabled={!formData.category}
                    >
                      <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                        <SelectValue placeholder="Select subcategory" />
                      </SelectTrigger>
                      <SelectContent>
                        {formData.category && categories[formData.category as keyof typeof categories]?.map(sub => (
                          <SelectItem key={sub} value={sub}>{sub}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label className="text-white mb-2 block">Brand</Label>
                    <Input
                      placeholder="Apple, Samsung, etc."
                      value={formData.brand}
                      onChange={(e) => setFormData(prev => ({ ...prev, brand: e.target.value }))}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-white mb-2 block">Model</Label>
                    <Input
                      placeholder="iPhone 14 Pro"
                      value={formData.model}
                      onChange={(e) => setFormData(prev => ({ ...prev, model: e.target.value }))}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-white mb-2 block">Color</Label>
                    <Input
                      placeholder="Space Black"
                      value={formData.color}
                      onChange={(e) => setFormData(prev => ({ ...prev, color: e.target.value }))}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Condition *</Label>
                  <div className="grid grid-cols-2 gap-3">
                    {conditions.map(condition => (
                      <Card 
                        key={condition.value}
                        className={`cursor-pointer transition-all ${
                          formData.condition === condition.value 
                            ? 'bg-blue-600 border-blue-500' 
                            : 'bg-gray-800 border-gray-600 hover:border-gray-500'
                        }`}
                        onClick={() => setFormData(prev => ({ ...prev, condition: condition.value }))}
                      >
                        <CardContent className="p-3">
                          <div className="text-white font-medium">{condition.label}</div>
                          <div className="text-xs text-gray-400">{condition.description}</div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label className="text-white mb-2 block">Description *</Label>
                  <Textarea
                    placeholder="Describe your item in detail. Include condition, features, and any relevant information..."
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white min-h-32"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Listing Type</Label>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { value: 'sell', label: 'Sell', icon: ShoppingBag, desc: 'Sell your item' },
                      { value: 'buy_request', label: 'Looking For', icon: Target, desc: 'Request to buy' },
                      { value: 'trade', label: 'Trade', icon: ArrowLeft, desc: 'Trade for other items' },
                      { value: 'group_buy', label: 'Group Buy', icon: Users, desc: 'Organize group purchase' }
                    ].map(type => (
                      <Card 
                        key={type.value}
                        className={`cursor-pointer transition-all ${
                          formData.listingType === type.value 
                            ? 'bg-blue-600 border-blue-500' 
                            : 'bg-gray-800 border-gray-600 hover:border-gray-500'
                        }`}
                        onClick={() => setFormData(prev => ({ ...prev, listingType: type.value as any }))}
                      >
                        <CardContent className="p-3 text-center">
                          <type.icon className="w-6 h-6 mx-auto mb-1 text-white" />
                          <div className="text-white text-sm font-medium">{type.label}</div>
                          <div className="text-xs text-gray-400">{type.desc}</div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Location</Label>
                  <Input
                    placeholder="City, State"
                    value={formData.location}
                    onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold text-white mb-2">Upload Product Images</h3>
              <p className="text-gray-400 mb-6">Add up to 8 high-quality images. First image will be the main photo.</p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {Array.from({ length: 8 }).map((_, index) => (
                <div 
                  key={index}
                  className={`aspect-square border-2 border-dashed rounded-lg flex items-center justify-center cursor-pointer transition-all ${
                    uploadedImages[index] 
                      ? 'border-green-500 bg-green-500/10' 
                      : 'border-gray-600 bg-gray-800/50 hover:border-gray-500'
                  }`}
                  onClick={() => fileInputRef.current?.click()}
                >
                  {uploadedImages[index] ? (
                    <div className="relative w-full h-full">
                      <ImageWithFallback
                        src={uploadedImages[index]} 
                        alt={`Upload ${index + 1}`}
                        className="w-full h-full object-cover rounded-lg"
                        width={200}
                        height={200}
                      />
                      {index === 0 && (
                        <Badge className="absolute top-2 left-2 bg-blue-600">Main</Badge>
                      )}
                      <Button
                        size="sm"
                        variant="destructive"
                        className="absolute top-2 right-2 w-6 h-6 p-0"
                        onClick={(e) => {
                          e.stopPropagation();
                          setUploadedImages(prev => prev.filter((_, i) => i !== index));
                        }}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center">
                      <Camera className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-xs text-gray-400">
                        {index === 0 ? 'Main Photo' : `Photo ${index + 1}`}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />

            <Card className="bg-gray-800 border-gray-600">
              <CardContent className="p-6">
                <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <Wand2 className="w-5 h-5 text-purple-400" />
                  AI Photo Enhancement (Coming Soon)
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="bg-gray-700 border-gray-600">
                    <CardContent className="p-4 text-center">
                      <Sparkles className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                      <h5 className="text-white font-medium mb-1">Auto Enhance</h5>
                      <p className="text-xs text-gray-400">Automatically improve lighting and clarity</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-gray-700 border-gray-600">
                    <CardContent className="p-4 text-center">
                      <Target className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                      <h5 className="text-white font-medium mb-1">Smart Crop</h5>
                      <p className="text-xs text-gray-400">AI-powered cropping for best presentation</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-gray-700 border-gray-600">
                    <CardContent className="p-4 text-center">
                      <Eye className="w-8 h-8 text-green-400 mx-auto mb-2" />
                      <h5 className="text-white font-medium mb-1">Background</h5>
                      <p className="text-xs text-gray-400">Professional background removal</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label className="text-white mb-2 block">Asking Price * ($)</Label>
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={formData.price}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Original Price ($)</Label>
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={formData.originalPrice}
                    onChange={(e) => setFormData(prev => ({ ...prev, originalPrice: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                  <p className="text-xs text-gray-400 mt-1">Optional: Show savings percentage</p>
                </div>

                <div className="flex items-center justify-between">
                  <Label className="text-white">Price Negotiable</Label>
                  <Switch
                    checked={formData.negotiable}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, negotiable: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label className="text-white">Shipping Available</Label>
                  <Switch
                    checked={formData.shipping}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, shipping: checked }))}
                  />
                </div>
              </div>

              <Card className="bg-gray-800 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-400" />
                    Pricing Insights
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-gray-700 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-300">Market Range</span>
                      <span className="text-white font-medium">$1,100 - $1,400</span>
                    </div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-300">Suggested Price</span>
                      <span className="text-green-400 font-medium">$1,250</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Competition</span>
                      <Badge className="bg-yellow-600">Medium</Badge>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-400" />
                      <span className="text-xs text-gray-300">Competitive pricing</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-400" />
                      <span className="text-xs text-gray-300">High demand category</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-400" />
                      <span className="text-xs text-gray-300">Consider shipping costs</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gray-800 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-blue-400" />
                  CLYQ Credits & Monetization
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 rounded-lg p-4 border border-yellow-500/30">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-yellow-400" />
                      <span className="text-white font-medium">Current Balance</span>
                    </div>
                    <Badge className="bg-yellow-500 text-black font-bold">{credits} CLYQ Credits</Badge>
                  </div>
                  <p className="text-gray-300 text-sm mb-3">
                    Each listing costs 10 CLYQ Credits. Premium features available with additional credits.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <Card className="bg-gray-700 border-gray-600">
                      <CardContent className="p-3 text-center">
                        <Package className="w-6 h-6 text-blue-400 mx-auto mb-1" />
                        <div className="text-white text-sm font-medium">Basic Listing</div>
                        <div className="text-yellow-400 font-bold">10 Credits</div>
                        <div className="text-xs text-gray-400">Standard features</div>
                      </CardContent>
                    </Card>
                    <Card className="bg-gray-700 border-gray-600">
                      <CardContent className="p-3 text-center">
                        <Star className="w-6 h-6 text-purple-400 mx-auto mb-1" />
                        <div className="text-white text-sm font-medium">Featured</div>
                        <div className="text-yellow-400 font-bold">25 Credits</div>
                        <div className="text-xs text-gray-400">Priority placement</div>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="text-center mt-4">
                    <Button 
                      variant="outline" 
                      className="border-yellow-500 text-yellow-400 hover:bg-yellow-500/10"
                      onClick={() => setShowCreditDialog(true)}
                    >
                      Buy More Credits
                    </Button>
                    <Badge className="ml-2 bg-green-600 text-white">FREE for testing</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold text-white mb-2">AI Optimization & Insights</h3>
              <p className="text-gray-400 mb-6">Let our AI analyze and optimize your listing for maximum visibility</p>
            </div>

            <Card className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 border-purple-500/30">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <Brain className="w-12 h-12 text-purple-400 mx-auto mb-3" />
                  <Button
                    onClick={analyzeWithAI}
                    disabled={isAiAnalyzing}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    {isAiAnalyzing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Analyze with AI
                      </>
                    )}
                  </Button>
                </div>

                {isAiAnalyzing && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-white">
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                      <span>Analyzing market trends...</span>
                    </div>
                    <div className="flex items-center gap-3 text-white">
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse delay-100"></div>
                      <span>Optimizing title and description...</span>
                    </div>
                    <div className="flex items-center gap-3 text-white">
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse delay-200"></div>
                      <span>Generating pricing recommendations...</span>
                    </div>
                  </div>
                )}

                {aiSuggestions && (
                  <div className="space-y-4 mt-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      <Card className="bg-gray-800 border-gray-600">
                        <CardHeader>
                          <CardTitle className="text-white text-sm flex items-center gap-2">
                            <Tag className="w-4 h-4 text-blue-400" />
                            Optimized Title
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-300 text-sm mb-3">{aiSuggestions.suggestedTitle}</p>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => applySuggestion('title', aiSuggestions.suggestedTitle)}
                          >
                            Apply Suggestion
                          </Button>
                        </CardContent>
                      </Card>

                      <Card className="bg-gray-800 border-gray-600">
                        <CardHeader>
                          <CardTitle className="text-white text-sm flex items-center gap-2">
                            <DollarSign className="w-4 h-4 text-green-400" />
                            Smart Pricing
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Recommended:</span>
                              <span className="text-green-400 font-medium">${aiSuggestions.suggestedPrice.recommended}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Range:</span>
                              <span className="text-white">${aiSuggestions.suggestedPrice.range.min} - ${aiSuggestions.suggestedPrice.range.max}</span>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => applySuggestion('price', aiSuggestions.suggestedPrice.recommended.toString())}
                            >
                              Apply Price
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <Card className="bg-gray-800 border-gray-600">
                      <CardHeader>
                        <CardTitle className="text-white text-sm flex items-center gap-2">
                          <MessageSquare className="w-4 h-4 text-purple-400" />
                          Enhanced Description
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-300 text-sm mb-3">{aiSuggestions.optimizedDescription}</p>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => applySuggestion('description', aiSuggestions.optimizedDescription)}
                        >
                          Use AI Description
                        </Button>
                      </CardContent>
                    </Card>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                      <Card className="bg-gray-800 border-gray-600">
                        <CardHeader>
                          <CardTitle className="text-white text-sm">Market Insights</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-400 text-xs">Demand:</span>
                            <Badge className="bg-green-600 text-xs">{aiSuggestions.marketInsights.demand}</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400 text-xs">Competition:</span>
                            <Badge className="bg-yellow-600 text-xs">{aiSuggestions.marketInsights.competition}</Badge>
                          </div>
                          <p className="text-xs text-gray-300">{aiSuggestions.marketInsights.bestTimeToSell}</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-gray-800 border-gray-600">
                        <CardHeader>
                          <CardTitle className="text-white text-sm">Visibility Score</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-400 mb-2">{aiSuggestions.visibility.score}/100</div>
                            <div className="text-xs text-gray-400">Excellent visibility</div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-gray-800 border-gray-600">
                        <CardHeader>
                          <CardTitle className="text-white text-sm">Suggested Tags</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex flex-wrap gap-1">
                            {aiSuggestions.suggestedTags.map((tag: string, index: number) => (
                              <Badge key={index} className="bg-blue-600 text-xs">{tag}</Badge>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold text-white mb-2">Preview Your Listing</h3>
              <p className="text-gray-400 mb-6">Review your listing before publishing to the marketplace</p>
            </div>

            <Card className="bg-gray-800 border-gray-600">
              <CardContent className="p-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    {uploadedImages.length > 0 ? (
                      <ImageWithFallback
                        src={uploadedImages[0]}
                        alt="Main product"
                        className="w-full h-64 object-cover rounded-lg"
                        width={400}
                        height={256}
                      />
                    ) : (
                      <div className="w-full h-64 bg-gray-700 rounded-lg flex items-center justify-center">
                        <Camera className="w-12 h-12 text-gray-400" />
                      </div>
                    )}
                    <div className="flex gap-2 mt-3 overflow-x-auto">
                      {uploadedImages.slice(1).map((img, index) => (
                        <ImageWithFallback
                          key={index}
                          src={img}
                          alt={`Product ${index + 2}`}
                          className="w-16 h-16 object-cover rounded flex-shrink-0"
                          width={64}
                          height={64}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="text-xl font-semibold text-white">{formData.title || 'Product Title'}</h4>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge className="bg-blue-600">{formData.category}</Badge>
                        <Badge variant="outline" className="border-gray-600 text-gray-300">{formData.condition}</Badge>
                        {formData.negotiable && <Badge className="bg-green-600">Negotiable</Badge>}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-2xl font-bold text-green-400">${formData.price}</span>
                      {formData.originalPrice && (
                        <span className="text-lg text-gray-400 line-through">${formData.originalPrice}</span>
                      )}
                    </div>

                    <p className="text-gray-300">{formData.description || 'Product description will appear here...'}</p>

                    <div className="space-y-2">
                      {formData.brand && (
                        <div className="flex items-center gap-2">
                          <span className="text-gray-400 text-sm">Brand:</span>
                          <span className="text-white text-sm">{formData.brand}</span>
                        </div>
                      )}
                      {formData.location && (
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-300 text-sm">{formData.location}</span>
                        </div>
                      )}
                      {formData.shipping && (
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-400" />
                          <span className="text-green-400 text-sm">Shipping Available</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4 text-center">
                  <Eye className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                  <div className="text-white font-medium">Estimated Views</div>
                  <div className="text-2xl font-bold text-blue-400">2.3K</div>
                  <div className="text-xs text-gray-400">in first week</div>
                </CardContent>
              </Card>
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4 text-center">
                  <MessageSquare className="w-8 h-8 text-green-400 mx-auto mb-2" />
                  <div className="text-white font-medium">Expected Inquiries</div>
                  <div className="text-2xl font-bold text-green-400">15-20</div>
                  <div className="text-xs text-gray-400">based on category</div>
                </CardContent>
              </Card>
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4 text-center">
                  <Clock className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                  <div className="text-white font-medium">Sale Probability</div>
                  <div className="text-2xl font-bold text-purple-400">87%</div>
                  <div className="text-xs text-gray-400">within 30 days</div>
                </CardContent>
              </Card>
            </div>

            <div className="flex gap-4 justify-center">
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300"
                onClick={() => setCurrentStep(1)}
              >
                Edit Listing
              </Button>
              <Button
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                onClick={() => {
                  // Handle publishing
                  setLocation('/marketplace');
                }}
              >
                <Package className="w-4 h-4 mr-2" />
                Publish Listing
                <Badge className="bg-yellow-500 text-black ml-2">10 Credits</Badge>
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <div className="bg-gray-800/50 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                onClick={() => setLocation('/marketplace')}
                className="text-gray-300 hover:text-white"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-white">Diversified Selling Made Easier, Scalable</h1>
                <p className="text-gray-400">Create a professional listing with AI assistance</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge className="bg-yellow-500 text-black">{credits} CLYQ Credits</Badge>
              <Button variant="outline" onClick={() => setShowCreditDialog(true)}>
                Buy Credits
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="bg-gray-800/30 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer transition-all ${
                    currentStep === step.id
                      ? 'bg-blue-600 text-white'
                      : currentStep > step.id
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-700 text-gray-400'
                  }`}
                  onClick={() => {
                    // Only allow going to previous steps or current step
                    if (step.id <= currentStep) {
                      setCurrentStep(step.id);
                    }
                  }}
                >
                  <step.icon className="w-4 h-4" />
                  <span className="hidden sm:inline text-sm">{step.title}</span>
                </div>
                {index < steps.length - 1 && (
                  <div className="w-8 h-px bg-gray-600 mx-2" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {renderStepContent()}

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-8">
          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
            disabled={currentStep === 1}
            className="border-gray-600 text-gray-300"
          >
            Previous
          </Button>
          <div className="flex items-center gap-3">
            {!validateCurrentStep() && (
              <div className="text-right">
                <p className="text-red-400 text-sm font-medium">Complete required fields:</p>
                <p className="text-red-300 text-xs">{getStepRequirements().join(', ')}</p>
              </div>
            )}
            <Button
              onClick={() => setCurrentStep(Math.min(5, currentStep + 1))}
              disabled={currentStep === 5 || !validateCurrentStep()}
              className={`${
                validateCurrentStep() 
                  ? 'bg-blue-600 hover:bg-blue-700' 
                  : 'bg-gray-600 cursor-not-allowed'
              }`}
            >
              {currentStep === 5 ? 'Complete' : 'Next Step'}
            </Button>
          </div>
        </div>
      </div>

      {/* Credit Purchase Dialog */}
      <Dialog open={showCreditDialog} onOpenChange={setShowCreditDialog}>
        <DialogContent className="bg-gray-800 border-gray-600">
          <DialogHeader>
            <DialogTitle className="text-white">Purchase CLYQ Credits</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { credits: 100, price: 4.99, popular: false },
                { credits: 500, price: 19.99, popular: true },
                { credits: 1000, price: 34.99, popular: false }
              ].map((pack, index) => (
                <Card 
                  key={index}
                  className={`cursor-pointer transition-all ${
                    pack.popular 
                      ? 'bg-gradient-to-br from-blue-600/20 to-purple-600/20 border-blue-500' 
                      : 'bg-gray-700 border-gray-600 hover:border-gray-500'
                  }`}
                >
                  <CardContent className="p-4 text-center">
                    {pack.popular && (
                      <Badge className="bg-blue-600 mb-2">Most Popular</Badge>
                    )}
                    <div className="text-2xl font-bold text-white">{pack.credits}</div>
                    <div className="text-sm text-gray-400 mb-2">Credits</div>
                    <div className="text-xl font-semibold text-green-400">${pack.price}</div>
                    <div className="text-xs text-gray-400">
                      ${(pack.price / pack.credits * 100).toFixed(3)} per 100 credits
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="bg-green-600/20 border border-green-600/30 rounded-lg p-4 text-center">
              <div className="text-green-400 font-semibold mb-2">🎉 Testing Phase - Everything is FREE!</div>
              <p className="text-gray-300 text-sm">
                We're currently in beta testing. All features are free to showcase our monetization model.
                Credits will be required when we launch publicly.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}