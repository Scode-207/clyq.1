import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Heart, MessageCircle, Share2, Bookmark, MapPin, Star, Calendar, User, Filter, TrendingUp, Coffee, Leaf, Utensils, Camera, ThumbsUp, Eye, Clock, Search, Zap, Globe, Droplets, Truck, Recycle, Award, BarChart3, Users, Timer, ShoppingCart, DollarSign, Package, UserCheck, MessageSquare, Handshake, ArrowUpDown, Bot, Plane, Send, X, Phone, Video, Shield, AlertTriangle, CheckCircle, Sparkles, Brain, Target, TrendingDown, ChevronUp, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import ImageWithFallback from "@/components/image-with-fallback";

interface Seller {
  id: string;
  name: string;
  username: string;
  avatar: string;
  verified: boolean;
  location: string;
  rating: number;
  totalSales: number;
  responseTime: string;
  joinedDate: string;
  specialties: string[];
}

interface MarketplaceItem {
  id: string;
  type: 'sell' | 'buy_request' | 'trade' | 'group_buy';
  seller: Seller;
  title: string;
  description: string;
  images: string[];
  price: number;
  originalPrice?: number;
  condition: 'like_new' | 'good' | 'fair' | 'needs_repair';
  category: string;
  subcategory: string;
  brand?: string;
  size?: string;
  color?: string;
  likes: number;
  comments: number;
  watchers: number;
  timestamp: string;
  location: string;
  tags: string[];
  negotiable: boolean;
  shipping: {
    available: boolean;
    cost: number;
    methods: string[];
  };
  aiInsights: {
    priceScore: number; // 1-10 (fair pricing)
    demandLevel: 'high' | 'medium' | 'low';
    similarItems: number;
    suggestedPrice: number;
    marketTrend: 'rising' | 'stable' | 'falling';
    quickSaleChance: number; // percentage
  };
  socialProof: {
    views: number;
    watchers: number;
    inquiries: number;
    nearbyInterest: number;
  };
}

interface RestaurantItem {
  id: string;
  name: string;
  cuisine: string;
  rating: number;
  priceRange: string;
  location: string;
  distance: string;
  specialties: string[];
  ambience: string;
  bestFor: string[];
  image: string;
  likes: number;
  reviews: number;
  timestamp: string;
}

interface TravelItem {
  id: string;
  destination: string;
  type: 'group_trip' | 'solo_adventure' | 'family_vacation' | 'business_travel';
  organizer: Seller;
  participants: number;
  maxParticipants: number;
  duration: string;
  startDate: string;
  estimatedCost: number;
  highlights: string[];
  difficulty: 'easy' | 'moderate' | 'challenging';
  image: string;
  likes: number;
  comments: number;
  timestamp: string;
}

// Mock data for sellers
const mockSellers: Seller[] = [
  {
    id: '1',
    name: 'Alex Chen',
    username: 'alexc_photo',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    verified: true,
    location: 'San Francisco, CA',
    rating: 4.9,
    totalSales: 127,
    responseTime: '< 1 hour',
    joinedDate: '2023-01-15',
    specialties: ['Photography', 'Tech', 'Travel']
  },
  {
    id: '2',
    name: 'Sarah Kim',
    username: 'sarahk_vintage',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    verified: true,
    location: 'Brooklyn, NY',
    rating: 4.8,
    totalSales: 89,
    responseTime: '< 30 mins',
    joinedDate: '2023-03-22',
    specialties: ['Vintage', 'Fashion', 'Antiques']
  },
  {
    id: '3',
    name: 'Carlos Martinez',
    username: 'carlos_vinyl',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face',
    verified: false,
    location: 'Austin, TX',
    rating: 4.7,
    totalSales: 156,
    responseTime: '< 2 hours',
    joinedDate: '2022-11-08',
    specialties: ['Music', 'Vinyl', 'Audio']
  },
  {
    id: '4',
    name: 'Diana Chen',
    username: 'diana_home',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b766?w=150&h=150&fit=crop&crop=face',
    verified: true,
    location: 'Seattle, WA',
    rating: 4.9,
    totalSales: 203,
    responseTime: '< 1 hour',
    joinedDate: '2023-05-14',
    specialties: ['Home Decor', 'Furniture', 'Design']
  },
  {
    id: '5',
    name: 'Michael Rodriguez',
    username: 'mike_sports',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    verified: false,
    location: 'Denver, CO',
    rating: 4.6,
    totalSales: 73,
    responseTime: '< 3 hours',
    joinedDate: '2023-07-02',
    specialties: ['Sports', 'Outdoor', 'Fitness']
  }
];

// Mock data for marketplace items
const mockMarketplaceItems: MarketplaceItem[] = [
  {
    id: '1',
    type: 'sell',
    seller: mockSellers[0],
    title: 'iPhone 14 Pro',
    description: 'Professional-grade camera in excellent condition. Only 2,000 shutter actuations. Perfect for photography enthusiasts.',
    images: ['https://images.unsplash.com/photo-1606983340126-99ab4feaa64d?w=400&h=300&fit=crop'],
    price: 2899,
    originalPrice: 3899,
    condition: 'like_new',
    category: 'Electronics',
    subcategory: 'Cameras',
    brand: 'Canon',
    likes: 24,
    comments: 8,
    watchers: 15,
    timestamp: '2h ago',
    location: 'San Francisco, CA',
    tags: ['Photography', 'Professional', 'Mirrorless'],
    negotiable: true,
    shipping: {
      available: true,
      cost: 25,
      methods: ['UPS', 'FedEx']
    },
    aiInsights: {
      priceScore: 8.5,
      demandLevel: 'high',
      similarItems: 12,
      suggestedPrice: 2950,
      marketTrend: 'rising',
      quickSaleChance: 85
    },
    socialProof: {
      views: 342,
      watchers: 15,
      inquiries: 8,
      nearbyInterest: 23
    }
  },
  {
    id: '2',
    type: 'sell',
    seller: mockSellers[1],
    title: 'Vintage Leather Jacket',
    description: 'Authentic vintage leather jacket from the 70s. Genuine leather, perfect patina. Size Medium.',
    images: ['https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=300&fit=crop'],
    price: 350,
    originalPrice: 450,
    condition: 'good',
    category: 'Fashion',
    subcategory: 'Outerwear',
    brand: 'Vintage',
    size: 'M',
    color: 'Brown',
    likes: 45,
    comments: 12,
    watchers: 28,
    timestamp: '4h ago',
    location: 'Brooklyn, NY',
    tags: ['Vintage', 'Leather', 'Fashion'],
    negotiable: true,
    shipping: {
      available: true,
      cost: 15,
      methods: ['USPS', 'UPS']
    },
    aiInsights: {
      priceScore: 9.2,
      demandLevel: 'high',
      similarItems: 6,
      suggestedPrice: 375,
      marketTrend: 'stable',
      quickSaleChance: 78
    },
    socialProof: {
      views: 567,
      watchers: 28,
      inquiries: 15,
      nearbyInterest: 34
    }
  },
  {
    id: '3',
    type: 'buy_request',
    seller: mockSellers[2],
    title: 'Looking for: Hasselblad 500CM Film Camera',
    description: 'Searching for a Hasselblad 500CM in working condition. Willing to pay fair market price for the right piece.',
    images: ['https://images.unsplash.com/photo-1606983340126-99ab4feaa64d?w=400&h=300&fit=crop'],
    price: 1200,
    condition: 'good',
    category: 'Electronics',
    subcategory: 'Cameras',
    brand: 'Hasselblad',
    likes: 18,
    comments: 5,
    watchers: 12,
    timestamp: '1d ago',
    location: 'Austin, TX',
    tags: ['Film', 'Medium Format', 'Photography'],
    negotiable: true,
    shipping: {
      available: true,
      cost: 30,
      methods: ['Insured Shipping']
    },
    aiInsights: {
      priceScore: 7.8,
      demandLevel: 'medium',
      similarItems: 3,
      suggestedPrice: 1350,
      marketTrend: 'rising',
      quickSaleChance: 65
    },
    socialProof: {
      views: 234,
      watchers: 12,
      inquiries: 5,
      nearbyInterest: 8
    }
  },
  {
    id: '4',
    type: 'sell',
    seller: mockSellers[3],
    title: 'Mid-Century Modern Dining Table',
    description: 'Authentic teak dining table from the 1960s. Seats 6 comfortably. Minor wear consistent with age.',
    images: ['https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=300&fit=crop'],
    price: 850,
    originalPrice: 1200,
    condition: 'good',
    category: 'Furniture',
    subcategory: 'Dining',
    brand: 'Mid-Century',
    likes: 67,
    comments: 23,
    watchers: 41,
    timestamp: '3h ago',
    location: 'Seattle, WA',
    tags: ['Mid-Century', 'Teak', 'Dining'],
    negotiable: true,
    shipping: {
      available: false,
      cost: 0,
      methods: ['Local Pickup Only']
    },
    aiInsights: {
      priceScore: 8.9,
      demandLevel: 'high',
      similarItems: 8,
      suggestedPrice: 900,
      marketTrend: 'rising',
      quickSaleChance: 82
    },
    socialProof: {
      views: 789,
      watchers: 41,
      inquiries: 19,
      nearbyInterest: 52
    }
  },
  {
    id: '5',
    type: 'trade',
    seller: mockSellers[4],
    title: 'Gaming Setup',
    description: 'Looking to trade my Trek mountain bike for a good road bike. Similar value range preferred.',
    images: ['https://images.unsplash.com/photo-1544191696-15693072b667?w=400&h=300&fit=crop'],
    price: 600,
    condition: 'good',
    category: 'Sports',
    subcategory: 'Cycling',
    brand: 'Trek',
    likes: 32,
    comments: 14,
    watchers: 22,
    timestamp: '6h ago',
    location: 'Denver, CO',
    tags: ['Cycling', 'Mountain Bike', 'Trade'],
    negotiable: true,
    shipping: {
      available: true,
      cost: 75,
      methods: ['BikeFlights']
    },
    aiInsights: {
      priceScore: 7.5,
      demandLevel: 'medium',
      similarItems: 15,
      suggestedPrice: 650,
      marketTrend: 'stable',
      quickSaleChance: 72
    },
    socialProof: {
      views: 456,
      watchers: 22,
      inquiries: 11,
      nearbyInterest: 17
    }
  },
  {
    id: '6',
    type: 'group_buy',
    seller: mockSellers[0],
    title: 'Rolex Watch',
    description: 'Organizing a group purchase for a 3-day photography workshop. Need 5 more people to get group discount.',
    images: ['https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=400&h=300&fit=crop'],
    price: 450,
    originalPrice: 650,
    condition: 'like_new',
    category: 'Education',
    subcategory: 'Workshops',
    likes: 28,
    comments: 9,
    watchers: 18,
    timestamp: '1d ago',
    location: 'San Francisco, CA',
    tags: ['Photography', 'Workshop', 'Group'],
    negotiable: false,
    shipping: {
      available: false,
      cost: 0,
      methods: ['In Person']
    },
    aiInsights: {
      priceScore: 9.1,
      demandLevel: 'high',
      similarItems: 2,
      suggestedPrice: 450,
      marketTrend: 'stable',
      quickSaleChance: 88
    },
    socialProof: {
      views: 623,
      watchers: 18,
      inquiries: 12,
      nearbyInterest: 29
    }
  }
];

// Mock data for restaurants
const mockRestaurants: RestaurantItem[] = [
  {
    id: '1',
    name: 'Sakura Sushi',
    cuisine: 'Japanese',
    rating: 4.8,
    priceRange: '$$$',
    location: 'Downtown',
    distance: '0.3 miles',
    specialties: ['Omakase', 'Fresh Sashimi', 'Sake Selection'],
    ambience: 'Intimate',
    bestFor: ['Date Night', 'Business Dinner'],
    image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=400&h=300&fit=crop',
    likes: 342,
    reviews: 156,
    timestamp: '2h ago'
  },
  {
    id: '2',
    name: 'The Garden Bistro',
    cuisine: 'Mediterranean',
    rating: 4.6,
    priceRange: '$$',
    location: 'Arts District',
    distance: '0.8 miles',
    specialties: ['Farm-to-Table', 'Wood-Fired Pizza', 'Local Wines'],
    ambience: 'Casual',
    bestFor: ['Family', 'Brunch'],
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&h=300&fit=crop',
    likes: 267,
    reviews: 89,
    timestamp: '3h ago'
  },
  {
    id: '3',
    name: 'Spice Route',
    cuisine: 'Indian',
    rating: 4.7,
    priceRange: '$$',
    location: 'University Area',
    distance: '1.2 miles',
    specialties: ['Traditional Curries', 'Tandoor Specialties', 'Vegan Options'],
    ambience: 'Cozy',
    bestFor: ['Groups', 'Takeout'],
    image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop',
    likes: 198,
    reviews: 234,
    timestamp: '4h ago'
  }
];

// Mock data for travel
const mockTravelItems: TravelItem[] = [
  {
    id: '1',
    destination: 'Tokyo Photography Tour',
    type: 'group_trip',
    organizer: mockSellers[0],
    participants: 4,
    maxParticipants: 8,
    duration: '7 days',
    startDate: '2024-03-15',
    estimatedCost: 1850,
    highlights: ['Cherry Blossom Season', 'Street Photography', 'Traditional Culture'],
    difficulty: 'easy',
    image: 'https://images.unsplash.com/photo-1490806843957-31f4c9a91c65?w=400&h=300&fit=crop',
    likes: 89,
    comments: 34,
    timestamp: '1h ago'
  },
  {
    id: '2',
    destination: 'European Vintage Hunt',
    type: 'group_trip',
    organizer: mockSellers[1],
    participants: 6,
    maxParticipants: 12,
    duration: '14 days',
    startDate: '2024-04-20',
    estimatedCost: 2400,
    highlights: ['Flea Markets', 'Antique Shops', 'Historical Sites'],
    difficulty: 'moderate',
    image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&h=300&fit=crop',
    likes: 156,
    comments: 67,
    timestamp: '3h ago'
  },
  {
    id: '3',
    destination: 'Scandinavian Design Tour',
    type: 'group_trip',
    organizer: mockSellers[3],
    participants: 3,
    maxParticipants: 6,
    duration: '10 days',
    startDate: '2024-05-10',
    estimatedCost: 2100,
    highlights: ['Design Museums', 'Furniture Workshops', 'Nordic Culture'],
    difficulty: 'easy',
    image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop',
    likes: 234,
    comments: 45,
    timestamp: '5h ago'
  }
];

// Chat message interface
interface ChatMessage {
  id: string;
  sender: 'user' | 'seller';
  content: string;
  timestamp: Date;
  isTyping?: boolean;
}

export default function Marketplace() {
  const [, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'marketplace' | 'restaurants' | 'travel'>('all');
  const [selectedType, setSelectedType] = useState<'all' | 'sell' | 'buy_request' | 'trade' | 'group_buy'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'recent' | 'price_low' | 'price_high' | 'popularity'>('recent');
  const itemRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});
  const [selectedProfile, setSelectedProfile] = useState<any>(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  
  // Chat state
  const [showChatModal, setShowChatModal] = useState(false);
  const [chatSeller, setChatSeller] = useState<Seller | null>(null);
  const [chatItem, setChatItem] = useState<MarketplaceItem | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isSellerTyping, setIsSellerTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  // Fraud detection state
  const [showFraudModal, setShowFraudModal] = useState(false);
  const [fraudCheckItem, setFraudCheckItem] = useState<MarketplaceItem | null>(null);
  const [fraudAnalysisResult, setFraudAnalysisResult] = useState<any>(null);

  // AI Agent state
  const [showAIAgent, setShowAIAgent] = useState(false);
  const [aiRecommendations, setAiRecommendations] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [agentExpanded, setAgentExpanded] = useState(false);

  // Predefined fraud check results (most safe, few unsafe)
  const fraudResults: { [key: string]: any } = {
    'iphone-14-pro': {
      status: 'safe',
      score: 95,
      verified: true,
      checks: {
        sellerHistory: 'Excellent',
        priceAnalysis: 'Fair market price',
        imageVerification: 'Original photos',
        communicationPattern: 'Normal response time'
      },
      riskFactors: [],
      recommendation: 'Safe to proceed with purchase'
    },
    'vintage-leather-jacket': {
      status: 'unsafe',
      score: 25,
      verified: false,
      checks: {
        sellerHistory: 'New account (created 2 days ago)',
        priceAnalysis: 'Price 60% below market value',
        imageVerification: 'Stock photos from other sites',
        communicationPattern: 'Suspicious urgent language'
      },
      riskFactors: [
        'Seller account very new',
        'Price too good to be true',
        'Images appear to be stolen',
        'Pushing for immediate payment'
      ],
      recommendation: 'Proceed with extreme caution or avoid'
    },
    'gaming-setup': {
      status: 'safe',
      score: 88,
      verified: true,
      checks: {
        sellerHistory: 'Good reputation (6 months)',
        priceAnalysis: 'Reasonable price range',
        imageVerification: 'Original photos with timestamp',
        communicationPattern: 'Professional communication'
      },
      riskFactors: ['Minor: No original receipts'],
      recommendation: 'Generally safe to proceed'
    },
    'rolex-watch': {
      status: 'unsafe',
      score: 15,
      verified: false,
      checks: {
        sellerHistory: 'Multiple negative reviews',
        priceAnalysis: 'Suspiciously low price',
        imageVerification: 'Low quality images',
        communicationPattern: 'Evasive about details'
      },
      riskFactors: [
        'High-value item at very low price',
        'Seller has dispute history',
        'Refuses video call verification',
        'No authentication papers'
      ],
      recommendation: 'High risk - recommend avoiding'
    }
  };

  const checkFraud = (item: MarketplaceItem) => {
    setFraudCheckItem(item);
    
    // Get predefined result or default to safe
    const itemKey = item.title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    const result = fraudResults[itemKey] || {
      status: 'safe',
      score: 92,
      verified: true,
      checks: {
        sellerHistory: 'Good standing',
        priceAnalysis: 'Market appropriate',
        imageVerification: 'Verified original',
        communicationPattern: 'Normal patterns'
      },
      riskFactors: [],
      recommendation: 'Safe to proceed'
    };
    
    setFraudAnalysisResult(result);
    setShowFraudModal(true);
  };

  const analyzeWithAI = async () => {
    setIsAnalyzing(true);
    setShowAIAgent(true);
    setAgentExpanded(true);
    
    try {
      // Simulate user data from knowledge graph
      const userData = {
        preferences: ['Technology', 'Photography', 'Gaming', 'Travel'],
        location: 'San Francisco, CA',
        recentActivity: ['Viewed cameras', 'Inquired about electronics', 'Joined photography groups'],
        budget: '$500-2000',
        interests: ['Professional equipment', 'Vintage items', 'Local meetups']
      };

      const marketplaceContext = {
        availableItems: mockMarketplaceItems.map(item => ({
          title: item.title,
          category: item.category,
          price: item.price,
          location: item.location,
          type: item.type
        })),
        availableRestaurants: mockRestaurants.map(rest => ({
          name: rest.name,
          cuisine: rest.cuisine,
          location: rest.location,
          rating: rest.rating
        })),
        availableTravel: mockTravelItems.map(travel => ({
          destination: travel.destination,
          type: travel.type,
          cost: travel.estimatedCost,
          participants: travel.participants
        }))
      };

      const prompt = `You are an AI agent analyzing a user's knowledge graph and marketplace data to provide intelligent recommendations.

User Profile:
- Preferences: ${userData.preferences.join(', ')}
- Location: ${userData.location}
- Recent Activity: ${userData.recentActivity.join(', ')}
- Budget Range: ${userData.budget}
- Interests: ${userData.interests.join(', ')}

Marketplace Context:
- Available Items: ${JSON.stringify(marketplaceContext.availableItems.slice(0, 6))}
- Available Restaurants: ${JSON.stringify(marketplaceContext.availableRestaurants.slice(0, 4))}
- Available Travel: ${JSON.stringify(marketplaceContext.availableTravel.slice(0, 3))}

Based on this data, provide personalized recommendations in JSON format:
{
  "marketplaceRecommendations": [
    {"item": "item_name", "reason": "why_recommended", "confidence": number_0_to_100}
  ],
  "restaurantRecommendations": [
    {"restaurant": "name", "reason": "why_recommended", "confidence": number_0_to_100}
  ],
  "travelRecommendations": [
    {"destination": "name", "reason": "why_recommended", "confidence": number_0_to_100}
  ],
  "groupSuggestions": [
    {"group": "group_name", "activity": "activity_type", "reason": "why_join", "confidence": number_0_to_100}
  ],
  "insights": {
    "behaviorPattern": "user_behavior_analysis",
    "trendingInterests": ["interest1", "interest2"],
    "budgetOptimization": "spending_advice",
    "socialRecommendations": "social_interaction_advice"
  }
}`;

      const response = await fetch('/api/ai/analyze-recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, userData, marketplaceContext })
      });

      if (response.ok) {
        const recommendations = await response.json();
        setAiRecommendations(recommendations);
      } else {
        // Fallback recommendations
        setAiRecommendations({
          marketplaceRecommendations: [
            {"item": "iPhone 14 Pro", "reason": "Matches your technology interest and photography needs", "confidence": 92},
            {"item": "Gaming Setup", "reason": "Perfect for your gaming hobby and within budget", "confidence": 88}
          ],
          restaurantRecommendations: [
            {"restaurant": "Noma SF", "reason": "High-rated Nordic cuisine matching your taste for quality", "confidence": 85},
            {"restaurant": "The French Laundry", "reason": "Professional dining experience for special occasions", "confidence": 90}
          ],
          travelRecommendations: [
            {"destination": "Tokyo Photography Tour", "reason": "Combines travel and photography interests", "confidence": 95},
            {"destination": "Patagonia Adventure", "reason": "Adventure travel matching your exploration spirit", "confidence": 82}
          ],
          groupSuggestions: [
            {"group": "SF Photography Collective", "activity": "Photography meetups", "reason": "Connect with local photographers and share techniques", "confidence": 94},
            {"group": "Tech Professionals Network", "activity": "Technology discussions", "reason": "Network with peers in your field of interest", "confidence": 87}
          ],
          insights: {
            behaviorPattern: "You show strong interest in high-quality technology and creative pursuits",
            trendingInterests: ["Professional Photography", "Gaming Technology", "Local Experiences"],
            budgetOptimization: "Focus on professional-grade equipment that retains value",
            socialRecommendations: "Join photography groups to combine hobby with networking"
          }
        });
      }
    } catch (error) {
      console.error('AI Analysis error:', error);
      setAiRecommendations({
        error: 'Unable to complete analysis. Please check your connection and try again.'
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Filter items based on selected category and type
  const filteredItems = mockMarketplaceItems.filter(item => {
    const matchesType = selectedType === 'all' || item.type === selectedType;
    const matchesSearch = searchQuery === '' || 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesType && matchesSearch;
  });

  // Sort items
  const sortedItems = [...filteredItems].sort((a, b) => {
    switch (sortBy) {
      case 'price_low':
        return a.price - b.price;
      case 'price_high':
        return b.price - a.price;
      case 'popularity':
        return b.likes - a.likes;
      default:
        return 0; // Keep original order for 'recent'
    }
  });

  const handleItemClick = (itemId: string) => {
    const element = itemRefs.current[itemId];
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Chat functionality
  const startChat = (seller: Seller, item: MarketplaceItem) => {
    setChatSeller(seller);
    setChatItem(item);
    setChatMessages([
      {
        id: '1',
        sender: 'seller',
        content: `Hey there! Interested in my ${item.title}?`,
        timestamp: new Date()
      }
    ]);
    setShowChatModal(true);
  };

  const sendMessage = async (content: string) => {
    if (!content.trim() || !chatSeller) return;

    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      content,
      timestamp: new Date()
    };
    
    setChatMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setIsSellerTyping(true);

    // Simulate seller typing and response
    setTimeout(async () => {
      setIsSellerTyping(false);
      
      // Generate AI response using OpenAI
      try {
        const response = await fetch('/api/chat/negotiate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userMessage: content,
            sellerName: chatSeller.name,
            itemTitle: chatItem?.title,
            itemPrice: chatItem?.price,
            conversationHistory: chatMessages
          })
        });

        if (response.ok) {
          const data = await response.json();
          const sellerMessage: ChatMessage = {
            id: (Date.now() + 1).toString(),
            sender: 'seller',
            content: data.response,
            timestamp: new Date()
          };
          setChatMessages(prev => [...prev, sellerMessage]);
        } else {
          throw new Error('Failed to get response');
        }
      } catch (error) {
        // Fallback response if API fails
        const fallbackResponses = [
          "Thanks for your interest! The price is negotiable. What were you thinking?",
          "I'm pretty firm on the price, but I could throw in free shipping. Deal?",
          "How about we meet in the middle? I could do 10% off the listed price.",
          "This item is in excellent condition. I think the price is fair, but I'm open to reasonable offers.",
          "I've had a lot of interest in this item. My best price would be just 5% off."
        ];
        
        const sellerMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'seller',
          content: fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)],
          timestamp: new Date()
        };
        setChatMessages(prev => [...prev, sellerMessage]);
      }
    }, 1500 + Math.random() * 2000); // Random delay 1.5-3.5 seconds
  };

  // Auto-scroll chat to bottom
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isSellerTyping]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <div className="bg-gray-800/60 backdrop-blur-md border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo & Navigation */}
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">SocialPlace</h1>
                  <p className="text-xs text-gray-400">Social Commerce Universe</p>
                </div>
              </div>
            </div>

            {/* Social Activity & Profile */}
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                className="text-gray-300 hover:text-white relative"
                onClick={() => setLocation('/social')}
                title="Social Feed"
              >
                <Users className="w-5 h-5" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full text-xs flex items-center justify-center text-white">3</div>
              </Button>
              <Button 
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white gap-2 shadow-lg"
                onClick={() => setLocation('/sell')}
              >
                <Package className="w-4 h-4" />
                Sell/Post
                <Badge className="bg-yellow-500 text-black text-xs ml-1">
                  10 CLYQ Credits
                </Badge>
              </Button>
              <Avatar className="w-10 h-10 ring-2 ring-blue-400">
                <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b612b766?w=150&h=150&fit=crop&crop=face" />
                <AvatarFallback>SC</AvatarFallback>
              </Avatar>
            </div>
          </div>

          {/* Unified Search Bar with Domain Tabs */}
          <div className="relative mb-4">
            <div className="flex bg-gray-700 rounded-lg overflow-hidden shadow-lg">
              <div className="flex">
                <Button 
                  variant={selectedCategory === 'all' ? "default" : "ghost"}
                  size="sm" 
                  className={`rounded-none border-r border-gray-600 ${selectedCategory === 'all' ? 'bg-blue-600' : 'text-gray-300'}`}
                  onClick={() => setSelectedCategory('all')}
                >
                  All
                </Button>
                <Button 
                  variant={selectedCategory === 'marketplace' ? "default" : "ghost"}
                  size="sm" 
                  className={`rounded-none border-r border-gray-600 ${selectedCategory === 'marketplace' ? 'bg-blue-600' : 'text-gray-300'}`}
                  onClick={() => setSelectedCategory('marketplace')}
                >
                  Marketplace
                </Button>
                <Button 
                  variant={selectedCategory === 'restaurants' ? "default" : "ghost"}
                  size="sm" 
                  className={`rounded-none border-r border-gray-600 ${selectedCategory === 'restaurants' ? 'bg-blue-600' : 'text-gray-300'}`}
                  onClick={() => setSelectedCategory('restaurants')}
                >
                  Restaurants
                </Button>
                <Button 
                  variant={selectedCategory === 'travel' ? "default" : "ghost"}
                  size="sm" 
                  className={`rounded-none ${selectedCategory === 'travel' ? 'bg-blue-600' : 'text-gray-300'}`}
                  onClick={() => setSelectedCategory('travel')}
                >
                  Travel
                </Button>
              </div>
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search across all domains..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-transparent border-none text-white placeholder-gray-400 focus:ring-0 focus:border-none rounded-none"
                />
              </div>
            </div>
          </div>

          {/* Your Network Activity */}
          <div className="bg-gray-800/60 rounded-lg p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-400" />
                Your Network Activity
              </h3>
              <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                View All
              </Button>
            </div>
            <div className="flex gap-4 overflow-x-auto pb-2">
              {[
                { 
                  name: 'Alex Chen', 
                  activity: 'Selling Canon R5 camera gear', 
                  time: '2h ago', 
                  status: 'online',
                  currentAction: 'Currently listing photography equipment',
                  engagement: { views: 127, inquiries: 8, rating: 4.9 },
                  interests: ['Photography', 'Tech', 'Travel'],
                  aiInsight: 'Highly active seller with premium photography gear. 95% positive feedback rate.'
                },
                { 
                  name: 'Sarah Kim', 
                  activity: 'Looking for Hasselblad camera', 
                  time: '3h ago', 
                  status: 'away',
                  currentAction: 'Actively searching for vintage cameras',
                  engagement: { views: 89, inquiries: 12, rating: 4.8 },
                  interests: ['Vintage', 'Fashion', 'Antiques'],
                  aiInsight: 'Serious collector with budget of $1,200-1,500. Prefers authenticated vintage pieces.'
                },
                { 
                  name: 'Carlos Martinez', 
                  activity: 'Dining at Spice Route', 
                  time: '1h ago', 
                  status: 'online',
                  currentAction: 'Sharing live dining experience',
                  engagement: { views: 234, inquiries: 15, rating: 4.7 },
                  interests: ['Music', 'Vinyl', 'Audio'],
                  aiInsight: 'Food enthusiast and vinyl collector. Often organizes group dining and music events.'
                },
                { 
                  name: 'Diana Chen', 
                  activity: 'Organizing Tokyo photo trip', 
                  time: '4h ago', 
                  status: 'away',
                  currentAction: 'Planning group travel itinerary',
                  engagement: { views: 312, inquiries: 23, rating: 4.9 },
                  interests: ['Home Decor', 'Furniture', 'Design'],
                  aiInsight: 'Expert trip organizer specializing in design-focused travel. 98% trip satisfaction rate.'
                }
              ].map((friend, index) => (
                <Card 
                  key={index} 
                  className="flex-shrink-0 bg-gray-700/50 border-gray-600 hover:bg-gray-700/70 transition-all duration-300 cursor-pointer group relative overflow-hidden w-[320px]"
                  onClick={() => {
                    setSelectedProfile({ ...friend, seller: mockSellers[index] });
                    setShowProfileModal(true);
                  }}
                >
                  <CardContent className="p-4">
                    {/* Profile Header */}
                    <div className="flex items-center gap-3 mb-3">
                      <div className="relative">
                        <Avatar className="w-12 h-12 ring-2 ring-purple-400/30">
                          <AvatarImage src={mockSellers[index]?.avatar} />
                          <AvatarFallback className="text-sm">{friend.name.slice(0, 2)}</AvatarFallback>
                        </Avatar>
                        <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-gray-700 ${friend.status === 'online' ? 'bg-green-400' : 'bg-gray-400'}`}></div>
                        {friend.status === 'online' && (
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-green-400 animate-ping"></div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium text-white truncate">{friend.name}</h4>
                          {mockSellers[index]?.verified && <UserCheck className="w-3 h-3 text-blue-400" />}
                        </div>
                        <p className="text-xs text-gray-400">{mockSellers[index]?.totalSales} sales • {friend.engagement.rating} ⭐</p>
                      </div>
                    </div>

                    {/* Current Activity */}
                    <div className="bg-gray-800/60 rounded-lg p-3 mb-3">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                        <span className="text-xs font-medium text-blue-400">Live Activity</span>
                      </div>
                      <p className="text-sm text-white font-medium mb-1">{friend.activity}</p>
                      <p className="text-xs text-gray-400">{friend.currentAction}</p>
                    </div>

                    {/* Engagement Stats */}
                    <div className="grid grid-cols-3 gap-2 mb-3">
                      <div className="text-center">
                        <div className="text-sm font-medium text-white">{friend.engagement.views}</div>
                        <div className="text-xs text-gray-400">Views</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm font-medium text-white">{friend.engagement.inquiries}</div>
                        <div className="text-xs text-gray-400">Inquiries</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm font-medium text-white">2</div>
                        <div className="text-xs text-gray-400">Mutual</div>
                      </div>
                    </div>

                    {/* Interest Tags */}
                    <div className="flex flex-wrap gap-1 mb-3">
                      {friend.interests.slice(0, 2).map((interest) => (
                        <Badge key={interest} variant="secondary" className="text-xs bg-gray-600 text-gray-300">
                          {interest}
                        </Badge>
                      ))}
                      {friend.interests.length > 2 && (
                        <Badge variant="secondary" className="text-xs bg-gray-600 text-gray-300">
                          +{friend.interests.length - 2}
                        </Badge>
                      )}
                    </div>

                    {/* Quick AI Insight */}
                    <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-lg p-2 mb-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Bot className="w-3 h-3 text-purple-400" />
                        <span className="text-xs font-medium text-purple-400">AI Insight</span>
                      </div>
                      <p className="text-xs text-gray-300 line-clamp-2">{friend.aiInsight}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="flex-1 h-8 text-xs text-purple-400 hover:bg-purple-600/20 border border-purple-600/30"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Handle Plan Together
                        }}
                      >
                        Plan Together
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="flex-1 h-8 text-xs text-green-400 hover:bg-green-600/20 border border-green-600/30"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Create a mock marketplace item for this friend's activity
                          const mockItem: MarketplaceItem = {
                            id: `friend-${index}`,
                            type: 'sell',
                            seller: mockSellers[index],
                            title: friend.activity.includes('camera') ? 'Camera Equipment' : 
                                   friend.activity.includes('dining') ? 'Restaurant Experience' : 
                                   friend.activity.includes('Tokyo') ? 'Travel Planning' : 'Item',
                            description: friend.currentAction,
                            images: ['https://images.unsplash.com/photo-1606983340126-99ab4feaa64d?w=400&h=300&fit=crop'],
                            price: 500,
                            condition: 'like_new',
                            category: 'General',
                            subcategory: 'General',
                            likes: friend.engagement.views,
                            comments: friend.engagement.inquiries,
                            watchers: 10,
                            timestamp: friend.time,
                            location: mockSellers[index]?.location || 'Local',
                            tags: friend.interests,
                            negotiable: true,
                            shipping: { available: true, cost: 25, methods: ['UPS'] },
                            aiInsights: {
                              priceScore: 8,
                              demandLevel: 'medium' as const,
                              similarItems: 5,
                              suggestedPrice: 450,
                              marketTrend: 'stable' as const,
                              quickSaleChance: 75
                            },
                            socialProof: {
                              views: friend.engagement.views,
                              watchers: 10,
                              inquiries: friend.engagement.inquiries,
                              nearbyInterest: 20
                            }
                          };
                          startChat(mockSellers[index], mockItem);
                        }}
                      >
                        Negotiate
                      </Button>
                    </div>

                    {/* Time indicator */}
                    <div className="flex items-center justify-center gap-1 mt-2 pt-2 border-t border-gray-600">
                      <Clock className="w-3 h-3 text-gray-500" />
                      <span className="text-xs text-gray-500">{friend.time}</span>
                      <span className="text-xs text-gray-500">•</span>
                      <span className="text-xs text-gray-500">Click for AI analysis</span>
                    </div>

                    {/* Hover effect overlay */}
                    <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 to-pink-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content - Full Width */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* Hero Title */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 tracking-tight">
            WORLD'S FIRST MULTI DOMAIN
          </h1>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-orange-400 bg-clip-text text-transparent mb-2 tracking-tight">
            COMMERCE SOCIAL PLATFORM
          </h1>
          <p className="text-gray-400 text-lg md:text-xl max-w-3xl mx-auto">
            Experience the future of social commerce across marketplace, restaurants, and travel
          </p>
        </div>
        
        <div className="space-y-8">
          {/* Marketplace Content */}
          {(selectedCategory === 'all' || selectedCategory === 'marketplace') && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-6 h-6 text-orange-400" />
                  Trending Marketplace Items
                </h2>
                <div className="flex items-center gap-4">
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-gray-700 text-white border border-gray-600 rounded-lg px-3 py-2 text-sm"
                  >
                    <option value="recent">Most Recent</option>
                    <option value="price_low">Price: Low to High</option>
                    <option value="price_high">Price: High to Low</option>
                    <option value="popularity">Most Popular</option>
                  </select>
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                    View All
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sortedItems.map((item) => (
                  <Card
                    key={item.id}
                    ref={(el) => itemRefs.current[item.id] = el}
                    data-item-id={item.id}
                    className="bg-gray-800/60 border-gray-600 hover:bg-gray-800/80 transition-all duration-300 relative h-fit backdrop-blur-sm group"
                  >
                    <CardHeader className="pb-3">
                      {/* Seller Info - Compact */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={item.seller.avatar} alt={item.seller.name} />
                            <AvatarFallback className="text-xs">{item.seller.name.slice(0, 2)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="flex items-center gap-1">
                              <p className="font-medium text-white text-sm">{item.seller.name}</p>
                              {item.seller.verified && <UserCheck className="w-3 h-3 text-blue-400" />}
                            </div>
                            <p className="text-xs text-gray-400">{item.seller.rating} ⭐ • {item.timestamp}</p>
                          </div>
                        </div>
                        
                        {/* Item Type Badge */}
                        <Badge 
                          className={`${
                            item.type === 'sell' ? 'bg-green-600' :
                            item.type === 'buy_request' ? 'bg-blue-600' :
                            item.type === 'trade' ? 'bg-purple-600' :
                            'bg-orange-600'
                          } text-white text-xs`}
                        >
                          {item.type === 'sell' ? 'Sale' :
                           item.type === 'buy_request' ? 'Want' :
                           item.type === 'trade' ? 'Trade' :
                           'Group'}
                        </Badge>
                      </div>

                      {/* Item Image */}
                      <div className="relative mt-3">
                        <ImageWithFallback
                          src={item.images[0]} 
                          alt={item.title}
                          className="w-full h-48 object-cover rounded-lg"
                          width={400}
                          height={192}
                        />
                        {item.originalPrice && (
                          <Badge className="absolute top-2 left-2 bg-red-600 text-white">
                            {Math.round(((item.originalPrice - item.price) / item.originalPrice) * 100)}% OFF
                          </Badge>
                        )}
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="absolute top-2 right-2 text-white hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Heart className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>

                    <CardContent>
                      {/* Item Title & Description */}
                      <div className="mb-3">
                        <h3 className="font-semibold text-white text-lg mb-1">{item.title}</h3>
                        <p className="text-gray-400 text-sm line-clamp-2">{item.description}</p>
                      </div>

                      {/* Price & Condition */}
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl font-bold text-green-400">${item.price}</span>
                          {item.originalPrice && (
                            <span className="text-sm text-gray-500 line-through">${item.originalPrice}</span>
                          )}
                        </div>
                        <Badge 
                          variant="outline"
                          className={`${
                            item.condition === 'like_new' ? 'border-green-500 text-green-400' :
                            item.condition === 'good' ? 'border-blue-500 text-blue-400' :
                            item.condition === 'fair' ? 'border-yellow-500 text-yellow-400' :
                            'border-red-500 text-red-400'
                          }`}
                        >
                          {item.condition.replace('_', ' ')}
                        </Badge>
                      </div>

                      {/* AI Insights Panel */}
                      <div className="bg-gray-700/50 rounded-lg p-3 mb-3">
                        <div className="flex items-center gap-2 mb-2">
                          <Bot className="w-4 h-4 text-cyan-400" />
                          <span className="text-sm font-medium text-cyan-400">AI Analysis</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <span className="text-gray-400">Fair Price:</span>
                            <span className={`ml-1 ${item.aiInsights.priceScore >= 8 ? 'text-green-400' : item.aiInsights.priceScore >= 6 ? 'text-yellow-400' : 'text-red-400'}`}>
                              {item.aiInsights.priceScore}/10
                            </span>
                          </div>
                          <div>
                            <span className="text-gray-400">Demand:</span>
                            <span className={`ml-1 ${item.aiInsights.demandLevel === 'high' ? 'text-green-400' : item.aiInsights.demandLevel === 'medium' ? 'text-yellow-400' : 'text-red-400'}`}>
                              {item.aiInsights.demandLevel}
                            </span>
                          </div>
                          <div>
                            <span className="text-gray-400">Quick Sale:</span>
                            <span className="ml-1 text-blue-400">{item.aiInsights.quickSaleChance}%</span>
                          </div>
                          <div>
                            <span className="text-gray-400">Trend:</span>
                            <span className={`ml-1 ${item.aiInsights.marketTrend === 'rising' ? 'text-green-400' : item.aiInsights.marketTrend === 'stable' ? 'text-yellow-400' : 'text-red-400'}`}>
                              {item.aiInsights.marketTrend}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-1 mb-3">
                        {item.tags.slice(0, 3).map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      {/* Social Proof */}
                      <div className="flex items-center justify-between text-sm text-gray-400 mb-3">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <Heart className="w-4 h-4" />
                            <span>{item.likes}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageCircle className="w-4 h-4" />
                            <span>{item.comments}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            <span>{item.socialProof.views}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span className="text-xs">{item.location}</span>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-2">
                        <Button 
                          className={`flex-1 ${
                            item.type === 'sell' ? 'bg-green-600 hover:bg-green-700' :
                            item.type === 'buy_request' ? 'bg-blue-600 hover:bg-blue-700' :
                            item.type === 'trade' ? 'bg-purple-600 hover:bg-purple-700' :
                            'bg-orange-600 hover:bg-orange-700'
                          }`}
                          size="sm"
                        >
                          {item.type === 'sell' ? 'Buy Now' :
                           item.type === 'buy_request' ? 'I Have This' :
                           item.type === 'trade' ? 'Propose Trade' :
                           'Join Group'}
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-gray-400 hover:text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            startChat(item.seller, item);
                          }}
                        >
                          <MessageSquare className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-gray-400 hover:text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            checkFraud(item);
                          }}
                        >
                          <Shield className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Restaurant Content */}
          {(selectedCategory === 'all' || selectedCategory === 'restaurants') && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Utensils className="w-6 h-6 text-orange-400" />
                  Trending Restaurants
                </h2>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                  View All
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {mockRestaurants.map((restaurant) => (
                  <Card key={restaurant.id} className="bg-gray-800/60 border-gray-600 hover:bg-gray-800/80 transition-all duration-300 backdrop-blur-sm group">
                    <CardHeader className="pb-3">
                      <div className="relative">
                        <ImageWithFallback
                          src={restaurant.image} 
                          alt={restaurant.name}
                          className="w-full h-48 object-cover rounded-lg"
                          width={400}
                          height={192}
                        />
                        <Badge className="absolute top-2 left-2 bg-black/60 text-white">
                          {restaurant.priceRange}
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="absolute top-2 right-2 text-white hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Heart className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>

                    <CardContent>
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-white text-lg">{restaurant.name}</h3>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          <span className="text-sm text-gray-400">{restaurant.rating}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 mb-3">
                        <Badge variant="secondary" className="text-xs">{restaurant.cuisine}</Badge>
                        <Badge variant="outline" className="text-xs">{restaurant.distance}</Badge>
                      </div>

                      <div className="space-y-2 mb-3">
                        <p className="text-sm text-gray-400">Specialties: {restaurant.specialties.join(', ')}</p>
                        <p className="text-sm text-gray-400">Best for: {restaurant.bestFor.join(', ')}</p>
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-400 mb-3">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <Heart className="w-4 h-4" />
                            <span>{restaurant.likes}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageCircle className="w-4 h-4" />
                            <span>{restaurant.reviews}</span>
                          </div>
                        </div>
                        <span className="text-xs">{restaurant.timestamp}</span>
                      </div>

                      <div className="flex gap-2">
                        <Button className="flex-1 bg-orange-600 hover:bg-orange-700" size="sm">
                          Order Now
                        </Button>
                        <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                          <Calendar className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Travel Content */}
          {(selectedCategory === 'all' || selectedCategory === 'travel') && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Plane className="w-6 h-6 text-blue-400" />
                  Active Group Plans
                </h2>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                  View All
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {mockTravelItems.map((trip) => (
                  <Card key={trip.id} className="bg-gray-800/60 border-gray-600 hover:bg-gray-800/80 transition-all duration-300 backdrop-blur-sm group">
                    <CardHeader className="pb-3">
                      <div className="relative">
                        <ImageWithFallback
                          src={trip.image} 
                          alt={trip.destination}
                          className="w-full h-48 object-cover rounded-lg"
                          width={400}
                          height={192}
                        />
                        <Badge className="absolute top-2 left-2 bg-black/60 text-white">
                          {trip.participants}/{trip.maxParticipants} joined
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="absolute top-2 right-2 text-white hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Heart className="w-4 h-4" />
                        </Button>
                      </div>
                      
                      <div className="flex items-center gap-2 mt-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={trip.organizer.avatar} alt={trip.organizer.name} />
                          <AvatarFallback className="text-xs">{trip.organizer.name.slice(0, 2)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium text-white">{trip.organizer.name}</p>
                          <p className="text-xs text-gray-400">Trip Organizer</p>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent>
                      <h3 className="font-semibold text-white text-lg mb-2">{trip.destination}</h3>
                      
                      <div className="flex items-center gap-4 mb-3">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-400">{trip.duration}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <DollarSign className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-400">${trip.estimatedCost}</span>
                        </div>
                      </div>

                      <div className="space-y-2 mb-3">
                        <p className="text-sm text-gray-400">Highlights: {trip.highlights.join(', ')}</p>
                        <p className="text-sm text-gray-400">Difficulty: {trip.difficulty}</p>
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-400 mb-3">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <Heart className="w-4 h-4" />
                            <span>{trip.likes}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageCircle className="w-4 h-4" />
                            <span>{trip.comments}</span>
                          </div>
                        </div>
                        <span className="text-xs">{trip.timestamp}</span>
                      </div>

                      <div className="flex gap-2">
                        <Button 
                          className="flex-1 bg-blue-600 hover:bg-blue-700" 
                          size="sm"
                          onClick={() => window.location.href = '/group-trip-planning'}
                        >
                          Join Trip
                        </Button>
                        <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                          <MessageSquare className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* AI Profile Analysis Modal */}
      <Dialog open={showProfileModal} onOpenChange={setShowProfileModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gray-800 border-gray-600">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-white flex items-center gap-2">
              <Bot className="w-5 h-5 text-purple-400" />
              AI Profile Analysis: {selectedProfile?.name}
            </DialogTitle>
          </DialogHeader>
          
          {selectedProfile && (
            <div className="space-y-6">
              {/* Profile Overview */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-gray-700/50 border-gray-600">
                  <CardHeader className="pb-3">
                    <h3 className="text-lg font-semibold text-white">Profile Overview</h3>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="relative">
                        <Avatar className="w-16 h-16 ring-2 ring-purple-400/50">
                          <AvatarImage src={selectedProfile.seller?.avatar} />
                          <AvatarFallback>{selectedProfile.name.slice(0, 2)}</AvatarFallback>
                        </Avatar>
                        <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-gray-700 ${selectedProfile.status === 'online' ? 'bg-green-400' : 'bg-gray-400'}`}></div>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-lg font-bold text-white">{selectedProfile.name}</h4>
                          {selectedProfile.seller?.verified && <UserCheck className="w-4 h-4 text-blue-400" />}
                        </div>
                        <p className="text-sm text-gray-400">@{selectedProfile.seller?.username}</p>
                        <p className="text-sm text-gray-400">{selectedProfile.seller?.location}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-xs text-gray-400">Rating</p>
                        <p className="text-lg font-bold text-yellow-400">{selectedProfile.engagement.rating} ⭐</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Total Sales</p>
                        <p className="text-lg font-bold text-green-400">{selectedProfile.seller?.totalSales}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Response Time</p>
                        <p className="text-sm text-white">{selectedProfile.seller?.responseTime}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Member Since</p>
                        <p className="text-sm text-white">{selectedProfile.seller?.joinedDate}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-700/50 border-gray-600">
                  <CardHeader className="pb-3">
                    <h3 className="text-lg font-semibold text-white">Current Activity</h3>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-800/60 rounded-lg p-4 mb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse"></div>
                        <span className="text-sm font-medium text-blue-400">Live Now</span>
                      </div>
                      <p className="text-white font-medium mb-1">{selectedProfile.activity}</p>
                      <p className="text-sm text-gray-400">{selectedProfile.currentAction}</p>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-3">
                      <div className="bg-gray-800/40 rounded-lg p-3 text-center">
                        <p className="text-lg font-bold text-white">{selectedProfile.engagement.views}</p>
                        <p className="text-xs text-gray-400">Profile Views</p>
                      </div>
                      <div className="bg-gray-800/40 rounded-lg p-3 text-center">
                        <p className="text-lg font-bold text-white">{selectedProfile.engagement.inquiries}</p>
                        <p className="text-xs text-gray-400">Inquiries</p>
                      </div>
                      <div className="bg-gray-800/40 rounded-lg p-3 text-center">
                        <p className="text-lg font-bold text-white">2</p>
                        <p className="text-xs text-gray-400">Mutual Friends</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* AI Analysis Sections */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-gradient-to-br from-purple-600/10 to-pink-600/10 border-purple-600/30">
                  <CardHeader className="pb-3">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                      <Bot className="w-5 h-5 text-purple-400" />
                      AI Behavioral Analysis
                    </h3>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-purple-400 mb-2">Trading Pattern</h4>
                      <p className="text-sm text-gray-300">{selectedProfile.aiInsight}</p>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-purple-400 mb-2">Reliability Score</h4>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-700 rounded-full h-2">
                          <div className="bg-green-400 h-2 rounded-full" style={{ width: '95%' }}></div>
                        </div>
                        <span className="text-sm text-green-400">95%</span>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-purple-400 mb-2">Negotiation Style</h4>
                      <Badge className="bg-blue-600 text-white">Fair & Flexible</Badge>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-purple-400 mb-2">Communication</h4>
                      <div className="flex gap-2">
                        <Badge variant="secondary" className="bg-gray-600">Responsive</Badge>
                        <Badge variant="secondary" className="bg-gray-600">Detailed</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-cyan-600/10 to-blue-600/10 border-cyan-600/30">
                  <CardHeader className="pb-3">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-cyan-400" />
                      Market Intelligence
                    </h3>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-cyan-400 mb-2">Price Analysis</h4>
                      <p className="text-sm text-gray-300">Typically prices items 8-12% below market rate for quick sales</p>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-cyan-400 mb-2">Success Rate</h4>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-700 rounded-full h-2">
                          <div className="bg-cyan-400 h-2 rounded-full" style={{ width: '88%' }}></div>
                        </div>
                        <span className="text-sm text-cyan-400">88%</span>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-cyan-400 mb-2">Specialization</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedProfile.interests.map((interest: string) => (
                          <Badge key={interest} variant="secondary" className="bg-cyan-600/20 text-cyan-300">
                            {interest}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-cyan-400 mb-2">Best Time to Contact</h4>
                      <p className="text-sm text-gray-300">Weekdays 9AM-6PM PST, typically responds within 1 hour</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Collaboration Opportunities */}
              <Card className="bg-gradient-to-br from-green-600/10 to-emerald-600/10 border-green-600/30">
                <CardHeader className="pb-3">
                  <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                    <Handshake className="w-5 h-5 text-green-400" />
                    Collaboration Opportunities
                  </h3>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-800/40 rounded-lg p-4">
                      <h4 className="text-sm font-medium text-green-400 mb-2">Joint Purchases</h4>
                      <p className="text-sm text-gray-300">High compatibility for bulk buying photography equipment</p>
                      <Badge className="mt-2 bg-green-600 text-white">Recommended</Badge>
                    </div>
                    
                    <div className="bg-gray-800/40 rounded-lg p-4">
                      <h4 className="text-sm font-medium text-green-400 mb-2">Trading Potential</h4>
                      <p className="text-sm text-gray-300">Strong match for equipment exchanges in photography domain</p>
                      <Badge className="mt-2 bg-yellow-600 text-white">Moderate</Badge>
                    </div>
                    
                    <div className="bg-gray-800/40 rounded-lg p-4">
                      <h4 className="text-sm font-medium text-green-400 mb-2">Group Activities</h4>
                      <p className="text-sm text-gray-300">Excellent organizer for photography workshops and trips</p>
                      <Badge className="mt-2 bg-green-600 text-white">High Match</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <Button 
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={() => {
                    if (selectedProfile?.seller) {
                      // Create a mock item for the conversation
                      const mockItem: MarketplaceItem = {
                        id: `profile-chat-${selectedProfile.seller.id}`,
                        type: 'sell',
                        seller: selectedProfile.seller,
                        title: selectedProfile.activity || 'General Chat',
                        description: selectedProfile.currentAction || 'Starting a conversation',
                        images: ['https://images.unsplash.com/photo-1606983340126-99ab4feaa64d?w=400&h=300&fit=crop'],
                        price: 0,
                        condition: 'like_new',
                        category: 'General',
                        subcategory: 'General',
                        likes: selectedProfile.engagement?.views || 0,
                        comments: selectedProfile.engagement?.inquiries || 0,
                        watchers: 10,
                        timestamp: selectedProfile.time || 'now',
                        location: selectedProfile.seller.location || 'Local',
                        tags: selectedProfile.interests || [],
                        negotiable: true,
                        shipping: { available: true, cost: 0, methods: ['Local'] },
                        aiInsights: {
                          priceScore: 8,
                          demandLevel: 'medium' as const,
                          similarItems: 5,
                          suggestedPrice: 0,
                          marketTrend: 'stable' as const,
                          quickSaleChance: 75
                        },
                        socialProof: {
                          views: selectedProfile.engagement?.views || 0,
                          watchers: 10,
                          inquiries: selectedProfile.engagement?.inquiries || 0,
                          nearbyInterest: 20
                        }
                      };
                      setShowProfileModal(false);
                      startChat(selectedProfile.seller, mockItem);
                    }
                  }}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Start Conversation
                </Button>
                <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white">
                  <Handshake className="w-4 h-4 mr-2" />
                  Propose Collaboration
                </Button>
                <Button variant="outline" className="border-gray-600 text-gray-300 hover:text-white">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Profile
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Chat Modal */}
      <Dialog open={showChatModal} onOpenChange={setShowChatModal}>
        <DialogContent className="max-w-2xl h-[600px] bg-gray-900 text-white border-gray-700">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={chatSeller?.avatar} />
                <AvatarFallback>{chatSeller?.name?.slice(0, 2)}</AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-semibold">{chatSeller?.name}</h3>
                  {chatSeller?.verified && <UserCheck className="w-4 h-4 text-blue-400" />}
                </div>
                <p className="text-sm text-gray-400">
                  {chatItem?.title} • ${chatItem?.price}
                </p>
              </div>
              <div className="ml-auto flex items-center gap-2">
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                  <Phone className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                  <Video className="w-4 h-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-gray-400 hover:text-white"
                  onClick={() => setShowChatModal(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </DialogTitle>
          </DialogHeader>
          
          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-800/30 rounded-lg">
            {chatMessages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className="flex items-start gap-2 max-w-[80%]">
                  {message.sender === 'seller' && (
                    <Avatar className="w-6 h-6 mt-1">
                      <AvatarImage src={chatSeller?.avatar} />
                      <AvatarFallback className="text-xs">{chatSeller?.name?.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                  )}
                  <div
                    className={`p-3 rounded-lg ${
                      message.sender === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-700 text-gray-100'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            
            {/* Typing Indicator */}
            {isSellerTyping && (
              <div className="flex justify-start">
                <div className="flex items-start gap-2 max-w-[80%]">
                  <Avatar className="w-6 h-6 mt-1">
                    <AvatarImage src={chatSeller?.avatar} />
                    <AvatarFallback className="text-xs">{chatSeller?.name?.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="bg-gray-700 text-gray-100 p-3 rounded-lg">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
          
          {/* Chat Input */}
          <div className="flex gap-2 p-4 border-t border-gray-700">
            <Textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-400 resize-none min-h-[44px] max-h-32"
              rows={1}
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage(newMessage);
                }
              }}
            />
            <Button
              onClick={() => sendMessage(newMessage)}
              disabled={!newMessage.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Fraud Detection Modal */}
      <Dialog open={showFraudModal} onOpenChange={setShowFraudModal}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Fraud Detection Analysis
            </DialogTitle>
          </DialogHeader>
          
          {fraudAnalysisResult && (
            <div className="space-y-6">
              {/* Item Info */}
              <div className="flex items-center gap-3 p-3 bg-gray-700/50 rounded-lg">
                <ImageWithFallback
                  src={fraudCheckItem?.images[0] || ''} 
                  alt={fraudCheckItem?.title || 'Item'}
                  className="w-16 h-16 object-cover rounded-lg"
                  width={64}
                  height={64}
                />
                <div>
                  <h3 className="font-semibold">{fraudCheckItem?.title}</h3>
                  <p className="text-gray-400">${fraudCheckItem?.price} • {fraudCheckItem?.seller.name}</p>
                </div>
              </div>

              {/* Overall Status */}
              <div className={`p-4 rounded-lg border-2 ${
                fraudAnalysisResult.status === 'safe' 
                  ? 'bg-green-900/20 border-green-500' 
                  : 'bg-red-900/20 border-red-500'
              }`}>
                <div className="flex items-center gap-3 mb-2">
                  {fraudAnalysisResult.status === 'safe' ? (
                    <CheckCircle className="w-6 h-6 text-green-400" />
                  ) : (
                    <AlertTriangle className="w-6 h-6 text-red-400" />
                  )}
                  <div>
                    <h3 className={`font-bold text-lg ${
                      fraudAnalysisResult.status === 'safe' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {fraudAnalysisResult.status === 'safe' ? 'VERIFIED SAFE' : 'POTENTIAL FRAUD'}
                    </h3>
                    <p className="text-sm text-gray-300">
                      Safety Score: {fraudAnalysisResult.score}/100
                    </p>
                  </div>
                </div>
                <p className={`text-sm ${
                  fraudAnalysisResult.status === 'safe' ? 'text-green-200' : 'text-red-200'
                }`}>
                  {fraudAnalysisResult.recommendation}
                </p>
              </div>

              {/* Detailed Checks */}
              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Security Checks
                </h4>
                
                <div className="grid grid-cols-1 gap-3">
                  {Object.entries(fraudAnalysisResult.checks).map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center p-3 bg-gray-700/30 rounded-lg">
                      <span className="text-gray-300 capitalize">
                        {key.replace(/([A-Z])/g, ' $1').trim()}:
                      </span>
                      <span className={`font-medium ${
                        typeof value === 'string' && (
                          value.toLowerCase().includes('excellent') || 
                          value.toLowerCase().includes('good') ||
                          value.toLowerCase().includes('normal') ||
                          value.toLowerCase().includes('verified') ||
                          value.toLowerCase().includes('original')
                        ) ? 'text-green-400' : 
                        typeof value === 'string' && (
                          value.toLowerCase().includes('suspicious') ||
                          value.toLowerCase().includes('new account') ||
                          value.toLowerCase().includes('stolen') ||
                          value.toLowerCase().includes('below market')
                        ) ? 'text-red-400' : 'text-yellow-400'
                      }`}>
                        {value as string}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Risk Factors */}
              {fraudAnalysisResult.riskFactors.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold flex items-center gap-2 text-red-400">
                    <AlertTriangle className="w-4 h-4" />
                    Risk Factors Detected
                  </h4>
                  <ul className="space-y-1">
                    {fraudAnalysisResult.riskFactors.map((risk: string, index: number) => (
                      <li key={index} className="flex items-start gap-2 text-sm text-red-200">
                        <span className="text-red-400 mt-1">•</span>
                        {risk}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                {fraudAnalysisResult.status === 'safe' ? (
                  <>
                    <Button 
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => setShowFraudModal(false)}
                    >
                      Proceed with Confidence
                    </Button>
                    <Button 
                      variant="outline" 
                      className="border-gray-600 text-gray-300"
                      onClick={() => setShowFraudModal(false)}
                    >
                      Cancel
                    </Button>
                  </>
                ) : (
                  <>
                    <Button 
                      variant="outline" 
                      className="flex-1 border-yellow-500 text-yellow-400 hover:bg-yellow-500/10"
                      onClick={() => setShowFraudModal(false)}
                    >
                      Proceed with Caution
                    </Button>
                    <Button 
                      className="flex-1 bg-red-600 hover:bg-red-700"
                      onClick={() => setShowFraudModal(false)}
                    >
                      Avoid This Listing
                    </Button>
                  </>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* AI Agent Bubble - Bottom Right */}
      <div className="fixed bottom-6 right-6 z-50">
        {!showAIAgent ? (
          <Button
            onClick={analyzeWithAI}
            className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg hover:shadow-xl transition-all duration-300 relative group"
            disabled={isAnalyzing}
          >
            {isAnalyzing ? (
              <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Brain className="w-8 h-8 text-white" />
            )}
            {/* Pulse Animation */}
            <div className="absolute inset-0 rounded-full bg-purple-600 animate-ping opacity-20"></div>
            
            {/* Tooltip */}
            <div className="absolute bottom-full right-0 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              <div className="bg-gray-800 text-white text-sm px-3 py-2 rounded-lg whitespace-nowrap shadow-lg">
                AI Analysis & Recommendations
                <div className="absolute top-full right-4 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-800"></div>
              </div>
            </div>
          </Button>
        ) : (
          <Card className={`bg-gray-800 border-gray-600 shadow-2xl transition-all duration-300 ${
            agentExpanded ? 'w-96 h-[600px]' : 'w-80 h-20'
          }`}>
            <CardHeader className="p-4 border-b border-gray-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center">
                    <Brain className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-sm">AI Agent</h3>
                    <p className="text-xs text-gray-400">
                      {isAnalyzing ? 'Analyzing...' : 'Analysis Complete'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setAgentExpanded(!agentExpanded)}
                    className="text-gray-400 hover:text-white p-1"
                  >
                    {agentExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowAIAgent(false)}
                    className="text-gray-400 hover:text-white p-1"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            {agentExpanded && aiRecommendations && (
              <CardContent className="p-4 overflow-y-auto flex-1">
                <div className="space-y-4">
                  {/* Marketplace Recommendations */}
                  {aiRecommendations.marketplaceRecommendations && (
                    <div>
                      <h4 className="font-semibold text-white flex items-center gap-2 mb-2">
                        <ShoppingCart className="w-4 h-4 text-green-400" />
                        Marketplace Picks
                      </h4>
                      {aiRecommendations.marketplaceRecommendations.map((rec: any, idx: number) => (
                        <div key={idx} className="bg-gray-700/50 rounded-lg p-3 mb-2">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-white text-sm">{rec.item}</span>
                            <Badge className="bg-green-600 text-white text-xs">{rec.confidence}%</Badge>
                          </div>
                          <p className="text-xs text-gray-300">{rec.reason}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Restaurant Recommendations */}
                  {aiRecommendations.restaurantRecommendations && (
                    <div>
                      <h4 className="font-semibold text-white flex items-center gap-2 mb-2">
                        <Utensils className="w-4 h-4 text-orange-400" />
                        Dining Spots
                      </h4>
                      {aiRecommendations.restaurantRecommendations.map((rec: any, idx: number) => (
                        <div key={idx} className="bg-gray-700/50 rounded-lg p-3 mb-2">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-white text-sm">{rec.restaurant}</span>
                            <Badge className="bg-orange-600 text-white text-xs">{rec.confidence}%</Badge>
                          </div>
                          <p className="text-xs text-gray-300">{rec.reason}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Travel Recommendations */}
                  {aiRecommendations.travelRecommendations && (
                    <div>
                      <h4 className="font-semibold text-white flex items-center gap-2 mb-2">
                        <Plane className="w-4 h-4 text-blue-400" />
                        Travel Ideas
                      </h4>
                      {aiRecommendations.travelRecommendations.map((rec: any, idx: number) => (
                        <div key={idx} className="bg-gray-700/50 rounded-lg p-3 mb-2">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-white text-sm">{rec.destination}</span>
                            <Badge className="bg-blue-600 text-white text-xs">{rec.confidence}%</Badge>
                          </div>
                          <p className="text-xs text-gray-300">{rec.reason}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Group Suggestions */}
                  {aiRecommendations.groupSuggestions && (
                    <div>
                      <h4 className="font-semibold text-white flex items-center gap-2 mb-2">
                        <Users className="w-4 h-4 text-purple-400" />
                        Groups to Join
                      </h4>
                      {aiRecommendations.groupSuggestions.map((rec: any, idx: number) => (
                        <div key={idx} className="bg-gray-700/50 rounded-lg p-3 mb-2">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-white text-sm">{rec.group}</span>
                            <Badge className="bg-purple-600 text-white text-xs">{rec.confidence}%</Badge>
                          </div>
                          <p className="text-xs text-gray-400 mb-1">{rec.activity}</p>
                          <p className="text-xs text-gray-300">{rec.reason}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* AI Insights */}
                  {aiRecommendations.insights && (
                    <div>
                      <h4 className="font-semibold text-white flex items-center gap-2 mb-2">
                        <Sparkles className="w-4 h-4 text-yellow-400" />
                        AI Insights
                      </h4>
                      <div className="bg-gray-700/50 rounded-lg p-3 space-y-2">
                        {aiRecommendations.insights.behaviorPattern && (
                          <div>
                            <span className="text-xs font-medium text-yellow-400">Behavior Pattern:</span>
                            <p className="text-xs text-gray-300">{aiRecommendations.insights.behaviorPattern}</p>
                          </div>
                        )}
                        {aiRecommendations.insights.budgetOptimization && (
                          <div>
                            <span className="text-xs font-medium text-green-400">Budget Tip:</span>
                            <p className="text-xs text-gray-300">{aiRecommendations.insights.budgetOptimization}</p>
                          </div>
                        )}
                        {aiRecommendations.insights.socialRecommendations && (
                          <div>
                            <span className="text-xs font-medium text-blue-400">Social Tip:</span>
                            <p className="text-xs text-gray-300">{aiRecommendations.insights.socialRecommendations}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Action Button */}
                  <Button
                    onClick={analyzeWithAI}
                    disabled={isAnalyzing}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                  >
                    {isAnalyzing ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        Analyzing...
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Target className="w-4 h-4" />
                        Refresh Analysis
                      </div>
                    )}
                  </Button>
                </div>
              </CardContent>
            )}
          </Card>
        )}
      </div>
    </div>
  );
}