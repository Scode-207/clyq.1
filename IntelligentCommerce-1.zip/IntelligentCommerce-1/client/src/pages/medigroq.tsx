import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Upload, Send, Paperclip, Stethoscope, ArrowLeft, Bot, User as UserIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface MedicalMessage {
  id: number;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  type?: "text" | "image" | "file";
  fileName?: string;
  suggestions?: Array<{
    type: "facility" | "medication" | "action";
    title: string;
    description: string;
    data: any;
  }>;
}

export default function MediGroq() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  
  const [messages, setMessages] = useState<MedicalMessage[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Send message mutation using Gemini medical service
  const sendMessageMutation = useMutation({
    mutationFn: async ({ message, file }: { message: string; file?: File }) => {
      const formData = new FormData();
      formData.append('message', message);
      if (file) {
        formData.append('file', file);
      }

      const response = await fetch('/api/medigroq/chat', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('Failed to send message');
      return response.json();
    },
    onMutate: ({ message, file }) => {
      // Add user message immediately
      const userMessage: MedicalMessage = {
        id: Date.now(),
        role: "user",
        content: message,
        timestamp: new Date().toISOString(),
        type: file ? (file.type.startsWith('image/') ? 'image' : 'file') : 'text',
        fileName: file?.name
      };
      setMessages(prev => [...prev, userMessage]);
      setIsTyping(true);
      setInputMessage("");
      setUploadedFile(null);
    },
    onSuccess: (response) => {
      // Add AI response
      const aiMessage: MedicalMessage = {
        id: Date.now() + 1,
        role: "assistant",
        content: response.content,
        timestamp: new Date().toISOString(),
        suggestions: response.suggestions || []
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    },
    onError: (error) => {
      setIsTyping(false);
      toast({
        title: "Message Failed",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      toast({
        title: "File Selected",
        description: `${file.name} ready for analysis`,
      });
    }
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim() && !uploadedFile) return;
    
    sendMessageMutation.mutate({ 
      message: inputMessage || "Please analyze this file", 
      file: uploadedFile || undefined 
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const removeUploadedFile = () => {
    setUploadedFile(null);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white flex flex-col">
      {/* Header */}
      <div className="border-b border-gray-800/50 bg-[#0D0D0D] p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              className="text-gray-400 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Stethoscope className="h-6 w-6 text-blue-400" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">MediGroq</h1>
                <p className="text-sm text-gray-400">AI Medical Assistant</p>
              </div>
            </div>
          </div>
          <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
            Powered by Gemini AI
          </Badge>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 max-w-4xl mx-auto w-full flex flex-col">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.length === 0 && (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-500/20 rounded-full mb-4">
                <Stethoscope className="h-8 w-8 text-blue-400" />
              </div>
              <h2 className="text-xl font-semibold text-white mb-2">Welcome to MediGroq</h2>
              <p className="text-gray-400 mb-6">Your AI-powered medical assistant for prescriptions, facilities, and health information.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-lg mx-auto">
                <Button
                  variant="outline"
                  className="bg-gray-800/50 border-gray-700 text-gray-300 hover:bg-gray-700"
                  onClick={() => setInputMessage("Find hospitals near me")}
                >
                  Find Medical Facilities
                </Button>
                <Button
                  variant="outline"
                  className="bg-gray-800/50 border-gray-700 text-gray-300 hover:bg-gray-700"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Analyze Prescription
                </Button>
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div key={message.id} className={`flex gap-4 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              {message.role === 'assistant' && (
                <Avatar className="w-8 h-8 flex-shrink-0">
                  <AvatarFallback className="bg-blue-500/20 text-blue-400">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
              )}
              
              <div className={`max-w-3xl ${message.role === 'user' ? 'order-2' : ''}`}>
                <div className={`rounded-2xl p-4 ${
                  message.role === 'user' 
                    ? 'bg-blue-500/20 text-white ml-12' 
                    : 'bg-gray-800/50 text-gray-100'
                }`}>
                  {message.type === 'image' && (
                    <div className="mb-2">
                      <Badge variant="outline" className="text-xs">Image: {message.fileName}</Badge>
                    </div>
                  )}
                  {message.type === 'file' && (
                    <div className="mb-2">
                      <Badge variant="outline" className="text-xs">File: {message.fileName}</Badge>
                    </div>
                  )}
                  
                  <div className="prose prose-invert max-w-none">
                    {message.content.split('\n').map((line, index) => (
                      <p key={index} className="mb-2 last:mb-0">{line}</p>
                    ))}
                  </div>

                  {message.suggestions && message.suggestions.length > 0 && (
                    <div className="mt-4 space-y-2">
                      <p className="text-sm font-medium text-gray-300">Suggestions:</p>
                      <div className="grid gap-2">
                        {message.suggestions.map((suggestion, index) => (
                          <Card key={index} className="bg-gray-700/50 border-gray-600">
                            <CardContent className="p-3">
                              <h4 className="font-medium text-white text-sm">{suggestion.title}</h4>
                              <p className="text-gray-300 text-xs">{suggestion.description}</p>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="text-xs text-gray-500 mt-1 px-4">
                  {new Date(message.timestamp).toLocaleTimeString()}
                </div>
              </div>

              {message.role === 'user' && (
                <Avatar className="w-8 h-8 flex-shrink-0 order-3">
                  <AvatarFallback className="bg-gray-700 text-gray-300">
                    <UserIcon className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-4">
              <Avatar className="w-8 h-8 flex-shrink-0">
                <AvatarFallback className="bg-blue-500/20 text-blue-400">
                  <Bot className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div className="bg-gray-800/50 rounded-2xl p-4">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t border-gray-800/50 bg-[#0D0D0D] p-4">
          <div className="space-y-3">
            {/* File Upload Preview */}
            {uploadedFile && (
              <div className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
                <Paperclip className="h-4 w-4 text-gray-400" />
                <span className="text-sm text-gray-300 flex-1">{uploadedFile.name}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={removeUploadedFile}
                  className="text-gray-400 hover:text-white h-6 w-6 p-0"
                >
                  ×
                </Button>
              </div>
            )}

            {/* Input Row */}
            <div className="flex gap-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.pdf"
                onChange={handleFileUpload}
                className="hidden"
              />
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                className="bg-gray-800/50 border-gray-700 text-gray-300 hover:bg-gray-700 px-3"
              >
                <Upload className="h-4 w-4" />
              </Button>

              <Textarea
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about medical facilities, upload prescriptions, or get health information..."
                className="flex-1 min-h-[44px] max-h-32 bg-gray-800/50 border-gray-700 text-white placeholder-gray-400 resize-none"
                rows={1}
              />

              <Button
                onClick={handleSendMessage}
                disabled={(!inputMessage.trim() && !uploadedFile) || sendMessageMutation.isPending}
                className="bg-blue-500 hover:bg-blue-600 text-white px-4"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>

            {/* Medical Disclaimer */}
            <div className="text-xs text-gray-500 text-center">
              Medical information is for reference only. Always consult healthcare professionals for medical decisions.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}