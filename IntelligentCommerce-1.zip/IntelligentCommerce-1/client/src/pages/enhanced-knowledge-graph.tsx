import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Brain, TrendingUp, Clock, ShoppingBag, User, Activity, BarChart3, 
  Target, Zap, Calendar, MapPin, Smartphone, Monitor, Globe, 
  ArrowLeft, RotateCcw, Download, Filter, Search, Eye, Heart, 
  MessageCircle, Star, Award, Sparkles, Network, Database,
  LineChart, PieChart, TimerIcon, Users, ShoppingCart, Shield
} from "lucide-react";
import { useLocation } from "wouter";

interface UserInsights {
  preferences: Array<{
    id: number;
    category: string;
    preference: string;
    strength: number;
    source: string;
    lastUpdated: string;
  }>;
  patterns: Array<{
    id: number;
    patternType: string;
    patternData: any;
    confidence: number;
    lastCalculated: string;
  }>;
  recentActivity: Array<{
    id: number;
    action: string;
    entityType: string;
    entityName: string;
    metadata: any;
    timestamp: string;
  }>;
  stats: {
    totalInteractions: number;
    uniqueCategories: number;
    avgSessionLength: number;
    totalSessions: number;
  };
}

export default function EnhancedKnowledgeGraph() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('overview');
  const [timeFilter, setTimeFilter] = useState('30d');
  
  const { data: insights, isLoading, refetch } = useQuery<UserInsights>({
    queryKey: ['/api/knowledge-graph/insights', timeFilter],
    refetchInterval: 30000, // Refresh every 30 seconds for real-time data
  });

  // Mock data for demonstration while real data builds up
  const mockInsights: UserInsights = {
    preferences: [
      { id: 1, category: 'product_category', preference: 'Electronics', strength: 8.5, source: 'implicit', lastUpdated: new Date().toISOString() },
      { id: 2, category: 'brand', preference: 'Nike', strength: 7.2, source: 'explicit', lastUpdated: new Date().toISOString() },
      { id: 3, category: 'price_range', preference: 'mid-range', strength: 6.8, source: 'implicit', lastUpdated: new Date().toISOString() },
      { id: 4, category: 'product_category', preference: 'Fashion', strength: 5.9, source: 'implicit', lastUpdated: new Date().toISOString() },
      { id: 5, category: 'brand', preference: 'Apple', strength: 9.1, source: 'explicit', lastUpdated: new Date().toISOString() },
      { id: 6, category: 'time_preference', preference: 'evening', strength: 7.5, source: 'implicit', lastUpdated: new Date().toISOString() },
    ],
    patterns: [
      { 
        id: 1, 
        patternType: 'category_affinity', 
        patternData: { 
          categories: [
            { category: 'Electronics', count: 45 },
            { category: 'Fashion', count: 23 },
            { category: 'Home & Garden', count: 12 }
          ],
          dominantCategory: 'Electronics'
        }, 
        confidence: 0.85, 
        lastCalculated: new Date().toISOString() 
      },
      { 
        id: 2, 
        patternType: 'time_preference', 
        patternData: { 
          peakHours: [
            { hour: 19, count: 25 },
            { hour: 20, count: 30 },
            { hour: 21, count: 22 }
          ]
        }, 
        confidence: 0.78, 
        lastCalculated: new Date().toISOString() 
      },
      { 
        id: 3, 
        patternType: 'price_sensitivity', 
        patternData: { 
          averagePrice: 85,
          priceVariability: 45
        }, 
        confidence: 0.72, 
        lastCalculated: new Date().toISOString() 
      },
    ],
    recentActivity: [
      { id: 1, action: 'view', entityType: 'product', entityName: 'iPhone 15 Pro', metadata: { category: 'Electronics', price: 999 }, timestamp: new Date().toISOString() },
      { id: 2, action: 'like', entityType: 'product', entityName: 'Nike Air Max', metadata: { category: 'Fashion', price: 120 }, timestamp: new Date(Date.now() - 300000).toISOString() },
      { id: 3, action: 'search', entityType: 'query', entityName: 'sustainable outdoor gear', metadata: { category: 'Sports' }, timestamp: new Date(Date.now() - 600000).toISOString() },
      { id: 4, action: 'chat', entityType: 'conversation', entityName: 'AI Assistant Chat', metadata: { domain: 'marketplace' }, timestamp: new Date(Date.now() - 900000).toISOString() },
      { id: 5, action: 'view', entityType: 'product', entityName: 'MacBook Pro 16"', metadata: { category: 'Electronics', price: 2499 }, timestamp: new Date(Date.now() - 1200000).toISOString() },
    ],
    stats: {
      totalInteractions: 127,
      uniqueCategories: 8,
      avgSessionLength: 480, // 8 minutes
      totalSessions: 23
    }
  };

  // Use real data if available, otherwise use mock data for demonstration
  const displayData = insights && insights.preferences.length > 0 ? insights : mockInsights;

  const formatDuration = (seconds: number) => {
    if (!seconds) return '0m';
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    return `${minutes}m`;
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'product_category': return <ShoppingBag className="w-4 h-4" />;
      case 'brand': return <Award className="w-4 h-4" />;
      case 'price_range': return <Target className="w-4 h-4" />;
      case 'time_preference': return <Clock className="w-4 h-4" />;
      default: return <Brain className="w-4 h-4" />;
    }
  };

  const getPatternIcon = (patternType: string) => {
    switch (patternType) {
      case 'category_affinity': return <TrendingUp className="w-4 h-4 text-blue-400" />;
      case 'time_preference': return <Clock className="w-4 h-4 text-green-400" />;
      case 'price_sensitivity': return <Target className="w-4 h-4 text-purple-400" />;
      case 'brand_loyalty': return <Award className="w-4 h-4 text-orange-400" />;
      default: return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'view': return <Eye className="w-4 h-4 text-blue-400" />;
      case 'like': return <Heart className="w-4 h-4 text-red-400" />;
      case 'comment': return <MessageCircle className="w-4 h-4 text-green-400" />;
      case 'search': return <Search className="w-4 h-4 text-purple-400" />;
      case 'purchase': return <ShoppingCart className="w-4 h-4 text-orange-400" />;
      case 'chat': return <MessageCircle className="w-4 h-4 text-indigo-400" />;
      case 'fraud_check': return <Shield className="w-4 h-4 text-yellow-400" />;
      case 'ai_analyze': return <Brain className="w-4 h-4 text-pink-400" />;
      default: return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white text-lg">Analyzing your interaction patterns...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <div className="bg-gray-800/60 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation('/')}
                className="text-gray-400 hover:text-white hover:bg-gray-700"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Network className="w-6 h-6 text-purple-400" />
                  Knowledge Graph Analytics
                </h1>
                <p className="text-gray-400 text-sm">Real-time insights from your platform interactions</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <select 
                value={timeFilter}
                onChange={(e) => setTimeFilter(e.target.value)}
                className="bg-gray-700 text-white border border-gray-600 rounded-md px-3 py-1 text-sm"
              >
                <option value="7d">Last 7 days</option>
                <option value="30d">Last 30 days</option>
                <option value="90d">Last 90 days</option>
                <option value="all">All time</option>
              </select>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => refetch()}
                className="border-gray-600 text-gray-300 hover:text-white"
              >
                <RotateCcw className="w-4 h-4 mr-1" />
                Refresh
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="border-gray-600 text-gray-300 hover:text-white"
              >
                <Download className="w-4 h-4 mr-1" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-800/60 border-gray-600">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Total Interactions</p>
                  <p className="text-2xl font-bold text-white">{displayData?.stats.totalInteractions || 0}</p>
                </div>
                <Activity className="w-8 h-8 text-blue-400" />
              </div>
              <div className="mt-2">
                <Badge variant="secondary" className="text-xs">
                  +12% vs last period
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/60 border-gray-600">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Categories Explored</p>
                  <p className="text-2xl font-bold text-white">{displayData?.stats.uniqueCategories || 0}</p>
                </div>
                <BarChart3 className="w-8 h-8 text-green-400" />
              </div>
              <div className="mt-2">
                <Badge variant="secondary" className="text-xs">
                  Diverse interests
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/60 border-gray-600">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Avg Session</p>
                  <p className="text-2xl font-bold text-white">
                    {formatDuration(displayData?.stats.avgSessionLength || 0)}
                  </p>
                </div>
                <TimerIcon className="w-8 h-8 text-purple-400" />
              </div>
              <div className="mt-2">
                <Badge variant="secondary" className="text-xs">
                  High engagement
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/60 border-gray-600">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Total Sessions</p>
                  <p className="text-2xl font-bold text-white">{displayData?.stats.totalSessions || 0}</p>
                </div>
                <Users className="w-8 h-8 text-orange-400" />
              </div>
              <div className="mt-2">
                <Badge variant="secondary" className="text-xs">
                  Active user
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-4 w-full max-w-2xl bg-gray-800 border-gray-600">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600">Overview</TabsTrigger>
            <TabsTrigger value="preferences" className="data-[state=active]:bg-purple-600">Preferences</TabsTrigger>
            <TabsTrigger value="patterns" className="data-[state=active]:bg-purple-600">Patterns</TabsTrigger>
            <TabsTrigger value="activity" className="data-[state=active]:bg-purple-600">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Top Preferences */}
              <Card className="bg-gray-800/60 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Target className="w-5 h-5 text-purple-400" />
                    Top Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {displayData?.preferences.slice(0, 8).map((pref) => (
                        <div key={pref.id} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                          <div className="flex items-center gap-3">
                            {getCategoryIcon(pref.category)}
                            <div>
                              <p className="text-white font-medium">{pref.preference}</p>
                              <p className="text-gray-400 text-xs capitalize">{pref.category.replace('_', ' ')}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <Progress value={pref.strength * 10} className="w-16 h-2 mb-1" />
                            <p className="text-xs text-gray-400">{(pref.strength * 10).toFixed(0)}%</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Interaction Patterns */}
              <Card className="bg-gray-800/60 border-gray-600">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Brain className="w-5 h-5 text-blue-400" />
                    Behavioral Patterns
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {displayData?.patterns.map((pattern) => (
                      <div key={pattern.id} className="p-4 bg-gray-700/50 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {getPatternIcon(pattern.patternType)}
                            <span className="text-white font-medium capitalize">
                              {pattern.patternType.replace('_', ' ')}
                            </span>
                          </div>
                          <Badge variant="outline" className="border-purple-500 text-purple-400">
                            {(pattern.confidence * 100).toFixed(0)}% confidence
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-300">
                          {pattern.patternType === 'category_affinity' && pattern.patternData.dominantCategory && (
                            <p>Strong interest in <span className="text-purple-400">{pattern.patternData.dominantCategory}</span> products</p>
                          )}
                          {pattern.patternType === 'time_preference' && pattern.patternData.peakHours && (
                            <p>Most active during <span className="text-green-400">peak hours</span></p>
                          )}
                          {pattern.patternType === 'price_sensitivity' && (
                            <p>Average spend: <span className="text-orange-400">${pattern.patternData.averagePrice?.toFixed(0)}</span></p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="preferences" className="space-y-6">
            <Card className="bg-gray-800/60 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white">Detailed Preference Analysis</CardTitle>
                <p className="text-gray-400 text-sm">Your preferences learned from platform interactions</p>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {displayData?.preferences.map((pref) => (
                      <div key={pref.id} className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg hover:bg-gray-700/70 transition-colors">
                        <div className="flex items-center gap-4">
                          {getCategoryIcon(pref.category)}
                          <div>
                            <h4 className="text-white font-medium">{pref.preference}</h4>
                            <p className="text-gray-400 text-sm capitalize">{pref.category.replace('_', ' ')}</p>
                            <p className="text-gray-500 text-xs">
                              Source: {pref.source} • Updated: {new Date(pref.lastUpdated).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-2 mb-1">
                            <Progress value={pref.strength * 10} className="w-20 h-2" />
                            <span className="text-sm text-white min-w-[3rem]">{(pref.strength * 10).toFixed(0)}%</span>
                          </div>
                          <Badge 
                            variant={pref.source === 'explicit' ? 'default' : 'secondary'}
                            className="text-xs"
                          >
                            {pref.source}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="patterns" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {displayData?.patterns.map((pattern) => (
                <Card key={pattern.id} className="bg-gray-800/60 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      {getPatternIcon(pattern.patternType)}
                      {pattern.patternType.replace('_', ' ').toUpperCase()}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Progress value={pattern.confidence * 100} className="flex-1 h-2" />
                      <span className="text-sm text-gray-400">{(pattern.confidence * 100).toFixed(0)}%</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm text-gray-300">
                      {pattern.patternType === 'category_affinity' && pattern.patternData.categories && (
                        <div>
                          <h5 className="text-white font-medium mb-2">Category Breakdown:</h5>
                          {pattern.patternData.categories.slice(0, 5).map((cat: any, idx: number) => (
                            <div key={idx} className="flex justify-between items-center mb-1">
                              <span>{cat.category}</span>
                              <Badge variant="outline" className="text-xs">{cat.count} interactions</Badge>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {pattern.patternType === 'time_preference' && pattern.patternData.peakHours && (
                        <div>
                          <h5 className="text-white font-medium mb-2">Peak Activity Hours:</h5>
                          {pattern.patternData.peakHours.slice(0, 3).map((hour: any, idx: number) => (
                            <div key={idx} className="flex justify-between items-center mb-1">
                              <span>{hour.hour}:00</span>
                              <Badge variant="outline" className="text-xs">{hour.count} activities</Badge>
                            </div>
                          ))}
                        </div>
                      )}

                      {pattern.patternType === 'price_sensitivity' && (
                        <div>
                          <h5 className="text-white font-medium mb-2">Spending Pattern:</h5>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-gray-400">Average Price</p>
                              <p className="text-white font-semibold">${pattern.patternData.averagePrice?.toFixed(0)}</p>
                            </div>
                            <div>
                              <p className="text-gray-400">Price Range</p>
                              <p className="text-white font-semibold">
                                {pattern.patternData.priceVariability > 100 ? 'Wide' : 'Narrow'}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      <p className="text-xs text-gray-500 mt-3">
                        Last calculated: {new Date(pattern.lastCalculated).toLocaleString()}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="activity" className="space-y-6">
            <Card className="bg-gray-800/60 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white">Recent Activity Feed</CardTitle>
                <p className="text-gray-400 text-sm">Live tracking of your platform interactions</p>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {displayData?.recentActivity.map((activity) => (
                      <div key={activity.id} className="flex items-start gap-3 p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors">
                        <div className="mt-1">
                          {getActionIcon(activity.action)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-white font-medium capitalize">{activity.action}</span>
                            <Badge variant="outline" className="text-xs">
                              {activity.entityType}
                            </Badge>
                          </div>
                          <p className="text-gray-300 text-sm">{activity.entityName}</p>
                          {activity.metadata?.category && (
                            <p className="text-gray-400 text-xs">Category: {activity.metadata.category}</p>
                          )}
                          {activity.metadata?.price && (
                            <p className="text-gray-400 text-xs">Price: ${activity.metadata.price}</p>
                          )}
                        </div>
                        <div className="text-right">
                          <p className="text-gray-500 text-xs">
                            {new Date(activity.timestamp).toLocaleTimeString()}
                          </p>
                          <p className="text-gray-500 text-xs">
                            {new Date(activity.timestamp).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}