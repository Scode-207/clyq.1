import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Bot, ShoppingBag, MapPin, Utensils } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const registerSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  username: z.string().min(3, "Username must be at least 3 characters").regex(/^[a-zA-Z0-9_]+$/, "Username can only contain letters, numbers, and underscores"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormData = z.infer<typeof loginSchema>;
type RegisterFormData = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [activeTab, setActiveTab] = useState("login");

  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  // Redirect if already logged in
  if (user) {
    return <Redirect to={user.profileComplete ? "/" : "/onboarding"} />;
  }

  const onLogin = (data: LoginFormData) => {
    loginMutation.mutate(data);
  };

  const onRegister = (data: RegisterFormData) => {
    const { confirmPassword, ...registerData } = data;
    registerMutation.mutate(registerData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A0A0A] via-[#1A1A1A] to-[#0D0D0D] flex">
      {/* Left side - Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md space-y-6">
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center mb-4">
              <Bot className="h-8 w-8 text-electric-blue mr-2" />
              <h1 className="text-2xl font-bold text-white">AI Commerce</h1>
            </div>
            <p className="text-gray-400">
              Your intelligent shopping companion
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-gray-800 border-gray-700">
              <TabsTrigger value="login" className="text-gray-300 data-[state=active]:text-white">
                Sign In
              </TabsTrigger>
              <TabsTrigger value="register" className="text-gray-300 data-[state=active]:text-white">
                Sign Up
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <Card className="border-gray-800 bg-gray-900/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Welcome back</CardTitle>
                  <CardDescription>
                    Sign in to continue your personalized shopping experience
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-gray-300">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your@email.com"
                        {...loginForm.register("email")}
                        className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                      />
                      {loginForm.formState.errors.email && (
                        <p className="text-sm text-red-400">{loginForm.formState.errors.email.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-gray-300">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        placeholder="Enter your password"
                        {...loginForm.register("password")}
                        className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                      />
                      {loginForm.formState.errors.password && (
                        <p className="text-sm text-red-400">{loginForm.formState.errors.password.message}</p>
                      )}
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-electric-blue hover:bg-electric-blue/80"
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Signing In...
                        </>
                      ) : (
                        "Sign In"
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="register">
              <Card className="border-gray-800 bg-gray-900/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Create Account</CardTitle>
                  <CardDescription>
                    Join the future of AI-powered shopping
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={registerForm.handleSubmit(onRegister)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName" className="text-gray-300">First Name</Label>
                        <Input
                          id="firstName"
                          placeholder="John"
                          {...registerForm.register("firstName")}
                          className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                        />
                        {registerForm.formState.errors.firstName && (
                          <p className="text-sm text-red-400">{registerForm.formState.errors.firstName.message}</p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="lastName" className="text-gray-300">Last Name</Label>
                        <Input
                          id="lastName"
                          placeholder="Doe"
                          {...registerForm.register("lastName")}
                          className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                        />
                        {registerForm.formState.errors.lastName && (
                          <p className="text-sm text-red-400">{registerForm.formState.errors.lastName.message}</p>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="username" className="text-gray-300">Username</Label>
                      <Input
                        id="username"
                        placeholder="johndoe"
                        {...registerForm.register("username")}
                        className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                      />
                      {registerForm.formState.errors.username && (
                        <p className="text-sm text-red-400">{registerForm.formState.errors.username.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="regEmail" className="text-gray-300">Email</Label>
                      <Input
                        id="regEmail"
                        type="email"
                        placeholder="your@email.com"
                        {...registerForm.register("email")}
                        className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                      />
                      {registerForm.formState.errors.email && (
                        <p className="text-sm text-red-400">{registerForm.formState.errors.email.message}</p>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="regPassword" className="text-gray-300">Password</Label>
                        <Input
                          id="regPassword"
                          type="password"
                          placeholder="Create password"
                          {...registerForm.register("password")}
                          className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                        />
                        {registerForm.formState.errors.password && (
                          <p className="text-sm text-red-400">{registerForm.formState.errors.password.message}</p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword" className="text-gray-300">Confirm</Label>
                        <Input
                          id="confirmPassword"
                          type="password"
                          placeholder="Confirm password"
                          {...registerForm.register("confirmPassword")}
                          className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                        />
                        {registerForm.formState.errors.confirmPassword && (
                          <p className="text-sm text-red-400">{registerForm.formState.errors.confirmPassword.message}</p>
                        )}
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-electric-blue hover:bg-electric-blue/80"
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating Account...
                        </>
                      ) : (
                        "Create Account"
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Right side - Hero */}
      <div className="flex-1 relative flex items-center justify-center p-8 bg-gradient-to-bl from-electric-blue/20 to-deep-purple/20">
        <div className="text-center space-y-8 max-w-lg">
          <h2 className="text-4xl font-bold text-white leading-tight">
            Experience the Future of Shopping
          </h2>
          
          <p className="text-xl text-gray-300 leading-relaxed">
            AI-powered conversations that understand your needs, find perfect products, and create personalized experiences
          </p>

          <div className="grid grid-cols-2 gap-6 mt-12">
            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-electric-blue/20 rounded-full flex items-center justify-center mx-auto">
                <ShoppingBag className="w-8 h-8 text-electric-blue" />
              </div>
              <h3 className="font-semibold text-white">Smart Marketplace</h3>
              <p className="text-sm text-gray-400">Voice-driven product discovery</p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-electric-blue/20 rounded-full flex items-center justify-center mx-auto">
                <Utensils className="w-8 h-8 text-electric-blue" />
              </div>
              <h3 className="font-semibold text-white">Food Ordering</h3>
              <p className="text-sm text-gray-400">Discover local restaurants</p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-electric-blue/20 rounded-full flex items-center justify-center mx-auto">
                <MapPin className="w-8 h-8 text-electric-blue" />
              </div>
              <h3 className="font-semibold text-white">Travel Booking</h3>
              <p className="text-sm text-gray-400">Plan perfect trips</p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-electric-blue/20 rounded-full flex items-center justify-center mx-auto">
                <Bot className="w-8 h-8 text-electric-blue" />
              </div>
              <h3 className="font-semibold text-white">AI Assistant</h3>
              <p className="text-sm text-gray-400">Personalized recommendations</p>
            </div>
          </div>
        </div>

        {/* Background decorative elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-electric-blue/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/4 right-1/4 w-40 h-40 bg-deep-purple/10 rounded-full blur-3xl"></div>
        </div>
      </div>
    </div>
  );
}