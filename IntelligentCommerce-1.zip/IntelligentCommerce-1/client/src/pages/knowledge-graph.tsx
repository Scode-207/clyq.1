import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Brain, Calendar, MessageSquare, Star, ShoppingBag, Utensils, MapPin, Clock, TrendingUp, Activity, Heart, Award } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface DailyReport {
  date: string;
  title: string;
  insights: string[];
  recommendations: string[];
  score: number;
  activityLevel: "Low" | "Medium" | "High";
}

interface UserNote {
  id: string;
  date: string;
  category: "behavior" | "preference" | "insight" | "recommendation";
  content: string;
  confidence: number;
}

interface FeaturedItem {
  id: string;
  title: string;
  category: "product" | "restaurant" | "hotel" | "service";
  description: string;
  price: string;
  rating: number;
  image: string;
  personalizationReason: string;
  confidence: number;
}

export default function KnowledgeGraphPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");

  // Mock personalized data based on user
  const dailyReports: DailyReport[] = [
    {
      date: "2025-07-06",
      title: "Health-Conscious Sunday",
      insights: [
        "Strong preference for healthy dining options detected",
        "Consistent interest in sustainable products",
        "Peak activity between 5-7 PM",
        "Location-based searches trending upward"
      ],
      recommendations: [
        "Try new organic restaurants in your area",
        "Consider eco-friendly product alternatives",
        "Schedule health-focused activities for optimal engagement",
        "Explore local farmers markets"
      ],
      score: 87,
      activityLevel: "High"
    },
    {
      date: "2025-07-05",
      title: "Exploration Mode Active",
      insights: [
        "Increased travel planning behavior",
        "Interest in boutique accommodations",
        "Budget-conscious decision making",
        "Social dining preferences"
      ],
      recommendations: [
        "Present mid-range travel options",
        "Highlight group dining experiences",
        "Focus on value-driven recommendations",
        "Suggest weekend getaway packages"
      ],
      score: 92,
      activityLevel: "High"
    }
  ];

  const userNotes: UserNote[] = [
    {
      id: "1",
      date: "2025-07-06",
      category: "preference",
      content: "Strong correlation between health queries and sustainable product interest. User values eco-conscious options.",
      confidence: 94
    },
    {
      id: "2",
      date: "2025-07-06",
      category: "behavior",
      content: "Peak engagement during evening hours (5-7 PM). Response time increases 40% during this window.",
      confidence: 89
    },
    {
      id: "3",
      date: "2025-07-05",
      category: "insight",
      content: "Location-based searches indicate potential move or travel planning. Geographic queries up 150%.",
      confidence: 76
    },
    {
      id: "4",
      date: "2025-07-05",
      category: "recommendation",
      content: "Introduce price comparison features. User shows budget awareness in 78% of commercial interactions.",
      confidence: 91
    }
  ];

  const featuredItems: FeaturedItem[] = [
    {
      id: "1",
      title: "Organic Bamboo Coffee Cups",
      category: "product",
      description: "Sustainable, reusable coffee cups made from bamboo fiber. Perfect for your eco-conscious lifestyle.",
      price: "$24.99",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300",
      personalizationReason: "Matches your sustainable product preferences and coffee consumption patterns",
      confidence: 95
    },
    {
      id: "2",
      title: "Leaf & Grain",
      category: "restaurant",
      description: "Farm-to-table restaurant specializing in organic, locally-sourced healthy meals.",
      price: "$$",
      rating: 4.7,
      image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=300",
      personalizationReason: "Aligns with your healthy dining preferences and location history",
      confidence: 92
    },
    {
      id: "3",
      title: "Eco Wellness Retreat",
      category: "hotel",
      description: "Sustainable wellness retreat with organic spa treatments and farm-to-table dining.",
      price: "$189/night",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=300",
      personalizationReason: "Combines your interest in wellness, sustainability, and unique accommodations",
      confidence: 88
    },
    {
      id: "4",
      title: "Green Delivery Service",
      category: "service",
      description: "Carbon-neutral food delivery service partnering with local organic restaurants.",
      price: "Free delivery",
      rating: 4.6,
      image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300",
      personalizationReason: "Matches your eco-friendly values and healthy food delivery patterns",
      confidence: 85
    },
    {
      id: "5",
      title: "Smart Air Quality Monitor",
      category: "product",
      description: "Real-time air quality monitoring with health recommendations and app integration.",
      price: "$79.99",
      rating: 4.5,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300",
      personalizationReason: "Supports your health-conscious lifestyle with smart home preferences",
      confidence: 81
    }
  ];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "product": return <ShoppingBag className="w-4 h-4" />;
      case "restaurant": return <Utensils className="w-4 h-4" />;
      case "hotel": return <MapPin className="w-4 h-4" />;
      case "service": return <Star className="w-4 h-4" />;
      default: return <Star className="w-4 h-4" />;
    }
  };

  const getNoteIcon = (category: string) => {
    switch (category) {
      case "behavior": return <Activity className="w-4 h-4" />;
      case "preference": return <Heart className="w-4 h-4" />;
      case "insight": return <Brain className="w-4 h-4" />;
      case "recommendation": return <Award className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return "text-green-500";
    if (confidence >= 75) return "text-blue-500";
    if (confidence >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  return (
    <div className="h-screen bg-background overflow-hidden">
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="px-8 py-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center neural-glow">
                <Brain className="text-primary-foreground" size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Knowledge Graph</h1>
                <p className="text-muted-foreground">Hyperpersonalization Intelligence for {user?.username}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="border-primary/30 text-primary">
                <Activity className="w-3 h-3 mr-1" />
                Active Learning
              </Badge>
              <Badge variant="outline" className="border-green-500/30 text-green-500">
                <TrendingUp className="w-3 h-3 mr-1" />
                94% Accuracy
              </Badge>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
            <div className="px-8 py-4 border-b border-border">
              <TabsList className="grid w-full grid-cols-4 max-w-2xl">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="reports">Daily Reports</TabsTrigger>
                <TabsTrigger value="notes">AI Notes</TabsTrigger>
                <TabsTrigger value="featured">Featured Items</TabsTrigger>
              </TabsList>
            </div>

            <div className="flex-1 overflow-auto">
              <div className="p-8">
                <TabsContent value="overview" className="space-y-6">
                  {/* User Profile Summary */}
                  <Card className="glass-card border-primary/20">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Brain className="w-5 h-5 text-primary" />
                        <span>Personality Profile</span>
                      </CardTitle>
                      <CardDescription>AI-generated insights about your preferences and behavior</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm text-muted-foreground">Health Consciousness</span>
                            <span className="text-sm font-medium">94%</span>
                          </div>
                          <Progress value={94} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm text-muted-foreground">Sustainability Focus</span>
                            <span className="text-sm font-medium">89%</span>
                          </div>
                          <Progress value={89} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm text-muted-foreground">Tech Adoption</span>
                            <span className="text-sm font-medium">76%</span>
                          </div>
                          <Progress value={76} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm text-muted-foreground">Budget Awareness</span>
                            <span className="text-sm font-medium">82%</span>
                          </div>
                          <Progress value={82} className="h-2" />
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div className="space-y-2">
                          <div className="text-2xl font-bold text-primary">247</div>
                          <div className="text-sm text-muted-foreground">Interactions</div>
                        </div>
                        <div className="space-y-2">
                          <div className="text-2xl font-bold text-green-500">92%</div>
                          <div className="text-sm text-muted-foreground">Satisfaction</div>
                        </div>
                        <div className="space-y-2">
                          <div className="text-2xl font-bold text-blue-500">15</div>
                          <div className="text-sm text-muted-foreground">Days Active</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Quick Stats */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="glass-card">
                      <CardContent className="p-6">
                        <div className="flex items-center space-x-2">
                          <Utensils className="w-5 h-5 text-green-500" />
                          <span className="font-medium">Food Preferences</span>
                        </div>
                        <div className="mt-2 text-2xl font-bold">Healthy</div>
                        <div className="text-sm text-muted-foreground">Primary cuisine type</div>
                      </CardContent>
                    </Card>
                    
                    <Card className="glass-card">
                      <CardContent className="p-6">
                        <div className="flex items-center space-x-2">
                          <ShoppingBag className="w-5 h-5 text-blue-500" />
                          <span className="font-medium">Shopping Style</span>
                        </div>
                        <div className="mt-2 text-2xl font-bold">Eco-Conscious</div>
                        <div className="text-sm text-muted-foreground">Sustainable focus</div>
                      </CardContent>
                    </Card>
                    
                    <Card className="glass-card">
                      <CardContent className="p-6">
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-5 h-5 text-purple-500" />
                          <span className="font-medium">Travel Style</span>
                        </div>
                        <div className="mt-2 text-2xl font-bold">Boutique</div>
                        <div className="text-sm text-muted-foreground">Unique experiences</div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="reports" className="space-y-6">
                  {dailyReports.map((report, index) => (
                    <Card key={index} className="glass-card border-primary/20">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="flex items-center space-x-2">
                            <Calendar className="w-5 h-5 text-primary" />
                            <span>{report.title}</span>
                          </CardTitle>
                          <div className="flex items-center space-x-2">
                            <Badge variant={report.activityLevel === "High" ? "default" : "secondary"}>
                              {report.activityLevel} Activity
                            </Badge>
                            <div className="text-2xl font-bold text-primary">{report.score}</div>
                          </div>
                        </div>
                        <CardDescription>{report.date}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-2 flex items-center space-x-2">
                            <Brain className="w-4 h-4" />
                            <span>Key Insights</span>
                          </h4>
                          <ul className="space-y-1">
                            {report.insights.map((insight, i) => (
                              <li key={i} className="text-sm text-muted-foreground flex items-center space-x-2">
                                <div className="w-1 h-1 bg-primary rounded-full"></div>
                                <span>{insight}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <Separator />
                        
                        <div>
                          <h4 className="font-medium mb-2 flex items-center space-x-2">
                            <Star className="w-4 h-4" />
                            <span>Recommendations</span>
                          </h4>
                          <ul className="space-y-1">
                            {report.recommendations.map((rec, i) => (
                              <li key={i} className="text-sm text-muted-foreground flex items-center space-x-2">
                                <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                                <span>{rec}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="notes" className="space-y-4">
                  {userNotes.map((note) => (
                    <Card key={note.id} className="glass-card">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3 flex-1">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                              {getNoteIcon(note.category)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <Badge variant="outline" className={`text-xs ${
                                  note.category === 'behavior' ? 'border-blue-500/30 text-blue-500' :
                                  note.category === 'preference' ? 'border-green-500/30 text-green-500' :
                                  note.category === 'insight' ? 'border-purple-500/30 text-purple-500' :
                                  'border-orange-500/30 text-orange-500'
                                }`}>
                                  {note.category}
                                </Badge>
                                <span className="text-xs text-muted-foreground">{note.date}</span>
                              </div>
                              <p className="text-sm leading-relaxed">{note.content}</p>
                            </div>
                          </div>
                          <div className={`text-sm font-medium ${getConfidenceColor(note.confidence)}`}>
                            {note.confidence}%
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="featured" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {featuredItems.map((item) => (
                      <Card key={item.id} className="glass-card border-primary/20 overflow-hidden">
                        <div className="aspect-video bg-muted relative">
                          <img 
                            src={item.image} 
                            alt={item.title}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute top-3 right-3">
                            <Badge className="bg-primary/90 text-primary-foreground">
                              {getCategoryIcon(item.category)}
                              <span className="ml-1 capitalize">{item.category}</span>
                            </Badge>
                          </div>
                        </div>
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-3">
                            <h3 className="font-semibold text-lg">{item.title}</h3>
                            <div className="flex items-center space-x-1">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              <span className="text-sm font-medium">{item.rating}</span>
                            </div>
                          </div>
                          
                          <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                            {item.description}
                          </p>
                          
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="font-semibold text-primary text-lg">{item.price}</span>
                              <div className={`text-sm font-medium ${getConfidenceColor(item.confidence)}`}>
                                {item.confidence}% match
                              </div>
                            </div>
                            
                            <div className="p-3 bg-primary/5 rounded-lg border border-primary/10">
                              <div className="text-xs text-muted-foreground mb-1">Why this matches you:</div>
                              <div className="text-sm">{item.personalizationReason}</div>
                            </div>
                            
                            <Button className="w-full">
                              View Details
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </div>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}