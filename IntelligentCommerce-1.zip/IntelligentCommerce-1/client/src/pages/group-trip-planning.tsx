import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Send, Users, MapPin, Calendar, DollarSign, Star, Bot, ArrowLeft } from 'lucide-react';
import ImageWithFallback from '@/components/image-with-fallback';

interface GroupMember {
  id: string;
  name: string;
  avatar: string;
  role: 'member' | 'ai';
  status: 'online' | 'offline' | 'typing';
  preferences?: {
    budget: string;
    activities: string[];
    accommodation: string;
  };
}

interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: Date;
  type: 'text' | 'suggestion' | 'poll' | 'booking';
  reactions?: { emoji: string; count: number; users: string[] }[];
  attachments?: { type: 'image' | 'link'; url: string; title: string }[];
}

interface TripSuggestion {
  id: string;
  title: string;
  description: string;
  estimatedCost: string;
  duration: string;
  activities: string[];
  votes: { userId: string; vote: 'yes' | 'no' | 'maybe' }[];
}

export default function GroupTripPlanning() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [activeTyping, setActiveTyping] = useState<string[]>([]);
  const [currentSuggestion, setCurrentSuggestion] = useState<TripSuggestion | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isSimulationActive, setIsSimulationActive] = useState(true);

  const groupMembers: GroupMember[] = [
    {
      id: 'user1',
      name: 'Sarah Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=100&h=100&fit=crop&crop=face',
      role: 'member',
      status: 'online',
      preferences: { budget: '$1500-2000', activities: ['hiking', 'photography', 'local cuisine'], accommodation: 'boutique hotels' }
    },
    {
      id: 'user2', 
      name: 'Marcus Rodriguez',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
      role: 'member',
      status: 'online',
      preferences: { budget: '$1200-1800', activities: ['adventure sports', 'nightlife', 'museums'], accommodation: 'hostels/mid-range' }
    },
    {
      id: 'user3',
      name: 'Emily Johnson',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
      role: 'member',
      status: 'typing',
      preferences: { budget: '$2000-2500', activities: ['spa/wellness', 'shopping', 'fine dining'], accommodation: 'luxury hotels' }
    },
    {
      id: 'ai-agent',
      name: 'CLYQ Travel Assistant',
      avatar: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=100&h=100&fit=crop&crop=center',
      role: 'ai',
      status: 'online'
    }
  ];

  const initialMessages: ChatMessage[] = [
    {
      id: '1',
      senderId: 'user1',
      senderName: 'Sarah Chen',
      content: "Hey everyone! So excited to plan this trip together! I'm thinking somewhere with great hiking and photo opportunities 📸",
      timestamp: new Date(Date.now() - 300000),
      type: 'text',
      reactions: [{ emoji: '🔥', count: 2, users: ['user2', 'user3'] }]
    },
    {
      id: '2',
      senderId: 'user2',
      senderName: 'Marcus Rodriguez', 
      content: "Same here! I'm up for some adventure sports. What about somewhere like Costa Rica or New Zealand?",
      timestamp: new Date(Date.now() - 240000),
      type: 'text',
      reactions: [{ emoji: '🤙', count: 1, users: ['user1'] }]
    },
    {
      id: '3',
      senderId: 'ai-agent',
      senderName: 'CLYQ Travel Assistant',
      content: "Based on your preferences, I'm analyzing destinations that combine adventure activities with great photography opportunities. Let me gather some options for you!",
      timestamp: new Date(Date.now() - 180000),
      type: 'text'
    },
    {
      id: '4',
      senderId: 'user3',
      senderName: 'Emily Johnson',
      content: "I'd love somewhere with good spa options too! And maybe some upscale dining experiences?",
      timestamp: new Date(Date.now() - 120000),
      type: 'text'
    },
    {
      id: '5',
      senderId: 'ai-agent',
      senderName: 'CLYQ Travel Assistant',
      content: "Perfect! I've found some amazing options that balance adventure, wellness, and luxury. Let me create a comprehensive suggestion for you all.",
      timestamp: new Date(Date.now() - 60000),
      type: 'suggestion',
      attachments: [
        { type: 'image', url: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=300&h=200&fit=crop', title: 'Swiss Alps Adventure & Wellness' },
        { type: 'image', url: 'https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=300&h=200&fit=crop', title: 'Bali Adventure & Spa Retreat' }
      ]
    }
  ];

  useEffect(() => {
    setMessages(initialMessages);
    
    // Simulate AI generating suggestion
    const aiSuggestionTimer = setTimeout(() => {
      const suggestion: TripSuggestion = {
        id: 'suggestion-1',
        title: 'Swiss Alps Adventure & Wellness Retreat',
        description: 'Perfect blend of adventure, wellness, and luxury in the stunning Swiss Alps. Hiking in Zermatt, spa treatments in St. Moritz, and fine dining experiences.',
        estimatedCost: '$1800-2200 per person',
        duration: '7 days, 6 nights',
        activities: ['Mountain hiking', 'Spa treatments', 'Fine dining', 'Photography tours', 'Cable car adventures'],
        votes: []
      };
      setCurrentSuggestion(suggestion);
      
      addAIMessage("🏔️ I've created a personalized trip suggestion that matches everyone's preferences! Check out the Swiss Alps Adventure & Wellness Retreat above. It combines Sarah's love for hiking and photography, Marcus's adventure spirit, and Emily's wellness preferences. What do you think?");
    }, 2000);

    // Random message generation system
    const randomMessages = [
      { senderId: 'user2', senderName: 'Marcus Rodriguez', content: "This looks amazing! I love the adventure hiking component 🏔️" },
      { senderId: 'user3', senderName: 'Emily Johnson', content: "The spa treatments in St. Moritz sound perfect! Just what I needed 💆‍♀️" },
      { senderId: 'user1', senderName: 'Sarah Chen', content: "Those photography tours are going to be incredible! Can't wait to capture the Alps 📸" },
      { senderId: 'ai-agent', senderName: 'CLYQ Travel Assistant', content: "I'm seeing great enthusiasm! I can also arrange group discounts and coordinate transportation for everyone." },
      { senderId: 'user2', senderName: 'Marcus Rodriguez', content: "What about the cable car adventures? Are they included in the package?" },
      { senderId: 'ai-agent', senderName: 'CLYQ Travel Assistant', content: "Yes! The cable car rides are included. You'll get to experience the Matterhorn Glacier Paradise and Jungfraujoch." },
      { senderId: 'user3', senderName: 'Emily Johnson', content: "I'm researching the hotels now. Are we staying in luxury accommodations?" },
      { senderId: 'user1', senderName: 'Sarah Chen', content: "I found some great hiking trails! Should we plan for early morning starts?" },
      { senderId: 'ai-agent', senderName: 'CLYQ Travel Assistant', content: "Based on weather patterns, I recommend starting hikes around 7 AM for optimal lighting and fewer crowds." },
      { senderId: 'user2', senderName: 'Marcus Rodriguez', content: "Perfect! I'm definitely voting yes on this trip. When should we book?" },
      { senderId: 'user3', senderName: 'Emily Johnson', content: "I'm so excited! This trip has everything we wanted. Let's make it happen! ✈️" },
      { senderId: 'ai-agent', senderName: 'CLYQ Travel Assistant', content: "Excellent! I'll prepare the detailed itinerary and booking options. Early bird pricing available for the next 48 hours!" }
    ];

    let messageIndex = 0;
    const messageInterval = setInterval(() => {
      if (messageIndex < randomMessages.length && isSimulationActive) {
        // Show typing indicator first
        const typingUsers = [randomMessages[messageIndex].senderId];
        setActiveTyping(typingUsers);
        
        // After 1-3 seconds, send the message
        setTimeout(() => {
          const randomMessage = randomMessages[messageIndex];
          const newMessage: ChatMessage = {
            id: `random-${Date.now()}-${messageIndex}`,
            senderId: randomMessage.senderId,
            senderName: randomMessage.senderName,
            content: randomMessage.content,
            timestamp: new Date(),
            type: 'text'
          };
          
          setMessages(prev => [...prev, newMessage]);
          setActiveTyping([]);
          messageIndex++;
        }, Math.random() * 2000 + 1000); // 1-3 seconds typing delay
      } else {
        clearInterval(messageInterval);
        setActiveTyping([]);
      }
    }, Math.random() * 6000 + 5000); // Random interval between 5-11 seconds

    return () => {
      clearTimeout(aiSuggestionTimer);
      clearInterval(messageInterval);
    };
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const addAIMessage = (content: string) => {
    const newMsg: ChatMessage = {
      id: Date.now().toString(),
      senderId: 'ai-agent',
      senderName: 'CLYQ Travel Assistant',
      content,
      timestamp: new Date(),
      type: 'text'
    };
    setMessages(prev => [...prev, newMsg]);
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      senderId: 'user1',
      senderName: 'You',
      content: newMessage,
      timestamp: new Date(),
      type: 'text'
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "That's a great point! Let me update our recommendations based on that.",
        "I'll look into that option and get back to you with details and pricing.",
        "Excellent suggestion! I'm checking availability and group discounts now.",
        "Perfect! I'll coordinate with local providers to arrange that experience for the group."
      ];
      
      addAIMessage(responses[Math.floor(Math.random() * responses.length)]);
    }, 1500);
  };

  const handleVote = (suggestionId: string, vote: 'yes' | 'no' | 'maybe') => {
    if (currentSuggestion?.id === suggestionId) {
      const updatedSuggestion = {
        ...currentSuggestion,
        votes: [...currentSuggestion.votes.filter(v => v.userId !== 'user1'), { userId: 'user1', vote }]
      };
      setCurrentSuggestion(updatedSuggestion);
      
      // Simulate group voting
      setTimeout(() => {
        const otherVotes = [
          { userId: 'user2', vote: 'yes' as const },
          { userId: 'user3', vote: 'maybe' as const }
        ];
        
        setCurrentSuggestion(prev => prev ? {
          ...prev,
          votes: [...prev.votes, ...otherVotes]
        } : null);
        
        addAIMessage("Great! I see we have some votes coming in. Once everyone votes, I'll finalize the booking details and create our itinerary!");
      }, 2000);
    }
  };

  const addReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const existingReaction = msg.reactions?.find(r => r.emoji === emoji);
        if (existingReaction && !existingReaction.users.includes('user1')) {
          return {
            ...msg,
            reactions: msg.reactions?.map(r => 
              r.emoji === emoji 
                ? { ...r, count: r.count + 1, users: [...r.users, 'user1'] }
                : r
            )
          };
        } else if (!existingReaction) {
          return {
            ...msg,
            reactions: [...(msg.reactions || []), { emoji, count: 1, users: ['user1'] }]
          };
        }
      }
      return msg;
    }));
  };

  const getMemberStatus = (memberId: string) => {
    const member = groupMembers.find(m => m.id === memberId);
    return member?.status || 'offline';
  };

  const getMemberAvatar = (memberId: string) => {
    const member = groupMembers.find(m => m.id === memberId);
    return member?.avatar || '/api/placeholder/40/40';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Group Members Sidebar */}
          <div className="lg:col-span-1">
            <Card className="bg-gray-800/50 border-gray-700 mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Users className="w-5 h-5" />
                  Trip Planning Group
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {groupMembers.map(member => (
                  <div key={member.id} className="flex items-center gap-3">
                    <div className="relative">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={member.avatar} />
                        <AvatarFallback className="bg-gray-700 text-white">
                          {member.role === 'ai' ? <Bot className="w-5 h-5" /> : member.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-gray-800 ${
                        member.status === 'online' ? 'bg-green-500' : 
                        member.status === 'typing' ? 'bg-yellow-500' : 'bg-gray-500'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-white">{member.name}</span>
                        {member.role === 'ai' && <Badge variant="secondary" className="text-xs">AI</Badge>}
                      </div>
                      <span className="text-xs text-gray-400">
                        {member.status === 'typing' ? 'typing...' : member.status}
                      </span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Trip Preferences */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white text-sm">Group Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <DollarSign className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Budget: $1200-2500</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-blue-400" />
                  <span className="text-gray-300">Duration: 5-7 days</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-red-400" />
                  <span className="text-gray-300">Style: Adventure + Wellness</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-3">
            <Card className="bg-gray-800/50 border-gray-700 h-[80vh] flex flex-col">
              <CardHeader className="border-b border-gray-700">
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => window.location.href = '/marketplace'}
                    className="text-gray-400 hover:text-white"
                  >
                    <ArrowLeft className="w-4 h-4 mr-1" />
                    Back to Marketplace
                  </Button>
                  <div className="flex-1">
                    <CardTitle className="text-white">Swiss Alps Trip Planning</CardTitle>
                    <p className="text-sm text-gray-400 mt-1">Group collaboration with AI assistance</p>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="flex-1 p-0 flex flex-col">
                {/* Current Suggestion */}
                {currentSuggestion && (
                  <div className="p-6 border-b border-gray-700 bg-gradient-to-r from-purple-900/20 to-blue-900/20">
                    <div className="bg-gray-800/80 backdrop-blur-sm rounded-xl p-6 shadow-lg">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center">
                          <Bot className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <span className="font-semibold text-white">AI Trip Suggestion</span>
                          <p className="text-xs text-gray-400">Personalized for your group</p>
                        </div>
                      </div>
                      
                      <h3 className="font-bold text-white text-lg mb-3">{currentSuggestion.title}</h3>
                      <p className="text-gray-300 text-sm mb-4 leading-relaxed">{currentSuggestion.description}</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="bg-gray-700/50 rounded-lg p-3">
                          <div className="flex items-center gap-2">
                            <DollarSign className="w-4 h-4 text-green-400" />
                            <span className="text-sm text-gray-400">Estimated Cost</span>
                          </div>
                          <span className="text-green-400 font-semibold">{currentSuggestion.estimatedCost}</span>
                        </div>
                        <div className="bg-gray-700/50 rounded-lg p-3">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-blue-400" />
                            <span className="text-sm text-gray-400">Duration</span>
                          </div>
                          <span className="text-blue-400 font-semibold">{currentSuggestion.duration}</span>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-sm text-gray-400 mb-2">Activities included:</p>
                        <div className="flex flex-wrap gap-2">
                          {currentSuggestion.activities.map(activity => (
                            <Badge key={activity} className="bg-purple-600/20 text-purple-200 border-purple-600/30">
                              {activity}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex gap-3">
                        <Button 
                          size="sm" 
                          className="bg-green-600 hover:bg-green-700 text-white border-none"
                          onClick={() => handleVote(currentSuggestion.id, 'yes')}
                        >
                          👍 Yes ({currentSuggestion.votes.filter(v => v.vote === 'yes').length})
                        </Button>
                        <Button 
                          size="sm" 
                          className="bg-yellow-600 hover:bg-yellow-700 text-white border-none"
                          onClick={() => handleVote(currentSuggestion.id, 'maybe')}
                        >
                          🤔 Maybe ({currentSuggestion.votes.filter(v => v.vote === 'maybe').length})
                        </Button>
                        <Button 
                          size="sm" 
                          className="bg-red-600 hover:bg-red-700 text-white border-none"
                          onClick={() => handleVote(currentSuggestion.id, 'no')}
                        >
                          👎 No ({currentSuggestion.votes.filter(v => v.vote === 'no').length})
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Messages */}
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-6">
                    {messages.map((message) => (
                      <div key={message.id} className={`flex gap-3 ${message.senderId === 'user1' ? 'flex-row-reverse' : 'flex-row'}`}>
                        <Avatar className="w-10 h-10 flex-shrink-0">
                          <AvatarImage src={getMemberAvatar(message.senderId)} />
                          <AvatarFallback className={`text-white text-xs ${
                            message.senderId === 'ai-agent' ? 'bg-purple-600' : 
                            message.senderId === 'user1' ? 'bg-blue-600' : 'bg-gray-600'
                          }`}>
                            {message.senderId === 'ai-agent' ? <Bot className="w-4 h-4" /> : 
                             message.senderId === 'user1' ? 'You' : message.senderName[0]}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className={`flex-1 max-w-[70%] ${message.senderId === 'user1' ? 'text-right' : 'text-left'}`}>
                          <div className={`inline-block rounded-2xl px-4 py-3 ${
                            message.senderId === 'user1' 
                              ? 'bg-blue-600 text-white' 
                              : message.senderId === 'ai-agent'
                              ? 'bg-purple-600/90 text-white border border-purple-400/30'
                              : 'bg-gray-700 text-white'
                          }`}>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-medium text-gray-200">{message.senderName}</span>
                              {message.senderId === 'ai-agent' && (
                                <Badge variant="secondary" className="text-xs bg-purple-800 text-purple-200">AI</Badge>
                              )}
                            </div>
                            <p className="text-sm leading-relaxed">{message.content}</p>
                            
                            {message.attachments && (
                              <div className="mt-3 space-y-2">
                                {message.attachments.map((attachment, idx) => (
                                  <div key={idx} className="bg-black/30 rounded-lg p-2">
                                    <ImageWithFallback
                                      src={attachment.url} 
                                      alt={attachment.title}
                                      className="w-full h-32 object-cover rounded"
                                      width={300}
                                      height={128}
                                    />
                                    <p className="text-xs text-gray-300 mt-1">{attachment.title}</p>
                                  </div>
                                ))}
                              </div>
                            )}
                            
                            {message.reactions && message.reactions.length > 0 && (
                              <div className="flex gap-1 mt-2">
                                {message.reactions.map((reaction, idx) => (
                                  <span key={idx} className="text-xs bg-black/30 rounded-full px-2 py-1">
                                    {reaction.emoji} {reaction.count}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                          
                          <div className="flex items-center gap-2 mt-1 text-xs text-gray-400">
                            <span>{message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            {message.senderId !== 'user1' && (
                              <div className="flex gap-1">
                                <button 
                                  onClick={() => addReaction(message.id, '👍')}
                                  className="hover:scale-110 transition-transform"
                                >
                                  👍
                                </button>
                                <button 
                                  onClick={() => addReaction(message.id, '❤️')}
                                  className="hover:scale-110 transition-transform"
                                >
                                  ❤️
                                </button>
                                <button 
                                  onClick={() => addReaction(message.id, '🔥')}
                                  className="hover:scale-110 transition-transform"
                                >
                                  🔥
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {activeTyping.length > 0 && (
                      <div className="flex gap-3 items-start">
                        <Avatar className="w-10 h-10 flex-shrink-0">
                          <AvatarImage src={getMemberAvatar(activeTyping[0])} />
                          <AvatarFallback className={`text-white text-xs ${
                            activeTyping[0] === 'ai-agent' ? 'bg-purple-600' : 'bg-gray-600'
                          }`}>
                            {activeTyping[0] === 'ai-agent' ? <Bot className="w-4 h-4" /> : 
                             groupMembers.find(m => m.id === activeTyping[0])?.name[0] || '?'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="bg-gray-700 rounded-2xl px-4 py-3 max-w-[200px]">
                          <div className="flex items-center gap-2 text-sm text-gray-400">
                            <div className="flex gap-1">
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                            </div>
                            <span>typing...</span>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>
                
                {/* Message Input */}
                <div className="p-4 border-t border-gray-700">
                  <div className="flex gap-2 items-center">
                    <Button 
                      onClick={() => setIsSimulationActive(!isSimulationActive)}
                      variant="ghost"
                      size="sm"
                      className={`text-xs ${isSimulationActive ? 'text-green-400' : 'text-gray-400'}`}
                    >
                      {isSimulationActive ? '🟢 Live' : '⏸️ Paused'}
                    </Button>
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type your message..."
                      className="flex-1 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    />
                    <Button 
                      onClick={handleSendMessage}
                      className="bg-blue-600 hover:bg-blue-700"
                      size="sm"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    {isSimulationActive ? '✨ Live group chat simulation active' : '⏸️ Simulation paused - you can still send messages'}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}