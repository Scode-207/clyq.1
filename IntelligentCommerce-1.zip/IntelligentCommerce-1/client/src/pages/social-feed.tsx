import { useState } from "react";
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, Camera, Video, Smile, Send, Clock, MapPin, Star, Verified, TrendingUp, Eye, Users, ThumbsUp, Award, Recycle, Wrench, Package, Sparkles, ArrowLeft, ShoppingBag, Home } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import ImageWithFallback from "@/components/image-with-fallback";

interface SocialPost {
  id: string;
  user: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    verified: boolean;
    followers: number;
    badges: string[];
  };
  type: 'product_showcase' | 'refurbishment_journey' | 'review' | 'project_update' | 'achievement' | 'tip_share';
  content: {
    text: string;
    images: string[];
    videos?: string[];
    tags: string[];
  };
  metadata: {
    productName?: string;
    beforeAfterImages?: { before: string; after: string };
    progress?: number;
    rating?: number;
    timeSpent?: string;
    skillsUsed?: string[];
    costsInvolved?: { before: number; after: number };
  };
  engagement: {
    likes: number;
    comments: number;
    shares: number;
    bookmarks: number;
    views: number;
  };
  timestamp: string;
  location?: string;
  isLiked: boolean;
  isBookmarked: boolean;
}

export default function SocialFeed() {
  const [, setLocation] = useLocation();
  const [newPostText, setNewPostText] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'following' | 'trending' | 'showcase' | 'journeys'>('all');

  const mockPosts: SocialPost[] = [
    {
      id: '1',
      user: {
        id: 'alex_tech',
        name: 'Alex Chen',
        username: '@alextech_repairs',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
        verified: true,
        followers: 12500,
        badges: ['Electronics Expert', 'Sustainability Advocate']
      },
      type: 'refurbishment_journey',
      content: {
        text: "Just finished restoring this vintage 1980s Walkman! Found it in a thrift store for $5, and after 3 weeks of work, it's playing music like new. The key was sourcing original capacitors and cleaning the tape mechanism. Such a satisfying project! 🎵",
        images: [
          'https://images.unsplash.com/photo-1493020258366-be3ead67cdb8?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=500&h=400&fit=crop'
        ],
        tags: ['vintage', 'walkman', 'restoration', 'electronics', 'sustainability']
      },
      metadata: {
        productName: 'Sony Walkman WM-10',
        beforeAfterImages: {
          before: 'https://images.unsplash.com/photo-1493020258366-be3ead67cdb8?w=500&h=400&fit=crop',
          after: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=500&h=400&fit=crop'
        },
        progress: 100,
        timeSpent: '3 weeks',
        skillsUsed: ['Soldering', 'Circuit Repair', 'Mechanical Cleaning'],
        costsInvolved: { before: 5, after: 35 }
      },
      engagement: {
        likes: 847,
        comments: 89,
        shares: 156,
        bookmarks: 234,
        views: 5670
      },
      timestamp: '2h ago',
      location: 'San Francisco, CA',
      isLiked: false,
      isBookmarked: true
    },
    {
      id: '2',
      user: {
        id: 'maria_diy',
        name: 'Maria Rodriguez',
        username: '@maria_upcycles',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616c19a0da7?w=100&h=100&fit=crop&crop=face',
        verified: false,
        followers: 3400,
        badges: ['DIY Master', 'Eco Warrior']
      },
      type: 'product_showcase',
      content: {
        text: "Turned an old dresser into a modern entertainment center! Used sustainable wood stain and added LED strip lighting. Total transformation for under $50. Link to tutorial in my bio!",
        images: [
          'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1618220179428-22790b461013?w=500&h=400&fit=crop'
        ],
        tags: ['furniture', 'upcycling', 'diy', 'budget-friendly', 'sustainable']
      },
      metadata: {
        productName: 'Vintage Dresser Upcycle',
        beforeAfterImages: {
          before: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=500&h=400&fit=crop',
          after: 'https://images.unsplash.com/photo-1618220179428-22790b461013?w=500&h=400&fit=crop'
        },
        progress: 100,
        timeSpent: '2 weekends',
        skillsUsed: ['Woodworking', 'Painting', 'Electrical'],
        costsInvolved: { before: 20, after: 50 }
      },
      engagement: {
        likes: 523,
        comments: 67,
        shares: 89,
        bookmarks: 178,
        views: 3240
      },
      timestamp: '5h ago',
      location: 'Austin, TX',
      isLiked: true,
      isBookmarked: false
    },
    {
      id: '3',
      user: {
        id: 'james_collector',
        name: 'James Kim',
        username: '@vintage_james',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
        verified: true,
        followers: 8900,
        badges: ['Vintage Expert', 'Authenticated Seller']
      },
      type: 'review',
      content: {
        text: "Just received this Canon AE-1 from @camera_restoration_pro and WOW! The quality of work is incredible. Every detail restored to perfection. Film photography community, you need to check this out!",
        images: [
          'https://images.unsplash.com/photo-1606983340126-99ab4feaa64d?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=500&h=400&fit=crop'
        ],
        tags: ['camera', 'restoration', 'film-photography', 'canon', 'quality']
      },
      metadata: {
        productName: 'Canon AE-1 Camera',
        rating: 5,
        timeSpent: 'Service: 2 weeks',
        skillsUsed: ['Professional Restoration']
      },
      engagement: {
        likes: 691,
        comments: 45,
        shares: 78,
        bookmarks: 156,
        views: 4120
      },
      timestamp: '1d ago',
      location: 'Los Angeles, CA',
      isLiked: false,
      isBookmarked: true
    },
    {
      id: '4',
      user: {
        id: 'sarah_eco',
        name: 'Sarah Thompson',
        username: '@eco_sarah',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
        verified: false,
        followers: 15600,
        badges: ['Sustainability Expert', 'Green Living']
      },
      type: 'project_update',
      content: {
        text: "Week 3 of my laptop upgrade challenge! Swapped the HDD for an SSD and doubled the RAM. Performance increased by 300%! Proving that you don't always need to buy new. Next: upgrading the cooling system.",
        images: [
          'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1559181567-c3190ca9959b?w=500&h=400&fit=crop'
        ],
        tags: ['laptop', 'upgrade', 'sustainability', 'tech', 'diy']
      },
      metadata: {
        productName: 'ThinkPad X1 Carbon Upgrade',
        progress: 60,
        timeSpent: '3 weeks ongoing',
        skillsUsed: ['Hardware Installation', 'System Optimization'],
        costsInvolved: { before: 800, after: 950 }
      },
      engagement: {
        likes: 445,
        comments: 78,
        shares: 34,
        bookmarks: 123,
        views: 2890
      },
      timestamp: '6h ago',
      location: 'Seattle, WA',
      isLiked: true,
      isBookmarked: false
    },
    {
      id: '5',
      user: {
        id: 'mike_gamer',
        name: 'Mike Wilson',
        username: '@retro_mike',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face',
        verified: false,
        followers: 6700,
        badges: ['Gaming Expert', 'Retro Specialist']
      },
      type: 'achievement',
      content: {
        text: "FINALLY! After 6 months of searching and 2 months of restoration, my Nintendo Virtual Boy is working perfectly! The hardest part was fixing the mirror oscillation. Only 12 games exist but it's SO worth it!",
        images: [
          'https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=400&fit=crop'
        ],
        tags: ['nintendo', 'virtual-boy', 'retro-gaming', 'restoration', 'achievement']
      },
      metadata: {
        productName: 'Nintendo Virtual Boy',
        progress: 100,
        timeSpent: '2 months restoration',
        skillsUsed: ['Electronics Repair', 'Optical Calibration'],
        costsInvolved: { before: 300, after: 450 }
      },
      engagement: {
        likes: 912,
        comments: 134,
        shares: 89,
        bookmarks: 267,
        views: 6750
      },
      timestamp: '12h ago',
      location: 'Denver, CO',
      isLiked: false,
      isBookmarked: true
    },
    {
      id: '6',
      user: {
        id: 'luna_crafter',
        name: 'Luna Zhang',
        username: '@luna_upcycles',
        avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&h=100&fit=crop&crop=face',
        verified: true,
        followers: 22100,
        badges: ['Craft Master', 'Sustainability Champion']
      },
      type: 'tip_share',
      content: {
        text: "Pro tip for anyone restoring old electronics: Always use a multimeter to test circuits before powering on! Saved me from frying another vintage amplifier. Here's my essential testing checklist that's helped me restore 50+ devices safely.",
        images: [
          'https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=500&h=400&fit=crop'
        ],
        tags: ['electronics', 'safety', 'tips', 'restoration', 'vintage']
      },
      metadata: {
        skillsUsed: ['Circuit Testing', 'Electronics Safety', 'Troubleshooting']
      },
      engagement: {
        likes: 756,
        comments: 92,
        shares: 234,
        bookmarks: 445,
        views: 8920
      },
      timestamp: '18h ago',
      location: 'Boston, MA',
      isLiked: true,
      isBookmarked: true
    },
    {
      id: '7',
      user: {
        id: 'carlos_vintage',
        name: 'Carlos Mendoza',
        username: '@vintage_carlos',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
        verified: false,
        followers: 4300,
        badges: ['Vintage Expert', 'Watch Collector']
      },
      type: 'product_showcase',
      content: {
        text: "Found this 1960s Omega Seamaster at a flea market for $80! The seller thought it was broken, but it just needed a good cleaning and new mainspring. Now it's keeping perfect time. Sometimes the best treasures are hiding in plain sight! ⌚",
        images: [
          'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1594534475808-b18fc33b045e?w=500&h=400&fit=crop'
        ],
        tags: ['omega', 'vintage-watch', 'flea-market', 'restoration', 'treasure-hunt']
      },
      metadata: {
        productName: 'Omega Seamaster 1960s',
        beforeAfterImages: {
          before: 'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?w=500&h=400&fit=crop',
          after: 'https://images.unsplash.com/photo-1594534475808-b18fc33b045e?w=500&h=400&fit=crop'
        },
        timeSpent: '1 weekend',
        skillsUsed: ['Watch Repair', 'Cleaning', 'Calibration'],
        costsInvolved: { before: 80, after: 120 }
      },
      engagement: {
        likes: 934,
        comments: 156,
        shares: 78,
        bookmarks: 298,
        views: 6540
      },
      timestamp: '1d ago',
      location: 'Miami, FL',
      isLiked: false,
      isBookmarked: false
    },
    {
      id: '8',
      user: {
        id: 'emma_green',
        name: 'Emma Thompson',
        username: '@sustainable_emma',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b766?w=100&h=100&fit=crop&crop=face',
        verified: true,
        followers: 18700,
        badges: ['Eco Warrior', 'Zero Waste Expert']
      },
      type: 'refurbishment_journey',
      content: {
        text: "Week 4 update: Converting this 1980s sewing machine into a functional workspace centerpiece! Original motor works perfectly, just needed rewiring and a custom LED upgrade. The art deco design is timeless. Next week: custom wooden base!",
        images: [
          'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1609205928003-1bf60f0b1946?w=500&h=400&fit=crop'
        ],
        tags: ['sewing-machine', 'vintage', 'restoration', 'functional-art', 'led-upgrade']
      },
      metadata: {
        productName: 'Singer Featherweight 221',
        progress: 75,
        timeSpent: '4 weeks ongoing',
        skillsUsed: ['Electrical Work', 'Mechanical Repair', 'LED Installation'],
        costsInvolved: { before: 150, after: 220 }
      },
      engagement: {
        likes: 623,
        comments: 87,
        shares: 45,
        bookmarks: 234,
        views: 4320
      },
      timestamp: '2d ago',
      location: 'Portland, OR',
      isLiked: true,
      isBookmarked: true
    },
    {
      id: '9',
      user: {
        id: 'alex_audio',
        name: 'Alex Rivera',
        username: '@audio_alex',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
        verified: false,
        followers: 7800,
        badges: ['Audio Engineer', 'DIY Enthusiast']
      },
      type: 'achievement',
      content: {
        text: "SUCCESS! After 3 months of research and building, my custom tube preamp is finally complete! Hand-wound transformers, point-to-point wiring, and vintage NOS tubes. The sound is absolutely incredible - warm, rich, and musical. Building from scratch is so rewarding! 🎵",
        images: [
          'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=500&h=400&fit=crop'
        ],
        tags: ['tube-preamp', 'diy-audio', 'custom-build', 'hand-wired', 'achievement']
      },
      metadata: {
        productName: 'Custom Tube Preamp',
        progress: 100,
        timeSpent: '3 months',
        skillsUsed: ['Electronics Design', 'Hand Wiring', 'Audio Testing'],
        costsInvolved: { before: 0, after: 450 }
      },
      engagement: {
        likes: 1240,
        comments: 198,
        shares: 123,
        bookmarks: 567,
        views: 12450
      },
      timestamp: '3d ago',
      location: 'Nashville, TN',
      isLiked: false,
      isBookmarked: true
    },
    {
      id: '10',
      user: {
        id: 'maya_fashion',
        name: 'Maya Patel',
        username: '@sustainable_fashion',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
        verified: true,
        followers: 31200,
        badges: ['Fashion Designer', 'Upcycle Expert']
      },
      type: 'project_update',
      content: {
        text: "Transforming fast fashion into slow fashion, one piece at a time! This vintage blazer got a complete makeover with hand-embroidered details and custom tailoring. Teaching a workshop on sustainable fashion techniques next weekend - link in bio!",
        images: [
          'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=500&h=400&fit=crop',
          'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=500&h=400&fit=crop'
        ],
        tags: ['sustainable-fashion', 'embroidery', 'tailoring', 'slow-fashion', 'workshop']
      },
      metadata: {
        productName: 'Vintage Blazer Upcycle',
        beforeAfterImages: {
          before: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=500&h=400&fit=crop',
          after: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=500&h=400&fit=crop'
        },
        progress: 90,
        timeSpent: '2 weeks',
        skillsUsed: ['Embroidery', 'Tailoring', 'Pattern Making'],
        costsInvolved: { before: 25, after: 45 }
      },
      engagement: {
        likes: 892,
        comments: 134,
        shares: 234,
        bookmarks: 445,
        views: 7890
      },
      timestamp: '4d ago',
      location: 'San Francisco, CA',
      isLiked: true,
      isBookmarked: false
    }
  ];

  const getPostIcon = (type: SocialPost['type']) => {
    switch (type) {
      case 'product_showcase': return <Package className="w-4 h-4 text-blue-400" />;
      case 'refurbishment_journey': return <Wrench className="w-4 h-4 text-green-400" />;
      case 'review': return <Star className="w-4 h-4 text-yellow-400" />;
      case 'project_update': return <TrendingUp className="w-4 h-4 text-purple-400" />;
      case 'achievement': return <Award className="w-4 h-4 text-orange-400" />;
      case 'tip_share': return <Sparkles className="w-4 h-4 text-pink-400" />;
      default: return <MessageCircle className="w-4 h-4 text-gray-400" />;
    }
  };

  const getPostTypeLabel = (type: SocialPost['type']) => {
    switch (type) {
      case 'product_showcase': return 'Product Showcase';
      case 'refurbishment_journey': return 'Refurbishment Journey';
      case 'review': return 'Product Review';
      case 'project_update': return 'Project Update';
      case 'achievement': return 'Achievement';
      case 'tip_share': return 'Tip Share';
      default: return 'Post';
    }
  };

  // Filter posts based on active tab
  const getFilteredPosts = () => {
    switch (activeTab) {
      case 'following':
        // Show posts from verified/followed users
        return mockPosts.filter(post => post.user.verified || post.user.followers > 5000);
      case 'trending':
        // Show posts with high engagement
        return mockPosts.filter(post => post.engagement.likes > 600 || post.engagement.views > 4000);
      case 'showcase':
        // Show product showcases and achievements
        return mockPosts.filter(post => post.type === 'product_showcase' || post.type === 'achievement');
      case 'journeys':
        // Show refurbishment journeys and project updates
        return mockPosts.filter(post => post.type === 'refurbishment_journey' || post.type === 'project_update');
      default:
        return mockPosts;
    }
  };

  const filteredPosts = getFilteredPosts();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <div className="bg-gray-800/60 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation('/marketplace')}
                className="text-gray-400 hover:text-white hover:bg-gray-700"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Marketplace
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Users className="w-6 h-6 text-purple-400" />
                  Social Feed
                </h1>
                <p className="text-gray-400 text-sm">See what the community is building and sharing</p>
              </div>
            </div>
            
            {/* Feed Filters */}
            <div className="flex items-center gap-2">
              {[
                { key: 'all', label: 'All', icon: Users },
                { key: 'following', label: 'Following', icon: Heart },
                { key: 'trending', label: 'Trending', icon: TrendingUp },
                { key: 'showcase', label: 'Showcase', icon: Package },
                { key: 'journeys', label: 'Journeys', icon: Wrench }
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <Button
                    key={tab.key}
                    variant={activeTab === tab.key ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveTab(tab.key as any)}
                    className={`${
                      activeTab === tab.key 
                        ? 'bg-purple-600 text-white' 
                        : 'text-gray-400 hover:text-white hover:bg-gray-700'
                    }`}
                  >
                    <Icon className="w-4 h-4 mr-1" />
                    {tab.label}
                  </Button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-6">
        {/* Create Post Section */}
        <Card className="bg-gray-800/60 border-gray-600 mb-6">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face" />
                <AvatarFallback>You</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <Textarea
                  placeholder="Share your latest project, restoration, or discovery..."
                  value={newPostText}
                  onChange={(e) => setNewPostText(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 resize-none"
                  rows={3}
                />
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                      <Camera className="w-4 h-4 mr-1" />
                      Photo
                    </Button>
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                      <Video className="w-4 h-4 mr-1" />
                      Video
                    </Button>
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                      <Smile className="w-4 h-4 mr-1" />
                      Emoji
                    </Button>
                  </div>
                  <Button 
                    disabled={!newPostText.trim()}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    <Send className="w-4 h-4 mr-1" />
                    Share
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts Feed */}
        <div className="space-y-6">
          {filteredPosts.length === 0 ? (
            <Card className="bg-gray-800/60 border-gray-600">
              <CardContent className="p-8 text-center">
                <div className="flex flex-col items-center gap-3">
                  <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center">
                    {activeTab === 'showcase' && <Package className="w-8 h-8 text-purple-400" />}
                    {activeTab === 'journeys' && <Wrench className="w-8 h-8 text-green-400" />}
                    {activeTab === 'trending' && <TrendingUp className="w-8 h-8 text-orange-400" />}
                    {activeTab === 'following' && <Users className="w-8 h-8 text-blue-400" />}
                  </div>
                  <h3 className="text-xl font-semibold text-white">
                    {activeTab === 'showcase' && 'No Product Showcases Yet'}
                    {activeTab === 'journeys' && 'No Journey Posts Yet'}
                    {activeTab === 'trending' && 'No Trending Posts'}
                    {activeTab === 'following' && 'No Posts from Following'}
                  </h3>
                  <p className="text-gray-400 text-sm max-w-md">
                    {activeTab === 'showcase' && 'Be the first to showcase your latest product finds and achievements!'}
                    {activeTab === 'journeys' && 'Share your refurbishment journey and inspire others in the community.'}
                    {activeTab === 'trending' && 'Check back later for trending posts from the community.'}
                    {activeTab === 'following' && 'Follow more users to see their posts in your feed.'}
                  </p>
                  <Button 
                    onClick={() => setActiveTab('all')}
                    className="bg-purple-600 hover:bg-purple-700 text-white mt-2"
                  >
                    View All Posts
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            filteredPosts.map((post) => (
              <Card key={post.id} className="bg-gray-800/60 border-gray-600 hover:bg-gray-800/80 transition-all duration-300">
              <CardHeader className="pb-3">
                {/* Post Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={post.user.avatar} alt={post.user.name} />
                      <AvatarFallback>{post.user.name.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-white">{post.user.name}</h3>
                        {post.user.verified && <Verified className="w-4 h-4 text-blue-400" />}
                        <span className="text-gray-400 text-sm">{post.user.username}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="flex items-center gap-1">
                          {getPostIcon(post.type)}
                          <span className="text-xs text-gray-400">{getPostTypeLabel(post.type)}</span>
                        </div>
                        <span className="text-gray-500">•</span>
                        <span className="text-xs text-gray-400">{post.timestamp}</span>
                        {post.location && (
                          <>
                            <span className="text-gray-500">•</span>
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-gray-400" />
                              <span className="text-xs text-gray-400">{post.location}</span>
                            </div>
                          </>
                        )}
                      </div>
                      
                      {/* User Badges */}
                      <div className="flex flex-wrap gap-1 mt-2">
                        {post.user.badges.map((badge) => (
                          <Badge key={badge} variant="secondary" className="text-xs">
                            {badge}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>

              <CardContent>
                {/* Post Content */}
                <div className="mb-4">
                  <p className="text-white leading-relaxed">{post.content.text}</p>
                  
                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 mt-3">
                    {post.content.tags.map((tag) => (
                      <span key={tag} className="text-purple-400 text-sm hover:underline cursor-pointer">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Media Content */}
                {post.content.images.length > 0 && (
                  <div className={`grid gap-3 mb-4 ${
                    post.content.images.length === 1 ? 'grid-cols-1' : 
                    post.content.images.length === 2 ? 'grid-cols-2' : 
                    'grid-cols-2'
                  }`}>
                    {post.content.images.map((image, index) => (
                      <div key={index} className="relative group overflow-hidden rounded-lg">
                        <ImageWithFallback
                          src={image}
                          alt={`Post image ${index + 1}`}
                          className="w-full h-72 object-cover cursor-pointer hover:scale-105 transition-transform duration-300"
                          width={400}
                          height={288}
                        />
                        {post.metadata.beforeAfterImages && index < 2 && (
                          <div className="absolute top-3 left-3">
                            <Badge className={`${index === 0 ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'} text-white shadow-lg`}>
                              {index === 0 ? 'Before' : 'After'}
                            </Badge>
                          </div>
                        )}
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-300" />
                      </div>
                    ))}
                  </div>
                )}

                {/* Project Metadata */}
                {post.metadata && (
                  <div className="bg-gradient-to-r from-gray-700/30 to-gray-800/50 rounded-xl p-4 mb-4 border border-gray-600/30">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      {post.metadata.productName && (
                        <div className="bg-gray-800/50 rounded-lg p-2">
                          <span className="text-gray-400 text-xs">Product</span>
                          <p className="text-white font-medium truncate">{post.metadata.productName}</p>
                        </div>
                      )}
                      {post.metadata.timeSpent && (
                        <div className="bg-gray-800/50 rounded-lg p-2">
                          <span className="text-gray-400 text-xs flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            Time
                          </span>
                          <p className="text-white font-medium">{post.metadata.timeSpent}</p>
                        </div>
                      )}
                      {post.metadata.progress !== undefined && (
                        <div className="bg-gray-800/50 rounded-lg p-2">
                          <span className="text-gray-400 text-xs">Progress</span>
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-gray-600 rounded-full h-2">
                              <div 
                                className="bg-gradient-to-r from-green-500 to-emerald-400 h-2 rounded-full transition-all duration-300"
                                style={{ width: `${post.metadata.progress}%` }}
                              />
                            </div>
                            <span className="text-white font-medium text-xs">{post.metadata.progress}%</span>
                          </div>
                        </div>
                      )}
                      {post.metadata.costsInvolved && (
                        <div className="bg-gray-800/50 rounded-lg p-2">
                          <span className="text-gray-400 text-xs">Investment</span>
                          <p className="text-green-400 font-medium">${post.metadata.costsInvolved.after}</p>
                          {post.metadata.costsInvolved.before > 0 && (
                            <p className="text-xs text-gray-500">+${post.metadata.costsInvolved.after - post.metadata.costsInvolved.before}</p>
                          )}
                        </div>
                      )}
                    </div>
                    
                    {post.metadata.skillsUsed && (
                      <div className="mt-4 pt-3 border-t border-gray-600/30">
                        <span className="text-gray-400 text-sm flex items-center gap-1 mb-2">
                          <Award className="w-3 h-3" />
                          Skills Used
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {post.metadata.skillsUsed.map((skill) => (
                            <Badge key={skill} className="bg-purple-600/20 border-purple-500/30 text-purple-300 hover:bg-purple-600/30 transition-colors">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Engagement Actions */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-700/50">
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${
                        post.isLiked 
                          ? 'text-red-400 bg-red-400/10 hover:bg-red-400/20' 
                          : 'text-gray-400 hover:text-red-400 hover:bg-red-400/10'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${post.isLiked ? 'fill-current' : ''}`} />
                      <span className="text-sm font-medium">{post.engagement.likes.toLocaleString()}</span>
                    </Button>
                    
                    <Button variant="ghost" size="sm" className="flex items-center gap-2 px-3 py-2 rounded-lg text-gray-400 hover:text-blue-400 hover:bg-blue-400/10 transition-all">
                      <MessageCircle className="w-4 h-4" />
                      <span className="text-sm font-medium">{post.engagement.comments}</span>
                    </Button>
                    
                    <Button variant="ghost" size="sm" className="flex items-center gap-2 px-3 py-2 rounded-lg text-gray-400 hover:text-green-400 hover:bg-green-400/10 transition-all">
                      <Share2 className="w-4 h-4" />
                      <span className="text-sm font-medium">{post.engagement.shares}</span>
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 text-gray-400 text-sm">
                      <Eye className="w-4 h-4" />
                      <span>{post.engagement.views}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className={`${
                        post.isBookmarked ? 'text-yellow-400' : 'text-gray-400 hover:text-yellow-400'
                      }`}
                    >
                      <Bookmark className={`w-4 h-4 ${post.isBookmarked ? 'fill-current' : ''}`} />
                    </Button>
                  </div>
                </div>
              </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}