import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Star, MapPin, Send, Loader2, CreditCard, Heart, Mail, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import ImageWithFallback from "@/components/image-with-fallback";

interface HotelImages {
  lobby: string;
  room: string;
  exterior: string;
  amenities: string;
  dining: string;
}

interface BookingMessage {
  id: string;
  role: "ai" | "user";
  content: string;
  timestamp: Date;
}

export default function BookingPage() {
  const [, setLocation] = useLocation();
  const [hotel, setHotel] = useState<any>(null);
  const [selectedImage, setSelectedImage] = useState<string>('lobby');
  const [isLoading, setIsLoading] = useState(true);
  const [messages, setMessages] = useState<BookingMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showEmailButton, setShowEmailButton] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const [emailSending, setEmailSending] = useState(false);
  const [bookingDetails, setBookingDetails] = useState<any>(null);
  const { user } = useAuth();

  // Get hotel data from URL state
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const hotelData = urlParams.get('hotel');
    if (hotelData) {
      setHotel(JSON.parse(decodeURIComponent(hotelData)));
    }
    
    // Simulate loading
    setTimeout(() => {
      setIsLoading(false);
      initializeConversation();
    }, 2000);
  }, []);

  const initializeConversation = async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Only send the first greeting message
    addAIMessage(`Hi there! I'm looking at ${hotel?.name} and these photos are absolutely stunning! 😍\n\nWhat do you think about this place? The lobby looks quite elegant, doesn't it?`);
  };

  const addAIMessage = (content: string) => {
    const aiMessage: BookingMessage = {
      id: Date.now().toString() + Math.random(),
      role: "ai",
      content,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, aiMessage]);
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isProcessing) return;

    const userMessage: BookingMessage = {
      id: Date.now().toString(),
      role: "user", 
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsProcessing(true);

    // AI responses based on user input
    await generateAIResponse(inputValue);
    setIsProcessing(false);
  };

  const performBookingSequence = async () => {
    // Step 1: Initial contact
    addAIMessage("Perfect! Let me get this booked for you right away...");
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Step 2: Finding contact info
    addAIMessage(`📞 Looking up ${hotel?.name} reservation line...\n\nMain: +1 (555) 847-####\nReservations: +1 (555) 847-2156\nConcierge: +1 (555) 847-####`);
    await new Promise(resolve => setTimeout(resolve, 2500));

    // Step 3: Dialing
    addAIMessage(`📱 Dialing reservations: +1 (555) 847-2156\n\n🔄 Connecting... Ring... Ring...`);
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Step 4: Connected and checking
    addAIMessage(`✅ Connected! Speaking with Sarah from reservations...\n\n🔍 Checking availability for tonight...\n📅 Found 3 available rooms:\n\n• Standard King Room - $${hotel?.price}/night\n• Deluxe King Suite - $${(hotel?.price || 0) + 75}/night\n• Premium Corner Suite - $${(hotel?.price || 0) + 150}/night\n\nWhich room would you prefer?`);
    
    // Wait for room selection instead of continuing automatically
    return;
  };

  const continueBookingWithRoom = async (roomChoice: string) => {
    let selectedRoom = "Standard King Room";
    let roomPrice = hotel?.price || 0;
    
    if (roomChoice.toLowerCase().includes('deluxe')) {
      selectedRoom = "Deluxe King Suite";
      roomPrice = (hotel?.price || 0) + 75;
    } else if (roomChoice.toLowerCase().includes('premium') || roomChoice.toLowerCase().includes('corner')) {
      selectedRoom = "Premium Corner Suite";
      roomPrice = (hotel?.price || 0) + 150;
    }

    // Step 5: Processing reservation
    addAIMessage(`Perfect choice! Securing the ${selectedRoom}...\n\n🏨 Processing your reservation details:\n• Guest: 2 Adults\n• Room: ${selectedRoom}\n• Rate: $${roomPrice}/night\n• Check-in: Today, 3:00 PM\n• Check-out: Tomorrow, 11:00 AM\n• Special requests: Late check-in`);
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Step 6: Payment and bill
    const taxes = Math.round(roomPrice * 0.12);
    const resort_fee = 35;
    const total = roomPrice + taxes + resort_fee;
    
    addAIMessage(`💳 Processing payment...\n\n═══════════════════════════════\n           HOTEL BILL PREVIEW\n═══════════════════════════════\n\n${hotel?.name}\n${hotel?.location}\n\nGuest: Your Name\nConfirmation: RX${Math.random().toString(36).substr(2, 6).toUpperCase()}\nDates: ${new Date().toLocaleDateString()} - ${new Date(Date.now() + 86400000).toLocaleDateString()}\n\n─────────────────────────────────\nROOM CHARGES:\n─────────────────────────────────\n${selectedRoom}              $${roomPrice}.00\nTaxes & Fees (12%)           $${taxes}.00\nResort Fee                   $${resort_fee}.00\n─────────────────────────────────\nTOTAL AMOUNT                 $${total}.00\n─────────────────────────────────\n\nPayment Method: Visa ****2847\nProcessing...`);
    await new Promise(resolve => setTimeout(resolve, 4000));

    // Step 7: Final confirmation
    const confirmationNumber = `RX${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    
    // Store booking details for email
    const bookingInfo = {
      hotelName: hotel?.name,
      location: hotel?.location,
      room: selectedRoom,
      confirmationNumber,
      checkIn: new Date().toISOString().split('T')[0],
      checkOut: new Date(Date.now() + 86400000).toISOString().split('T')[0],
      roomPrice,
      taxes,
      resort_fee,
      total
    };
    setBookingDetails(bookingInfo);
    
    addAIMessage(`🎉 PAYMENT APPROVED!\n\n✅ Your reservation is confirmed!\n\n📋 BOOKING CONFIRMATION:\n• Confirmation #: ${confirmationNumber}\n• Hotel: ${hotel?.name}\n• Room: ${selectedRoom}\n• Guest: ${user?.username || 'Your Name'}\n• Total Charged: $${total}.00\n\n📱 Hotel will text check-in instructions\n🎁 Complimentary breakfast included\n\n🚗 Need airport transfer? I can arrange pickup for $35`);
    
    // Show email button after confirmation
    setShowEmailButton(true);
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Step 8: Personal touch and redirect
    addAIMessage(`Perfect! I've also noted your preference for quiet rooms - they've assigned you away from elevators and ice machines.\n\nYou're all set for an amazing stay! Taking you back to the main chat where I can help with your next steps...`);
    
    // Store booking context in localStorage for main chat
    const bookingContext = {
      hotel: hotel?.name,
      location: hotel?.location,
      room: selectedRoom,
      confirmationNumber: confirmationNumber,
      checkIn: "Today, 3:00 PM",
      checkOut: "Tomorrow, 11:00 AM",
      total: total,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('recentBooking', JSON.stringify(bookingContext));
    
    // Redirect to main page after 3 seconds
    setTimeout(() => {
      setLocation("/");
    }, 3000);
  };

  const sendBillToEmail = async () => {
    if (!user?.email || !bookingDetails) return;
    
    setEmailSending(true);
    try {
      const response = await apiRequest("POST", "/api/book-hotel", {
        hotelName: bookingDetails.hotelName,
        location: bookingDetails.location,
        checkIn: bookingDetails.checkIn,
        checkOut: bookingDetails.checkOut,
        guests: 1,
        price: bookingDetails.roomPrice
      });
      
      if (response.ok) {
        const result = await response.json();
        setEmailSent(true);
        addAIMessage(`✅ Perfect! I've sent a detailed bill to your email (${user.email}). You should receive it within a few minutes.\n\nThe email includes:\n• Complete booking confirmation (${result.booking?.confirmationNumber})\n• Itemized charges breakdown\n• Hotel contact information\n• Check-in instructions\n\nTotal Amount: $${result.booking?.totalAmount || bookingDetails.total}`);
      } else {
        const error = await response.json();
        addAIMessage(`❌ Sorry, there was an issue sending the email: ${error.error || 'Unknown error'}. Please try again or contact customer service.`);
      }
    } catch (error) {
      console.error("Email sending error:", error);
      setEmailStatus('Failed to send confirmation email. Please contact support.');
      addAIMessage(`❌ Email delivery failed. Please check your connection and try again.`);
    } finally {
      setEmailSending(false);
    }
  };

  const generateAIResponse = async (userInput: string) => {
    await new Promise(resolve => setTimeout(resolve, 1500));

    const lowerInput = userInput.toLowerCase();
    
    if (lowerInput.includes('yes') || lowerInput.includes('good') || lowerInput.includes('like') || lowerInput.includes('nice')) {
      addAIMessage("I'm so glad you like it! Should I run some extra checks on the amenities and services just to make sure everything's perfect for your stay?");
      
    } else if (lowerInput.includes('check') || lowerInput.includes('sure') || lowerInput.includes('please')) {
      addAIMessage(`Perfect! Let me dive deeper into the details...\n\nI notice that ${hotel?.name} doesn't provide complimentary blankets in their standard rooms, and I also see they don't include basic toiletries like toothbrushes.\n\nShould we head back to chat and look for hotels that include these essentials, or would you prefer I book this one and we can arrange these items separately?`);
      
    } else if (lowerInput.includes('no') || lowerInput.includes('skip') || lowerInput.includes('book this')) {
      addAIMessage(`No worries! Sometimes it's good to trust your instincts.\n\nShould I go ahead and secure this booking at ${hotel?.name}? The rate looks excellent and the location is perfect!`);
      
    } else if (lowerInput.includes('book') || lowerInput.includes('confirm') || lowerInput.includes('go ahead')) {
      await performBookingSequence();
      
    } else if (lowerInput.includes('standard') || lowerInput.includes('deluxe') || lowerInput.includes('premium') || lowerInput.includes('corner')) {
      await continueBookingWithRoom(userInput);
      
    } else if (lowerInput.includes('look') || lowerInput.includes('find') || lowerInput.includes('other')) {
      addAIMessage("Absolutely! I completely understand wanting to explore other options. Let me take you back to browse more hotels that might include those extra amenities you're looking for.");
      
    } else {
      addAIMessage("I can see you're thinking it through! That's exactly the kind of careful consideration I appreciate.\n\nWould you like me to run those extra checks on the amenities, or do you have any specific concerns about this hotel?");
    }
  };

  // Generate mock hotel images based on hotel name
  const getHotelImages = (hotelName: string): HotelImages => {
    const baseUrl = "https://images.unsplash.com";
    return {
      lobby: `${baseUrl}/photo-1578662996442-48f60103fc96?w=800&h=500&fit=crop`,
      room: `${baseUrl}/photo-1631049307264-da0ec9d70304?w=800&h=500&fit=crop`,
      exterior: `${baseUrl}/photo-1564501049412-61c2a3083791?w=800&h=500&fit=crop`,
      amenities: `${baseUrl}/photo-1571896349842-33c89424de2d?w=800&h=500&fit=crop`,
      dining: `${baseUrl}/photo-1414235077428-338989a2e8c0?w=800&h=500&fit=crop`
    };
  };

  const hotelImages = hotel ? getHotelImages(hotel.name) : null;

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < Math.floor(rating) 
            ? "fill-yellow-400 text-yellow-400" 
            : "text-gray-600"
        }`}
      />
    ));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0E0E0F] flex items-center justify-center">
        <div className="text-center">
          <motion.div
            className="h-8 w-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"
          />
          <p className="text-white">Loading hotel details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0E0E0F] flex flex-col">
      {/* Header */}
      <div className="bg-[#151515] border-b border-gray-800 p-4 flex-shrink-0">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => setLocation("/")}
            className="text-gray-400 hover:text-white"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Hotels
          </Button>
          <div className="flex items-center space-x-3">
            <Heart className="h-5 w-5 text-red-400" />
            <h1 className="text-xl font-semibold text-white">
              AI Booking Assistant
            </h1>
          </div>
        </div>
      </div>

      {/* Hotel Images Section - Fixed at top */}
      <div className="bg-[#0E0E0F] border-b border-gray-800 p-6 flex-shrink-0">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-4 text-center">{hotel?.name}</h2>
          
          {/* Main Image */}
          <div className="relative h-64 rounded-xl overflow-hidden mb-4">
            <motion.img
              key={selectedImage}
              src={hotelImages?.[selectedImage as keyof HotelImages]}
              alt={`${hotel?.name} ${selectedImage}`}
              className="w-full h-full object-cover"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            />
          </div>

          {/* Image Thumbnails */}
          <div className="grid grid-cols-5 gap-3 max-w-lg mx-auto">
            {Object.entries(hotelImages || {}).map(([key, url]) => (
              <div key={key} className="text-center">
                <button
                  onClick={() => setSelectedImage(key)}
                  className={`relative h-16 w-full rounded-lg overflow-hidden border-2 transition-colors ${
                    selectedImage === key ? 'border-blue-400' : 'border-gray-600'
                  }`}
                >
                  <ImageWithFallback src={url} alt={key} className="w-full h-full object-cover" width={64} height={64} />
                  <div className="absolute inset-0 bg-black bg-opacity-20" />
                </button>
                <span className="text-xs text-gray-400 mt-1 block capitalize">{key}</span>
              </div>
            ))}
          </div>

          {/* Hotel Quick Info */}
          <div className="flex items-center justify-center space-x-8 mt-4 text-center">
            <div>
              <div className="text-xl font-bold text-green-400">${hotel?.price}/night</div>
              <div className="flex items-center justify-center space-x-1 mt-1">
                {renderStars(hotel?.rating || 0)}
                <span className="text-gray-400 text-sm ml-2">({hotel?.reviews})</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4 text-gray-400" />
              <span className="text-gray-300 text-sm">{hotel?.location}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Messages Area - Scrollable */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto p-6 space-y-6">
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-2xl p-6 ${
                    message.role === "user"
                      ? "bg-blue-600 text-white rounded-2xl"
                      : "text-white"
                  }`}
                >
                  <div className="text-base leading-relaxed whitespace-pre-wrap">
                    {message.content}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isProcessing && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="p-6 flex items-center space-x-3">
                <Loader2 className="h-5 w-5 animate-spin text-blue-400" />
                <span className="text-gray-300">AI is thinking...</span>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {/* Input Area - Fixed at bottom */}
      <div className="bg-[#0E0E0F] p-6 flex-shrink-0">
        <div className="max-w-4xl mx-auto">
          {/* Email Button - Shows after booking confirmation */}
          {showEmailButton && !emailSent && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 flex justify-center"
            >
              <Button
                onClick={sendBillToEmail}
                disabled={emailSending}
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg font-semibold rounded-xl shadow-lg"
              >
                {emailSending ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin mr-3" />
                    Sending to {user?.email}...
                  </>
                ) : (
                  <>
                    <Mail className="h-5 w-5 mr-3" />
                    Send Bill to Your Email
                  </>
                )}
              </Button>
            </motion.div>
          )}

          {/* Success message after email sent */}
          {emailSent && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 flex justify-center"
            >
              <div className="bg-green-900/50 border border-green-500 rounded-xl px-6 py-3 flex items-center">
                <Check className="h-5 w-5 text-green-400 mr-3" />
                <span className="text-green-400 font-medium">Email sent to {user?.email}</span>
              </div>
            </motion.div>
          )}

          <div className="flex space-x-4">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Type your response..."
              className="flex-1 border-0 text-base focus:ring-0 bg-transparent text-white placeholder:text-gray-400 focus-visible:ring-0 focus-visible:ring-offset-0"
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              disabled={isProcessing}
            />
            <Button 
              onClick={handleSendMessage}
              disabled={isProcessing || !inputValue.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}