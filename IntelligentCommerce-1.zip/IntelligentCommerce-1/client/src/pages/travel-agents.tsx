import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { trackPageView } from "@/lib/tracking";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  ArrowLeft, Send, Plane, Hotel, DollarSign, MessageCircle, 
  Users, Zap, Brain, Target, Clock, Play, Pause, SkipForward, Mic, MicOff
} from "lucide-react";

interface AgentMessage {
  id: string;
  agentId: 'flight' | 'travel' | 'budget';
  agentName: string;
  content: string;
  timestamp: Date;
  isDebating?: boolean;
  targetAgent?: string;
}

interface TravelRequest {
  destination: string;
  dates: string;
  budget: string;
  preferences: string;
}

export default function TravelAgents() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [messages, setMessages] = useState<AgentMessage[]>([]);
  const [input, setInput] = useState("");
  const [isDebating, setIsDebating] = useState(false);
  const [debateRound, setDebateRound] = useState(0);
  const [currentTravelRequest, setCurrentTravelRequest] = useState<TravelRequest | null>(null);
  const [showStartPlanButton, setShowStartPlanButton] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isVoiceAvailable, setIsVoiceAvailable] = useState(false);
  const [finalTripPlan, setFinalTripPlan] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const agents = {
    flight: {
      name: "FlightAgent",
      model: "Groq/Llama",
      specialty: "Flight searches & routing",
      color: "bg-blue-500",
      icon: Plane,
      personality: "Practical, efficiency-focused"
    },
    travel: {
      name: "TravelAgent", 
      model: "Gemini",
      specialty: "Hotels & experiences",
      color: "bg-green-500",
      icon: Hotel,
      personality: "Experience-oriented, quality-focused"
    },
    budget: {
      name: "BudgetAgent",
      model: "Fetch AI", 
      specialty: "Cost optimization",
      color: "bg-purple-500",
      icon: DollarSign,
      personality: "Analytical, money-conscious"
    }
  };

  useEffect(() => {
    if (user) {
      trackPageView('Travel Agents', '/travel-agents');
    }
    
    // Initialize speech recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';
      
      recognitionRef.current.onstart = () => {
        setIsListening(true);
      };
      
      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
      
      recognitionRef.current.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0])
          .map((result: any) => result.transcript)
          .join('');
          
        if (event.results[event.results.length - 1].isFinal) {
          setInput(transcript);
          if (isDebating) {
            // Interrupt the debate
            setIsDebating(false);
            addAgentMessage('flight', '🎤 *Planning interrupted by user voice input*');
          }
        }
      };
      
      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        setVoiceStatus(`Error: ${event.error}`);
      };
      
      setIsVoiceAvailable(true);
    }
    
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [user, isDebating]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const processUserRequest = useMutation({
    mutationFn: async (userMessage: string) => {
      try {
        const response = await apiRequest("POST", "/api/travel-agents/process", {
          message: userMessage,
          userId: user?.id
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
      } catch (error) {
        console.error('Error processing travel request:', error);
        setError(`Failed to process request: ${error.message || 'Unknown error'}`);
        throw error;
      }
    },
    onSuccess: (data) => {
      // Add initial agent responses
      if (data.travelRequest) {
        setCurrentTravelRequest(data.travelRequest);
        
        // Add agent responses in sequence
        setTimeout(() => addAgentMessage('flight', data.flightResponse), 500);
        setTimeout(() => addAgentMessage('travel', data.travelResponse), 1500);
        setTimeout(() => addAgentMessage('budget', data.budgetResponse), 2500);
        
        // Show start plan button after initial responses
        setTimeout(() => {
          setShowStartPlanButton(true);
        }, 4000);
      }
    },
    onError: (error) => {
      console.error('Travel request processing failed:', error);
      setError(`Travel planning failed: ${error.message || 'Unknown error'}`);
      // Add fallback message for user
      addAgentMessage('travel', 'Sorry, I encountered an issue processing your travel request. Please try again or check your connection.');
    }
  });



  const triggerDebateRound = useMutation({
    mutationFn: async ({ request, round }: { request: TravelRequest, round: number }) => {
      try {
        const response = await apiRequest("POST", "/api/travel-agents/debate", {
          request,
          round,
          previousMessages: messages.slice(-6), // Last 6 messages for context
          userId: user?.id
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
      } catch (error) {
        console.error('Error in debate round:', error);
        addAgentMessage('system', 'Sorry, an error occurred during the debate. Please try again.');
        throw error;
      }
    },
    onSuccess: (data) => {
      // Add debate responses with delays
      if (data.debates) {
        data.debates.forEach((debate: any, index: number) => {
          setTimeout(() => {
            addAgentMessage(debate.agentId, debate.content, true, debate.targetAgent);
          }, (index + 1) * 2000);
        });

        // Continue debate or conclude
        if (debateRound < 3) {
          setTimeout(() => {
            setDebateRound(prev => prev + 1);
            triggerDebateRound.mutate({ 
              request: currentTravelRequest!, 
              round: debateRound + 1 
            });
          }, data.debates.length * 2000 + 3000);
        } else {
          setTimeout(() => {
            setIsDebating(false);
            addFinalConsensus();
          }, data.debates.length * 2000 + 2000);
        }
      }
    },
    onError: (error) => {
      console.error('Debate round failed:', error);
      setError(`Debate failed: ${error.message || 'Unknown error'}`);
      setIsDebating(false);
      addAgentMessage('travel', 'The agents encountered an issue during their discussion. Let me provide a direct recommendation instead.');
    }
  });

  const addAgentMessage = (
    agentId: 'flight' | 'travel' | 'budget', 
    content: string, 
    isDebating = false,
    targetAgent?: string
  ) => {
    const agent = agents[agentId];
    const newMessage: AgentMessage = {
      id: Date.now() + Math.random().toString(),
      agentId,
      agentName: agent.name,
      content,
      timestamp: new Date(),
      isDebating,
      targetAgent
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const addFinalConsensus = () => {
    addAgentMessage('travel', "After our discussion, here's our consensus recommendation...");
    // Generate final trip plan
    generateFinalTripPlan.mutate({
      request: currentTravelRequest!,
      userId: user?.id
    });
  };

  const generateFinalTripPlan = useMutation({
    mutationFn: async ({ request, userId }: { request: TravelRequest, userId: number }) => {
      try {
        const response = await apiRequest("POST", "/api/travel-agents/generate-plan", {
          request,
          userId
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
      } catch (error) {
        console.error('Error generating trip plan:', error);
        addAgentMessage('system', 'Failed to generate trip plan. Please check your connection and try again.');
        throw error;
      }
    },
    onSuccess: (data) => {
      setFinalTripPlan(data.tripPlan);
    },
    onError: (error) => {
      console.error('Trip plan generation failed:', error);
      setError(`Trip planning failed: ${error.message || 'Unknown error'}`);
      addAgentMessage('travel', 'I had trouble generating the detailed trip plan, but I can still help you with travel recommendations. Please let me know what specific information you need.');
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Add user message
    const userMessage: AgentMessage = {
      id: Date.now().toString(),
      agentId: 'flight', // Placeholder
      agentName: user?.username || 'You',
      content: input,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    
    // Process the request
    processUserRequest.mutate(input);
    setInput("");
  };

  const pauseDebate = () => {
    setIsDebating(false);
  };

  const skipToConsensus = () => {
    setIsDebating(false);
    addFinalConsensus();
  };

  const startPlanningDebate = () => {
    setShowStartPlanButton(false);
    setIsDebating(true);
    setDebateRound(1);
    triggerDebateRound.mutate({ 
      request: currentTravelRequest!, 
      round: 1 
    });
  };

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) return;
    
    if (isListening) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
    }
  };

  const handleVoiceSubmit = () => {
    if (input.trim()) {
      handleSubmit(new Event('submit') as any);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      {/* Header */}
      <div className="border-b border-gray-800 bg-[#111111] sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation('/')}
                className="text-gray-400 hover:text-white"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Users className="w-6 h-6 text-blue-400" />
                  Travel Agents
                </h1>
                <p className="text-gray-400 text-sm">Three AI agents collaborating on your travel plans</p>
              </div>
            </div>
            
            {isDebating && (
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="border-yellow-400 text-yellow-400">
                  Debating Round {debateRound}
                </Badge>
                <Button size="sm" variant="ghost" onClick={pauseDebate}>
                  <Pause className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="ghost" onClick={skipToConsensus}>
                  <SkipForward className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Hero Title */}
      <div className="text-center py-12 px-6">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 tracking-tight">
          WORLD'S FIRST REAL TIME
        </h1>
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-2 tracking-tight">
          MULTI AI TRAVEL PLANNER
        </h1>
        <p className="text-gray-400 text-lg md:text-xl max-w-3xl mx-auto">
          Three specialized AI agents collaborate in real-time to plan your perfect trip
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6" style={{ minHeight: '600px' }}>
          {/* Agent Info Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Active Agents</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(agents).map(([id, agent]) => (
                  <div key={id} className="flex items-start gap-3 p-3 bg-gray-800/50 rounded-lg">
                    <div className={`p-2 rounded-full ${agent.color}`}>
                      <agent.icon className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-white text-sm">{agent.name}</div>
                      <div className="text-gray-400 text-xs">{agent.model}</div>
                      <div className="text-gray-500 text-xs mt-1">{agent.specialty}</div>
                      <div className="text-gray-600 text-xs italic">{agent.personality}</div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {currentTravelRequest && (
              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white text-sm">Current Request</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div><span className="text-gray-400">Destination:</span> {currentTravelRequest.destination}</div>
                  <div><span className="text-gray-400">Dates:</span> {currentTravelRequest.dates}</div>
                  <div><span className="text-gray-400">Budget:</span> {currentTravelRequest.budget}</div>
                  <div><span className="text-gray-400">Preferences:</span> {currentTravelRequest.preferences}</div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-3 flex flex-col">
            <Card className="bg-gray-900/30 border-gray-700 flex flex-col" style={{ height: '500px' }}>
              <CardContent className="p-0 flex-1 flex flex-col min-h-0">
                {/* Messages */}
                <ScrollArea className="flex-1 overflow-y-auto" style={{ height: '400px' }}>
                  <div className="p-6">
                  <div className="space-y-4">
                    {messages.length === 0 && (
                      <div className="text-center py-12">
                        <Brain className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-300 mb-2">Ready for Agent Collaboration</h3>
                        <p className="text-gray-500 max-w-md mx-auto">
                          Describe your travel plans and watch three specialized AI agents work together to find the best options.
                        </p>
                      </div>
                    )}
                    
                    {messages.map((message) => {
                      const isUser = message.agentName === user?.username;
                      const agent = !isUser ? agents[message.agentId] : null;
                      
                      return (
                        <div key={message.id} className={`flex gap-3 ${isUser ? 'justify-end' : ''}`}>
                          {!isUser && (
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className={`${agent?.color} text-white text-xs`}>
                                {agent?.name.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                          )}
                          
                          <div className={`max-w-[80%] ${isUser ? 'order-first' : ''}`}>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-medium text-gray-300">
                                {message.agentName}
                              </span>
                              {message.isDebating && (
                                <Badge variant="outline" className="border-orange-400 text-orange-400 text-xs">
                                  Debating
                                </Badge>
                              )}
                              {message.targetAgent && (
                                <span className="text-xs text-gray-500">
                                  → {agents[message.targetAgent as keyof typeof agents]?.name}
                                </span>
                              )}
                              <span className="text-xs text-gray-500">
                                {message.timestamp.toLocaleTimeString()}
                              </span>
                            </div>
                            
                            <div className={`p-3 rounded-lg ${
                              isUser 
                                ? 'bg-blue-600 text-white' 
                                : 'bg-gray-800 text-gray-100'
                            }`}>
                              <div className="prose prose-invert prose-sm max-w-none">
                                {message.content.split('\n').map((line, i) => {
                                  if (line.startsWith('### ')) {
                                    return <h3 key={i} className="text-blue-400 font-semibold mt-2 mb-1">{line.slice(4)}</h3>;
                                  } else if (line.startsWith('## ')) {
                                    return <h2 key={i} className="text-green-400 font-bold text-lg mt-3 mb-2">{line.slice(3)}</h2>;
                                  } else if (line.startsWith('- ')) {
                                    return <li key={i} className="ml-4 text-gray-200">{line.slice(2)}</li>;
                                  } else if (line.trim()) {
                                    return <p key={i} className="text-gray-100 mb-1">{line}</p>;
                                  }
                                  return <br key={i} />;
                                })}
                              </div>
                            </div>
                          </div>
                          
                          {isUser && (
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className="bg-blue-600 text-white text-xs">
                                {user?.username?.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                          )}
                        </div>
                      );
                    })}
                    
                    {(processUserRequest.isPending || triggerDebateRound.isPending) && (
                      <div className="flex items-center gap-2 text-gray-400">
                        <Zap className="w-4 h-4 animate-pulse" />
                        <span className="text-sm">Agents are processing...</span>
                      </div>
                    )}

                    {showStartPlanButton && (
                      <div className="flex justify-center py-6">
                        <Button 
                          onClick={startPlanningDebate}
                          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium px-8 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 flex items-center gap-2"
                        >
                          <Play className="w-5 h-5" />
                          Start Plan Collaboration
                        </Button>
                      </div>
                    )}
                  </div>
                  <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                {/* Input */}
                <div className="border-t border-gray-700 p-4 flex-shrink-0">
                  <div className="space-y-3">
                    {/* Voice Input Controls */}
                    {isVoiceAvailable && (
                      <div className="flex items-center justify-center">
                        <div className="flex items-center gap-4 p-3 bg-gray-800/50 rounded-full">
                          <Button
                            type="button"
                            onClick={toggleVoiceInput}
                            variant={isListening ? "destructive" : "secondary"}
                            size="sm"
                            className={`flex items-center gap-2 ${
                              isListening 
                                ? 'bg-red-600 hover:bg-red-700 animate-pulse' 
                                : 'bg-blue-600 hover:bg-blue-700'
                            }`}
                          >
                            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                            {isListening ? 'Stop Listening' : 'Voice Input'}
                          </Button>
                          
                          {isListening && (
                            <div className="flex items-center gap-2 text-blue-400">
                              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                              <span className="text-sm">Listening... (Speak to interrupt agents)</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                    
                    {/* Text Input */}
                    <form onSubmit={handleSubmit} className="flex gap-2">
                      <Input
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder={isListening ? "Voice input detected..." : "Describe your travel plans or use voice input above"}
                        className="flex-1 bg-gray-800 border-gray-600 text-white placeholder:text-gray-400"
                        disabled={processUserRequest.isPending}
                      />
                      <Button 
                        type="submit" 
                        disabled={!input.trim() || processUserRequest.isPending}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </form>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

      </div>

      {/* Final Trip Plan - Separate section below chat */}
      {finalTripPlan && (
        <div className="bg-gray-900/20 border-t border-gray-700">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <Card className="bg-gray-900/30 border-gray-700">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-white flex items-center gap-3">
                  <Target className="w-6 h-6 text-green-400" />
                  Complete {finalTripPlan.destination} Trip Plan
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-8">
                {/* Trip Overview */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <h3 className="text-green-400 font-semibold mb-2">Total Cost</h3>
                    <p className="text-2xl font-bold text-white">{finalTripPlan.totalCost}</p>
                    <p className="text-gray-400 text-sm">Per person, all inclusive</p>
                  </div>
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <h3 className="text-blue-400 font-semibold mb-2">Duration</h3>
                    <p className="text-2xl font-bold text-white">{finalTripPlan.duration}</p>
                    <p className="text-gray-400 text-sm">Days in {finalTripPlan.destination}</p>
                  </div>
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <h3 className="text-purple-400 font-semibold mb-2">Best Time</h3>
                    <p className="text-2xl font-bold text-white">{finalTripPlan.season}</p>
                    <p className="text-gray-400 text-sm">Optimal travel season</p>
                  </div>
                </div>

                {/* Flight Details */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <Plane className="w-5 h-5 text-blue-400" />
                    Flight Details
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-800/30 p-4 rounded-lg">
                      <h4 className="text-blue-400 font-medium mb-2">Outbound Flight</h4>
                      <p className="text-white">{finalTripPlan.flights.outbound.route}</p>
                      <p className="text-gray-400">{finalTripPlan.flights.outbound.time}</p>
                      <p className="text-gray-400">{finalTripPlan.flights.outbound.duration}</p>
                      <p className="text-green-400 font-semibold">{finalTripPlan.flights.outbound.price}</p>
                    </div>
                    <div className="bg-gray-800/30 p-4 rounded-lg">
                      <h4 className="text-blue-400 font-medium mb-2">Return Flight</h4>
                      <p className="text-white">{finalTripPlan.flights.return.route}</p>
                      <p className="text-gray-400">{finalTripPlan.flights.return.time}</p>
                      <p className="text-gray-400">{finalTripPlan.flights.return.duration}</p>
                      <p className="text-green-400 font-semibold">{finalTripPlan.flights.return.price}</p>
                    </div>
                  </div>
                </div>

                {/* Hotel Details */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <Hotel className="w-5 h-5 text-green-400" />
                    Accommodation
                  </h3>
                  <div className="bg-gray-800/30 p-6 rounded-lg">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-green-400 font-semibold text-lg mb-2">{finalTripPlan.hotel.name}</h4>
                        <p className="text-gray-300 mb-3">{finalTripPlan.hotel.description}</p>
                        <div className="space-y-2">
                          <p><span className="text-gray-400">Location:</span> <span className="text-white">{finalTripPlan.hotel.location}</span></p>
                          <p><span className="text-gray-400">Room Type:</span> <span className="text-white">{finalTripPlan.hotel.roomType}</span></p>
                          <p><span className="text-gray-400">Check-in:</span> <span className="text-white">{finalTripPlan.hotel.checkIn}</span></p>
                          <p><span className="text-gray-400">Check-out:</span> <span className="text-white">{finalTripPlan.hotel.checkOut}</span></p>
                          <p><span className="text-gray-400">Price:</span> <span className="text-green-400 font-semibold">{finalTripPlan.hotel.price}</span></p>
                        </div>
                        <div className="mt-4">
                          <h5 className="text-blue-400 font-medium mb-2">Amenities</h5>
                          <div className="flex flex-wrap gap-2">
                            {(finalTripPlan.hotel?.amenities || []).map((amenity: string, index: number) => (
                              <Badge key={index} variant="outline" className="border-gray-600 text-gray-300">
                                {amenity}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-700/50 rounded-lg p-4 flex items-center justify-center">
                        <div className="text-center text-gray-400">
                          <Hotel className="w-16 h-16 mx-auto mb-2 opacity-50" />
                          <p>Hotel Image</p>
                          <p className="text-sm">{finalTripPlan.hotel.name}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Daily Itinerary */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <Clock className="w-5 h-5 text-purple-400" />
                    Daily Itinerary
                  </h3>
                  <div className="space-y-4">
                    {(finalTripPlan.itinerary || []).map((day: any, index: number) => (
                      <div key={index} className="bg-gray-800/30 p-4 rounded-lg">
                        <h4 className="text-purple-400 font-semibold mb-3">Day {day.day}: {day.theme}</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {(day.activities || []).map((activity: any, actIndex: number) => (
                            <div key={actIndex} className="bg-gray-700/50 p-3 rounded">
                              <h5 className="text-white font-medium">{activity.name}</h5>
                              <p className="text-gray-400 text-sm">{activity.time}</p>
                              <p className="text-gray-300 text-sm mt-1">{activity.description}</p>
                              <p className="text-green-400 text-sm font-medium mt-1">{activity.cost}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Scenic Locations */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <Target className="w-5 h-5 text-yellow-400" />
                    Must-Visit Scenic Locations
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {(finalTripPlan.scenicLocations || []).map((location: any, index: number) => (
                      <div key={index} className="bg-gray-800/30 p-4 rounded-lg">
                        <div className="bg-gray-700/50 rounded-lg p-4 mb-3 flex items-center justify-center h-32">
                          <div className="text-center text-gray-400">
                            <Target className="w-8 h-8 mx-auto mb-1 opacity-50" />
                            <p className="text-xs">{location.name}</p>
                          </div>
                        </div>
                        <h4 className="text-yellow-400 font-medium mb-2">{location.name}</h4>
                        <p className="text-gray-300 text-sm mb-2">{location.description}</p>
                        <div className="text-xs text-gray-400">
                          <p>Best time: {location.bestTime}</p>
                          <p>Duration: {location.duration}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Transportation Details */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-orange-400" />
                    Transportation & Local Travel
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {(finalTripPlan.transportation || []).map((transport: any, index: number) => (
                      <div key={index} className="bg-gray-800/30 p-4 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-orange-400 font-medium">{transport.type}</h4>
                          <Badge variant="outline" className="border-orange-400 text-orange-400">
                            {transport.brand}
                          </Badge>
                        </div>
                        <p className="text-white text-sm mb-1">{transport.route}</p>
                        <div className="flex justify-between items-center text-xs text-gray-400">
                          <span>{transport.time}</span>
                          <span className="text-green-400 font-semibold">{transport.price}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Authentic Mock Bills */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-yellow-400" />
                    Trip Receipts & Bills
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {(finalTripPlan.mockBills || []).map((bill: any, index: number) => (
                      <div key={index} className="bg-gray-800/30 p-4 rounded-lg border border-gray-700">
                        <div className="border-b border-gray-600 pb-2 mb-3">
                          <div className="flex justify-between items-center">
                            <h4 className="text-yellow-400 font-bold">{bill.company}</h4>
                            <Badge variant="outline" className="border-yellow-400 text-yellow-400">
                              {bill.type}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-400">{bill.address}</p>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-300">Receipt #:</span>
                            <span className="text-white font-mono">{bill.receiptNumber}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-300">Date:</span>
                            <span className="text-white">{bill.date}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-300">Time:</span>
                            <span className="text-white">{bill.time}</span>
                          </div>
                          <div className="border-t border-gray-600 pt-2">
                            {(bill.items || []).map((item: any, itemIndex: number) => (
                              <div key={itemIndex} className="flex justify-between text-sm">
                                <span className="text-gray-300">{item.description}</span>
                                <span className="text-white">{item.amount}</span>
                              </div>
                            ))}
                          </div>
                          <div className="border-t border-gray-600 pt-2 mt-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-300">Subtotal:</span>
                              <span className="text-white">{bill.subtotal}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-300">Tax:</span>
                              <span className="text-white">{bill.tax}</span>
                            </div>
                            <div className="flex justify-between text-lg font-bold">
                              <span className="text-yellow-400">Total:</span>
                              <span className="text-yellow-400">{bill.total}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cost Breakdown */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-green-400" />
                    Cost Breakdown
                  </h3>
                  <div className="bg-gray-800/30 p-4 rounded-lg">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                      <div>
                        <p className="text-gray-400 text-sm">Flights</p>
                        <p className="text-white font-semibold">{finalTripPlan.costBreakdown.flights}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Hotel</p>
                        <p className="text-white font-semibold">{finalTripPlan.costBreakdown.hotel}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Activities</p>
                        <p className="text-white font-semibold">{finalTripPlan.costBreakdown.activities}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Food & Misc</p>
                        <p className="text-white font-semibold">{finalTripPlan.costBreakdown.food}</p>
                      </div>
                    </div>
                    <div className="border-t border-gray-600 mt-4 pt-4 text-center">
                      <p className="text-lg font-bold text-green-400">Total: {finalTripPlan.totalCost}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}