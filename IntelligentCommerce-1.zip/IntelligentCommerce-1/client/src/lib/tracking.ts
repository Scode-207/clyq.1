import { apiRequest } from "./queryClient";

export interface TrackingData {
  action: string;
  entityType: string;
  entityId: string;
  entityName: string;
  metadata?: any;
}

// Track user interactions for knowledge graph
export const trackInteraction = async (data: TrackingData) => {
  try {
    await apiRequest('POST', '/api/knowledge-graph/track', data);
  } catch (error) {
    // Silently fail - don't disrupt user experience
    console.log('Interaction tracking failed:', error);
  }
};

// Helper functions for common tracking scenarios
export const trackProductView = (productId: string, productName: string, metadata: any = {}) => {
  trackInteraction({
    action: 'view',
    entityType: 'product',
    entityId: productId,
    entityName: productName,
    metadata: { ...metadata, timestamp: Date.now() }
  });
};

export const trackProductLike = (productId: string, productName: string, metadata: any = {}) => {
  trackInteraction({
    action: 'like',
    entityType: 'product',
    entityId: productId,
    entityName: productName,
    metadata: { ...metadata, timestamp: Date.now() }
  });
};

export const trackSearch = (query: string, category?: string) => {
  trackInteraction({
    action: 'search',
    entityType: 'query',
    entityId: `search_${Date.now()}`,
    entityName: query,
    metadata: { category, timestamp: Date.now() }
  });
};

export const trackPageView = (pageName: string, route: string) => {
  trackInteraction({
    action: 'view',
    entityType: 'page',
    entityId: route,
    entityName: pageName,
    metadata: { timestamp: Date.now() }
  });
};

export const trackChatInteraction = (conversationId: string, message: string, domain?: string) => {
  trackInteraction({
    action: 'chat',
    entityType: 'conversation',
    entityId: conversationId,
    entityName: 'Chat Message',
    metadata: { domain, messageLength: message.length, timestamp: Date.now() }
  });
};