import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";

export function ProtectedRoute({
  path,
  component: Component,
}: {
  path: string;
  component: () => React.JSX.Element;
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen bg-[#0A0A0A]">
          <div className="text-center space-y-4">
            <Loader2 className="h-8 w-8 animate-spin text-electric-blue mx-auto" />
            <p className="text-gray-400">Loading your workspace...</p>
          </div>
        </div>
      </Route>
    );
  }

  if (!user) {
    return (
      <Route path={path}>
        <Redirect to="/auth" />
      </Route>
    );
  }

  // If user hasn't completed their profile, redirect to onboarding
  if (!user.profileComplete && path !== "/onboarding") {
    return (
      <Route path={path}>
        <Redirect to="/onboarding" />
      </Route>
    );
  }

  return <Route path={path}><Component /></Route>;
}