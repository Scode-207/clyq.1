// Client-side OpenAI utilities (for future client-side AI features)
export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  timestamp?: Date;
}

export interface AIResponse {
  content: string;
  suggestions?: Array<{
    type: string;
    title: string;
    description: string;
    data: any;
  }>;
  domain?: string;
}

// Utility functions for processing AI responses
export function parseAIResponse(response: string): AIResponse {
  try {
    return JSON.parse(response);
  } catch (error) {
    return {
      content: response,
      suggestions: [],
      domain: "general"
    };
  }
}

export function formatChatHistory(messages: ChatMessage[]): Array<{ role: "user" | "assistant"; content: string }> {
  return messages.map(msg => ({
    role: msg.role,
    content: msg.content
  }));
}

export function extractDomainFromMessage(message: string): "food" | "travel" | "marketplace" | "general" {
  const foodKeywords = ["restaurant", "food", "meal", "order", "cuisine", "delivery", "eat"];
  const travelKeywords = ["hotel", "flight", "trip", "travel", "vacation", "booking", "destination"];
  const marketplaceKeywords = ["buy", "purchase", "product", "shop", "gear", "equipment", "brand"];

  const lowerMessage = message.toLowerCase();

  if (foodKeywords.some(keyword => lowerMessage.includes(keyword))) {
    return "food";
  }
  
  if (travelKeywords.some(keyword => lowerMessage.includes(keyword))) {
    return "travel";
  }
  
  if (marketplaceKeywords.some(keyword => lowerMessage.includes(keyword))) {
    return "marketplace";
  }

  return "general";
}
