import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Message } from "@shared/schema";

interface SendMessageData {
  content: string;
  type?: "text" | "voice" | "image";
  domain?: "food" | "travel" | "marketplace";
  recentBooking?: any;
}

export function useChat(conversationId: number | null) {
  const [isTyping, setIsTyping] = useState(false);
  const queryClient = useQueryClient();

  // Get messages for the current conversation
  const { data: messages = [], isLoading, isError, error } = useQuery({
    queryKey: ["/api/conversations", conversationId, "messages"],
    queryFn: async () => {
      if (!conversationId) return [];
      const response = await apiRequest("GET", `/api/conversations/${conversationId}/messages`);
      const data = await response.json();
      return data || [];
    },
    enabled: !!conversationId,
    initialData: [],
    refetchOnWindowFocus: false,
  });

  // Create new conversation
  const createConversationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/conversations", {});
      return response.json();
    },
    onSuccess: (conversation) => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      return conversation;
    },
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ conversationId, data }: { conversationId: number; data: SendMessageData }) => {
      const response = await apiRequest("POST", `/api/conversations/${conversationId}/messages`, data);
      return response.json();
    },
    onMutate: () => {
      setIsTyping(true);
    },
    onSuccess: (data, variables) => {
      // Invalidate and refetch messages to ensure UI updates immediately
      queryClient.invalidateQueries({ 
        queryKey: ["/api/conversations", variables.conversationId, "messages"] 
      });
      queryClient.refetchQueries({ 
        queryKey: ["/api/conversations", variables.conversationId, "messages"] 
      });
      setIsTyping(false);
    },
    onError: () => {
      setIsTyping(false);
    },
  });

  const sendMessage = async (content: string, type: "text" | "voice" | "image" = "text", domain?: "food" | "travel" | "marketplace" | "medical") => {
    let activeConversationId = conversationId;

    // Create conversation if none exists
    if (!activeConversationId) {
      const newConversation = await createConversationMutation.mutateAsync();
      activeConversationId = newConversation.id;
    }

    if (activeConversationId) {
      // Check for recent booking context in localStorage
      const recentBookingData = localStorage.getItem('recentBooking');
      let recentBooking = null;
      
      if (recentBookingData) {
        try {
          const booking = JSON.parse(recentBookingData);
          // Only use booking if it's within the last hour
          const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
          if (new Date(booking.timestamp) > oneHourAgo) {
            recentBooking = booking;
            // Clear it after using once to avoid confusion
            localStorage.removeItem('recentBooking');
          }
        } catch (error) {
          console.error('Error parsing recent booking data:', error);
        }
      }
      
      return sendMessageMutation.mutateAsync({
        conversationId: activeConversationId,
        data: { content, type, domain, recentBooking }
      });
    }
  };

  return {
    messages: messages as Message[],
    isLoading,
    isError,
    error,
    isTyping,
    sendMessage,
    isCreatingConversation: createConversationMutation.isPending,
    isSendingMessage: sendMessageMutation.isPending,
  };
}
