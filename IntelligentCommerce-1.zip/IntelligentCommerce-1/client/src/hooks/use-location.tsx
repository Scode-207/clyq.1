import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';

interface UserLocation {
  latitude: number;
  longitude: number;
  city: string;
  state: string;
  country: string;
  zipCode?: string;
  address?: string;
}

interface LocationError {
  code: number;
  message: string;
}

export function useLocation() {
  const [location, setLocation] = useState<UserLocation | null>(null);
  const [error, setError] = useState<LocationError | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Get location from IP as fallback
  const { data: ipLocation } = useQuery({
    queryKey: ['location', 'ip'],
    queryFn: async () => {
      const response = await fetch('/api/location/from-ip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      if (!response.ok) throw new Error('Failed to get location from IP');
      return response.json();
    },
    enabled: !location,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Reverse geocoding mutation
  const reverseGeocodeMutation = useMutation({
    mutationFn: async ({ latitude, longitude }: { latitude: number; longitude: number }) => {
      const response = await fetch('/api/location/reverse-geocode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ latitude, longitude })
      });
      if (!response.ok) throw new Error('Failed to reverse geocode');
      return response.json();
    },
    onSuccess: (data) => {
      setLocation(data);
      setError(null);
    },
    onError: (error: any) => {
      setError({ code: 2, message: error.message });
    }
  });

  // Get precise location using browser geolocation API
  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      setError({ code: 0, message: 'Geolocation is not supported by this browser.' });
      return;
    }

    setIsLoading(true);
    setError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        reverseGeocodeMutation.mutate({ latitude, longitude });
        setIsLoading(false);
      },
      (error) => {
        setIsLoading(false);
        setError({
          code: error.code,
          message: getGeolocationErrorMessage(error.code)
        });
        
        // Fallback to IP location if geolocation fails
        if (ipLocation) {
          setLocation(ipLocation);
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000, // 5 minutes
      }
    );
  };

  // Auto-get location on mount
  useEffect(() => {
    if (!location && ipLocation) {
      setLocation(ipLocation);
    }
  }, [ipLocation, location]);

  // Auto-request precise location if user hasn't denied it
  useEffect(() => {
    const hasAskedForLocation = localStorage.getItem('hasAskedForLocation');
    if (!hasAskedForLocation && !location) {
      getCurrentLocation();
      localStorage.setItem('hasAskedForLocation', 'true');
    }
  }, [location]);

  const getGeolocationErrorMessage = (code: number): string => {
    switch (code) {
      case 1:
        return 'Location access denied by user. Using approximate location.';
      case 2:
        return 'Location information is unavailable. Using approximate location.';
      case 3:
        return 'Location request timed out. Using approximate location.';
      default:
        return 'An unknown error occurred while retrieving location.';
    }
  };

  return {
    location: location || ipLocation,
    error,
    isLoading: isLoading || reverseGeocodeMutation.isPending,
    getCurrentLocation,
    hasPermission: location && !ipLocation, // True if we have precise GPS location
    isApproximate: !location || (location === ipLocation), // True if using IP-based location
  };
}

// Hook for search functionality with location
export function useLocationSearch() {
  const { location } = useLocation();

  const searchRestaurants = useMutation({
    mutationFn: async ({ cuisine, customLocation }: { cuisine?: string; customLocation?: string }) => {
      const searchParams: any = {};
      
      if (customLocation) {
        searchParams.location = customLocation;
      } else if (location) {
        searchParams.latitude = location.latitude;
        searchParams.longitude = location.longitude;
      } else {
        throw new Error('No location available');
      }
      
      if (cuisine) searchParams.cuisine = cuisine;

      const response = await fetch('/api/search/restaurants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(searchParams)
      });
      
      if (!response.ok) throw new Error('Failed to search restaurants');
      return response.json();
    }
  });

  const searchHotels = useMutation({
    mutationFn: async ({ 
      destination, 
      checkIn, 
      checkOut, 
      guests 
    }: { 
      destination: string; 
      checkIn?: string; 
      checkOut?: string; 
      guests?: number;
    }) => {
      const response = await fetch('/api/search/hotels', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ location: destination, checkIn, checkOut, guests })
      });
      
      if (!response.ok) throw new Error('Failed to search hotels');
      return response.json();
    }
  });

  const searchFlights = useMutation({
    mutationFn: async ({ 
      origin, 
      destination, 
      departureDate, 
      returnDate 
    }: { 
      origin: string; 
      destination: string; 
      departureDate?: string; 
      returnDate?: string;
    }) => {
      const response = await fetch('/api/search/flights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ origin, destination, departureDate, returnDate })
      });
      
      if (!response.ok) throw new Error('Failed to search flights');
      return response.json();
    }
  });

  return {
    searchRestaurants,
    searchHotels,
    searchFlights,
    currentLocation: location,
  };
}