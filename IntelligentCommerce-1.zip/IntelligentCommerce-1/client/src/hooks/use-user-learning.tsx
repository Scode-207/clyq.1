import { useState, useCallback, useEffect } from 'react';
import { useAuth } from './use-auth';

export interface UserPattern {
  id: string;
  type: 'preference' | 'behavior' | 'interaction' | 'timing' | 'context';
  category: string;
  pattern: string;
  confidence: number;
  frequency: number;
  lastSeen: Date;
  examples: string[];
  impact: 'high' | 'medium' | 'low';
}

export interface LearningNotification {
  id: string;
  type: 'new_pattern' | 'pattern_update' | 'insight' | 'recommendation';
  title: string;
  description: string;
  pattern: UserPattern;
  timestamp: Date;
  isRead: boolean;
  category: string;
}

export function useUserLearning() {
  const { user } = useAuth();
  const [patterns, setPatterns] = useState<UserPattern[]>([]);
  const [notifications, setNotifications] = useState<LearningNotification[]>([]);
  const [isLearning, setIsLearning] = useState(false);

  // Simulate learning from user interactions
  const learnFromInteraction = useCallback((
    message: string,
    context: {
      domain?: string;
      timeOfDay?: string;
      responseTime?: number;
      userSatisfaction?: number;
    }
  ) => {
    if (!user) return;

    setIsLearning(true);
    
    // Simulate ML processing delay
    setTimeout(() => {
      const newPatterns = analyzeUserMessage(message, context);
      
      newPatterns.forEach(pattern => {
        const existingPattern = patterns.find(p => p.category === pattern.category);
        
        if (existingPattern) {
          // Update existing pattern
          setPatterns(prev => prev.map(p => 
            p.id === existingPattern.id 
              ? { ...p, confidence: Math.min(p.confidence + 0.1, 1), frequency: p.frequency + 1, lastSeen: new Date() }
              : p
          ));
          
          // Create update notification
          const notification: LearningNotification = {
            id: `notif-${Date.now()}`,
            type: 'pattern_update',
            title: `Updated ${pattern.category} pattern`,
            description: `Confidence increased to ${Math.round((existingPattern.confidence + 0.1) * 100)}%`,
            pattern: { ...existingPattern, confidence: existingPattern.confidence + 0.1 },
            timestamp: new Date(),
            isRead: false,
            category: pattern.category
          };
          
          setNotifications(prev => [notification, ...prev]);
        } else {
          // Add new pattern
          setPatterns(prev => [...prev, pattern]);
          
          // Create new pattern notification
          const notification: LearningNotification = {
            id: `notif-${Date.now()}`,
            type: 'new_pattern',
            title: `New ${pattern.category} pattern discovered`,
            description: pattern.pattern,
            pattern,
            timestamp: new Date(),
            isRead: false,
            category: pattern.category
          };
          
          setNotifications(prev => [notification, ...prev]);
        }
      });
      
      setIsLearning(false);
    }, 1500);
  }, [user, patterns]);

  // Analyze user message and extract patterns
  const analyzeUserMessage = (message: string, context: any): UserPattern[] => {
    const patterns: UserPattern[] = [];
    const messageWords = message.toLowerCase().split(' ');
    
    // Food preferences
    if (messageWords.some(word => ['italian', 'chinese', 'mexican', 'healthy', 'vegan', 'vegetarian'].includes(word))) {
      const cuisineMatch = messageWords.find(word => ['italian', 'chinese', 'mexican', 'indian', 'thai'].includes(word));
      const dietMatch = messageWords.find(word => ['healthy', 'vegan', 'vegetarian', 'keto', 'organic'].includes(word));
      
      if (cuisineMatch) {
        patterns.push({
          id: `pattern-cuisine-${Date.now()}`,
          type: 'preference',
          category: 'Cuisine Preference',
          pattern: `Prefers ${cuisineMatch} cuisine`,
          confidence: 0.7,
          frequency: 1,
          lastSeen: new Date(),
          examples: [message],
          impact: 'high'
        });
      }
      
      if (dietMatch) {
        patterns.push({
          id: `pattern-diet-${Date.now()}`,
          type: 'preference',
          category: 'Dietary Preference',
          pattern: `Interested in ${dietMatch} options`,
          confidence: 0.8,
          frequency: 1,
          lastSeen: new Date(),
          examples: [message],
          impact: 'high'
        });
      }
    }
    
    // Price sensitivity
    if (messageWords.some(word => ['cheap', 'expensive', 'budget', 'affordable', 'luxury', 'premium'].includes(word))) {
      const priceIndicator = messageWords.find(word => ['cheap', 'expensive', 'budget', 'affordable', 'luxury', 'premium'].includes(word));
      patterns.push({
        id: `pattern-price-${Date.now()}`,
        type: 'preference',
        category: 'Price Sensitivity',
        pattern: `Shows ${priceIndicator} price preference`,
        confidence: 0.6,
        frequency: 1,
        lastSeen: new Date(),
        examples: [message],
        impact: 'medium'
      });
    }
    
    // Location patterns
    if (messageWords.some(word => ['near', 'nearby', 'close', 'around', 'within'].includes(word))) {
      patterns.push({
        id: `pattern-location-${Date.now()}`,
        type: 'behavior',
        category: 'Location Preference',
        pattern: 'Prefers nearby/local options',
        confidence: 0.8,
        frequency: 1,
        lastSeen: new Date(),
        examples: [message],
        impact: 'high'
      });
    }
    
    // Time-based patterns
    const hour = new Date().getHours();
    if (hour < 12) {
      patterns.push({
        id: `pattern-time-${Date.now()}`,
        type: 'timing',
        category: 'Usage Time',
        pattern: 'Active during morning hours',
        confidence: 0.5,
        frequency: 1,
        lastSeen: new Date(),
        examples: [message],
        impact: 'low'
      });
    } else if (hour < 17) {
      patterns.push({
        id: `pattern-time-${Date.now()}`,
        type: 'timing',
        category: 'Usage Time',
        pattern: 'Active during afternoon hours',
        confidence: 0.5,
        frequency: 1,
        lastSeen: new Date(),
        examples: [message],
        impact: 'low'
      });
    } else {
      patterns.push({
        id: `pattern-time-${Date.now()}`,
        type: 'timing',
        category: 'Usage Time',
        pattern: 'Active during evening hours',
        confidence: 0.5,
        frequency: 1,
        lastSeen: new Date(),
        examples: [message],
        impact: 'low'
      });
    }
    
    // Interaction style
    if (message.includes('?')) {
      patterns.push({
        id: `pattern-interaction-${Date.now()}`,
        type: 'interaction',
        category: 'Communication Style',
        pattern: 'Prefers asking questions',
        confidence: 0.4,
        frequency: 1,
        lastSeen: new Date(),
        examples: [message],
        impact: 'low'
      });
    }
    
    if (message.length > 50) {
      patterns.push({
        id: `pattern-detail-${Date.now()}`,
        type: 'behavior',
        category: 'Detail Preference',
        pattern: 'Provides detailed requests',
        confidence: 0.6,
        frequency: 1,
        lastSeen: new Date(),
        examples: [message],
        impact: 'medium'
      });
    }
    
    return patterns;
  };

  // Generate insights from patterns
  const generateInsights = useCallback(() => {
    const insights: LearningNotification[] = [];
    
    // High-confidence patterns
    const highConfidencePatterns = patterns.filter(p => p.confidence > 0.8);
    if (highConfidencePatterns.length > 0) {
      insights.push({
        id: `insight-${Date.now()}`,
        type: 'insight',
        title: 'Strong Preferences Identified',
        description: `You consistently show strong preferences for ${highConfidencePatterns.map(p => p.category.toLowerCase()).join(', ')}`,
        pattern: highConfidencePatterns[0],
        timestamp: new Date(),
        isRead: false,
        category: 'General'
      });
    }
    
    // Frequent patterns
    const frequentPatterns = patterns.filter(p => p.frequency > 3);
    if (frequentPatterns.length > 0) {
      insights.push({
        id: `insight-frequent-${Date.now()}`,
        type: 'insight',
        title: 'Recurring Behaviors Detected',
        description: `You frequently engage with ${frequentPatterns.map(p => p.category.toLowerCase()).join(', ')}`,
        pattern: frequentPatterns[0],
        timestamp: new Date(),
        isRead: false,
        category: 'Behavior'
      });
    }
    
    setNotifications(prev => [...insights, ...prev]);
  }, [patterns]);

  // Mark notification as read
  const markAsRead = useCallback((notificationId: string) => {
    setNotifications(prev => prev.map(n => 
      n.id === notificationId ? { ...n, isRead: true } : n
    ));
  }, []);

  // Clear all notifications
  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  // Get unread notifications count
  const unreadCount = notifications.filter(n => !n.isRead).length;

  return {
    patterns,
    notifications,
    isLearning,
    unreadCount,
    learnFromInteraction,
    generateInsights,
    markAsRead,
    clearAllNotifications
  };
}