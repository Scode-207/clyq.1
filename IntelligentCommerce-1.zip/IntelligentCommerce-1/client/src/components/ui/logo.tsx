import { cn } from "@/lib/utils";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
  className?: string;
}

export default function Logo({ size = "md", showText = false, className }: LogoProps) {
  const logoSizes = {
    sm: "text-base",
    md: "text-lg", 
    lg: "text-xl"
  };

  return (
    <div className={cn("flex items-center space-x-3", className)}>
      {/* CLYQ Geometric Logo */}
      <div className={cn("geometric-logo", logoSizes[size])}>
        Cly<span className="logo-q">Q</span>
      </div>
      
      {/* Expandable Text */}
      {showText && (
        <div>
          <h1 className="text-white font-semibold text-lg">CLYQ</h1>
          <p className="text-gray-400 text-sm">AI Commerce Agent</p>
        </div>
      )}
    </div>
  );
}