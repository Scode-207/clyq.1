# CLYQ - World's First Social Commerce Ecosystem

## Overview

CLYQ redefines commerce with a revolutionary insight: commerce is not just tied to you alone, it is tied to the entire world around you. Our platform enables users to buy, sell, plan and live along with their friends and family through the world's first multi-domain social commerce ecosystem with collaborative group planning features.

**🌍 Social Commerce Revolution**: While Amazon lets YOU buy items, CLYQ lets YOU ALONG WITH YOUR FRIENDS to plan, analyze, collaborate and buy, sell, and even plan trips together. Our social commerce feeds allow users to share product journeys, refurbishments, and discoveries, creating a vibrant community where commerce becomes a shared experience.

**🤖 World's First Multi-AI Agent Debate System**: Experience the revolutionary three-agent AI system featuring FlightAgent (Groq), TravelAgent (Gemini), and BudgetAgent (Fetch AI) that engage in structured debates to provide superior travel recommendations. Users witness transparent AI reasoning through controlled agent discussions, voice interruption capabilities, and real-time collaborative planning.

**👥 Collaborative Group Planning**: Plan trips, analyze purchases, and make decisions together with friends and family. Share itineraries, split costs, vote on destinations, and coordinate group activities through our advanced social planning interface.

**🗣️ Voice-Driven Social Marketplace**: Speak "red sneakers" and watch curated products appear while your friends can simultaneously contribute suggestions and opinions. The entire interface morphs based on group preferences with smooth animations and real-time collaborative filtering.

**🛡️ Advanced Group Security**: Industry-leading fraud detection with group verification, where friends can validate sellers and warn about suspicious activities, creating a community-driven safety network.

**📍 Location-Aware Social Intelligence**: Real-time location sharing with friends, group restaurant discovery, and collaborative travel booking with authentic photos and verified business data.

**🧠 Social Knowledge Graph**: Dynamic preference mapping that learns from both individual and group behaviors, creating personalized recommendations that consider social connections and friend preferences.

CLYQ transforms isolated commerce into connected experiences, where every purchase, trip, and decision becomes an opportunity to connect, collaborate, and create memories with the people who matter most.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **UI Framework**: Radix UI components with custom shadcn/ui styling
- **Styling**: Tailwind CSS with custom dark luxury theme
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **AI Integration**: OpenAI GPT-4o for conversational AI
- **Module System**: ES Modules throughout

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon Database
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations
- **Development Storage**: In-memory storage class for development/testing

## Key Components

### Core Features
1. **Conversational AI Interface**: Natural language processing for user queries across multiple domains
2. **Multi-Domain Commerce**: Food ordering, travel booking, and marketplace shopping
3. **Personalized Recommendations**: AI-driven suggestions based on user preferences and history
4. **Voice Input Support**: Speech-to-text capabilities for hands-free interaction
5. **Knowledge Graph**: User preference tracking and relationship mapping
6. **Responsive Design**: Mobile-first approach with desktop optimization

### UI Components
- **Sidebar Navigation**: Persistent navigation with domain-specific sections
- **Chat Interface**: Real-time messaging with typing indicators and suggestions
- **Commerce Cards**: Specialized components for hotels, restaurants, and products
- **Knowledge Graph Panel**: User profile and preference visualization
- **Voice Input Controls**: Integrated microphone and speech recognition

### Database Schema
- **Users**: User profiles with preferences and knowledge graph data
- **Conversations**: Chat session management
- **Messages**: Individual messages with metadata and AI-generated suggestions

## Data Flow

1. **User Input**: Voice or text input captured through the chat interface
2. **Domain Detection**: AI analyzes input to determine intent (food, travel, marketplace)
3. **Context Building**: System builds conversation context including user preferences
4. **AI Processing**: OpenAI GPT-4o generates contextual responses and suggestions
5. **Commerce Integration**: Mock commerce services provide relevant product/service data
6. **Response Rendering**: Specialized components render AI responses with interactive elements
7. **Preference Learning**: User interactions update the knowledge graph for future personalization

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL driver
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Comprehensive UI component library
- **drizzle-orm**: TypeScript ORM for PostgreSQL
- **openai**: Official OpenAI API client
- **date-fns**: Date manipulation utilities
- **wouter**: Lightweight routing library

### AI and Commerce Services
- **Groq LLaMA 3.3 70B**: Ultra-fast conversational AI with superior reasoning
- **Amazon Product Advertising API**: Real product search, pricing, and recommendations
- **Zomato API**: Live restaurant data, menus, ratings, and delivery options
- **MakeMyTrip API**: Hotel bookings, flight searches, and travel itineraries
- **Hyper-Personalization Engine**: Advanced user behavior analysis and predictive recommendations
- **Web Speech API**: Browser-native voice recognition for hands-free interaction

## Deployment Strategy

### Development Environment
- **Build Process**: Vite handles frontend bundling and development server
- **Server Build**: esbuild compiles TypeScript server code
- **Database**: Neon Database with Drizzle migrations
- **Environment Variables**: DATABASE_URL and OPENAI_API_KEY required

### Production Deployment
- **Frontend**: Static assets served from `/dist/public`
- **Backend**: Node.js server with compiled TypeScript
- **Database**: Neon Database (serverless PostgreSQL)
- **Build Commands**:
  - `npm run build`: Compiles both frontend and backend
  - `npm run start`: Runs production server
  - `npm run db:push`: Applies database schema changes

### Architecture Decisions

1. **Neon Database Choice**: Serverless PostgreSQL provides automatic scaling and reduced operational overhead while maintaining PostgreSQL compatibility
2. **Drizzle ORM**: Type-safe database operations with excellent TypeScript integration and migration support
3. **In-Memory Development Storage**: Allows rapid development and testing without database dependencies
4. **Groq LLaMA 3.3 70B**: Ultra-fast inference with advanced reasoning capabilities, significantly faster than traditional GPU-based models
5. **Real API Integrations**: Direct integration with Amazon, Zomato, and MakeMyTrip for authentic, real-time commerce data
6. **Hyper-Personalization Engine**: Advanced behavior profiling with contextual awareness (time, location, weather, social context)
7. **Radix UI Foundation**: Provides accessible, unstyled components that can be customized to match the dark luxury design
8. **TanStack Query**: Handles complex server state management with caching, background updates, and optimistic updates

## Three-Agent AI System Architecture

### Overview
A revolutionary multi-agent debate system where three specialized AI agents collaborate through structured reasoning, controlled debates, and consensus-building to provide superior recommendations and insights.

### Agent Specializations
1. **Analyst Agent (Data-Driven)**: Focuses on market analysis, price comparisons, user behavior patterns
2. **Advisor Agent (User-Centric)**: Emphasizes personalization, user preferences, emotional intelligence
3. **Critic Agent (Quality Control)**: Challenges assumptions, identifies risks, ensures accuracy

### Debate Protocol
- **Turn-Based System**: Agents speak in controlled rounds, preventing spam
- **Debate Topics**: Product recommendations, travel planning, dining choices
- **Consensus Mechanism**: Weighted voting based on expertise relevance
- **User Control**: Can pause, skip, or request deeper analysis

### Value Propositions
1. **Better Decisions**: Multiple perspectives reduce bias
2. **Transparent Reasoning**: Users see the thought process
3. **Adaptive Intelligence**: Agents learn from debate outcomes
4. **Trust Building**: Disagreements show honest analysis

## Changelog

```
Changelog:
- July 06, 2025. Initial setup with basic AI chat interface
- July 06, 2025. Upgraded to Groq API with LLaMA 3.3 70B model
- July 06, 2025. Implemented real API integrations:
  * Amazon Product Advertising API for marketplace shopping
  * Zomato API for restaurant discovery and food ordering
  * MakeMyTrip API for travel booking and hotel reservations
- July 06, 2025. Added hyper-personalization service with:
  * User behavior profiling and pattern recognition
  * Contextual recommendations based on time, location, and preferences
  * Real-time integration with all commerce platforms
  * Predictive analytics for shopping and dining patterns
- July 06, 2025. Implemented Tavily + SERP fusion approach:
  * Tavily API for AI-friendly real-time restaurant data
  * SERP API specifically for authentic restaurant images
  * IP-based location detection for location-aware searches
  * Enhanced restaurant cards with comprehensive business data
- July 06, 2025. Built revolutionary Voice-Driven Marketplace:
  * Real-time voice recognition with Web Speech API
  * Dynamic UI transformation based on voice commands
  * Amazon Product integration with visual product display
  * Seamless category morphing ("red sneakers" → "green vase")
  * Tailwind animations for smooth product transitions
  * Multi-source marketplace aggregation architecture
- July 06, 2025. Created dedicated Marketplace experience:
  * Alexa-style circular voice interface with hollowed center
  * Central microphone with animated rings during listening
  * Trending products grid with live Amazon data
  * Dedicated /marketplace route with full-page experience
  * Voice command transformation with smooth animations
  * Product cards with Prime badges, ratings, and pricing
- July 06, 2025. Completed full authentication and personalization system:
  * PostgreSQL-based user authentication with secure password hashing
  * 4-step onboarding flow capturing location, food, shopping, and travel preferences
  * Protected routes with automatic redirects for unauthenticated users
  * AI system integration with real user data instead of mock data
  * Personalized prompts using actual user location and preferences
  * Knowledge graph displaying authentic user profile data
  * User-specific conversations and recommendation history
  * Complete end-to-end personalized commerce experience
- July 06, 2025. Built MediGroq medical services as USP feature:
  * ZenSERP medical service integration for real hospital/clinic data
  * Gemini AI prescription analysis with image/file upload capabilities
  * Separate dedicated MediGroq chat interface with full-page experience
  * Real medical facility search with prices, ratings, and reviews
  * Medication price comparison across pharmacies
  * Medical disclaimers and safety warnings throughout
  * File upload support for prescription image analysis
  * Protected medical routes with secure file upload handling
  * Dedicated `/medigroq` route with complete chat UI powered by Gemini AI
- July 07, 2025. Replaced ALL mock data with real email delivery system:
  * Integrated Resend API for authentic email delivery instead of mock bills
  * Professional HTML email templates for hotel booking confirmations
  * Restaurant order confirmation emails with itemized receipts
  * Real-time email delivery with proper error handling
  * Test endpoints for validating email functionality with actual user emails
  * Complete migration from mock notification system to production-ready email delivery
  * Updated to use Resend's verified domain (onboarding@resend.dev) for reliable email delivery
- July 08, 2025. Built three-agent travel booking system with voice integration:
  * Created dedicated Travel Agents page with Groq (FlightAgent), Gemini (TravelAgent), and Fetch AI (BudgetAgent)
  * Implemented multi-agent debate system where agents challenge each other's recommendations
  * Added "Start Plan Collaboration" button for user control over agent debates
  * Integrated Web Speech API for voice input capabilities
  * Voice interruption feature - users can speak to interrupt AI agents during planning
  * Real-time voice recognition with visual feedback and status indicators
  * Optimized all AI responses to be under 100 words with proper markdown formatting
  * Added markdown renderer for structured display of agent responses
  * Complete hands-free travel planning experience with voice control
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```