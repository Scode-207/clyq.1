import { emailService } from './services/email-service';

async function testEmailDelivery() {
  console.log('Testing real email delivery with Resend API...');
  
  try {
    // Test hotel booking email
    const hotelEmailResult = await emailService.sendHotelBookingConfirmation({
      customerName: 'Test User',
      customerEmail: 'test@example.com',
      hotelName: 'The Grand Hotel',
      location: 'San Francisco, CA',
      checkIn: '2025-07-15',
      checkOut: '2025-07-17',
      nights: 2,
      roomType: 'Deluxe Suite',
      totalAmount: 599.99,
      bookingId: 'HTL-TEST-123',
      confirmationNumber: 'CONF-TEST456'
    });
    
    console.log('Hotel booking email test result:', hotelEmailResult);
    
    // Test restaurant order email
    const restaurantEmailResult = await emailService.sendRestaurantOrderConfirmation({
      customerName: 'Test User',
      customerEmail: 'test@example.com',
      restaurantName: 'Italian Bistro',
      orderItems: [
        { name: 'Margherita Pizza', quantity: 1, price: 18.99 },
        { name: 'Caesar Salad', quantity: 1, price: 12.99 }
      ],
      totalAmount: 31.98,
      deliveryAddress: '123 Main St, San Francisco, CA',
      estimatedDelivery: '7:30 PM',
      orderId: 'ORD-TEST-789'
    });
    
    console.log('Restaurant order email test result:', restaurantEmailResult);
    
    if (hotelEmailResult && restaurantEmailResult) {
      console.log('✅ Email delivery system is working correctly!');
    } else {
      console.log('❌ Some emails failed to send');
    }
    
  } catch (error) {
    console.error('Email test failed:', error);
  }
}

// Run test immediately
testEmailDelivery();