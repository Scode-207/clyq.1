import axios from 'axios';

interface SerpImageResult {
  position: number;
  title: string;
  source: string;
  source_logo?: string;
  link: string;
  original: string;
  original_width: number;
  original_height: number;
  is_product?: boolean;
}

interface SerpImageResponse {
  search_metadata: {
    id: string;
    status: string;
    json_endpoint: string;
    created_at: string;
    processed_at: string;
    google_url: string;
    raw_html_file: string;
    total_time_taken: number;
  };
  search_parameters: {
    engine: string;
    q: string;
    google_domain: string;
    hl: string;
    gl: string;
    device: string;
    tbm: string;
  };
  search_information: {
    image_results_state: string;
    total_results: number;
    time_taken_displayed: number;
  };
  images_results: SerpImageResult[];
}

interface RestaurantImages {
  restaurantName: string;
  images: {
    url: string;
    title: string;
    source: string;
    width: number;
    height: number;
    type: 'interior' | 'exterior' | 'food' | 'general';
  }[];
  totalFound: number;
}

export class SerpService {
  private apiKey = process.env.SERP_API_KEY;
  private baseUrl = 'https://serpapi.com/search';

  async getRestaurantImages(restaurantName: string, location: string): Promise<RestaurantImages> {
    if (!this.apiKey) {
      throw new Error('SERP API key not found');
    }

    try {
      // Search for restaurant interior and exterior images
      const interiorImages = await this.searchImages(`${restaurantName} ${location} restaurant interior dining room`);
      const exteriorImages = await this.searchImages(`${restaurantName} ${location} restaurant exterior building`);
      const foodImages = await this.searchImages(`${restaurantName} ${location} restaurant food menu dishes`);

      // Combine and categorize images
      const allImages = [
        ...interiorImages.map(img => ({ ...img, type: 'interior' as const })),
        ...exteriorImages.map(img => ({ ...img, type: 'exterior' as const })),
        ...foodImages.map(img => ({ ...img, type: 'food' as const }))
      ];

      // Remove duplicates and select best images
      const uniqueImages = this.removeDuplicateImages(allImages);
      const bestImages = this.selectBestImages(uniqueImages, 6);

      return {
        restaurantName,
        images: bestImages,
        totalFound: allImages.length
      };
    } catch (error) {
      console.error('SERP image search error:', error);
      throw new Error(`Failed to fetch restaurant images: ${error.message}`);
    }
  }

  private async searchImages(query: string): Promise<{
    url: string;
    title: string;
    source: string;
    width: number;
    height: number;
  }[]> {
    try {
      const response = await axios.get(this.baseUrl, {
        params: {
          api_key: this.apiKey,
          engine: 'google',
          q: query,
          tbm: 'isch', // Image search
          hl: 'en',
          gl: 'us',
          safe: 'active',
          num: 20
        }
      });

      const data: SerpImageResponse = response.data;
      
      if (!data.images_results) {
        return [];
      }

      return data.images_results
        .filter(img => this.isValidRestaurantImage(img))
        .map(img => ({
          url: img.original,
          title: img.title,
          source: img.source,
          width: img.original_width,
          height: img.original_height
        }))
        .slice(0, 8); // Limit to 8 images per category
    } catch (error) {
      console.error('SERP search error:', error);
      return [];
    }
  }

  private isValidRestaurantImage(image: SerpImageResult): boolean {
    // Filter out low-quality or irrelevant images
    const title = image.title?.toLowerCase() || '';
    const source = image.source?.toLowerCase() || '';
    
    // Minimum size requirements
    if (image.original_width < 300 || image.original_height < 200) {
      return false;
    }

    // Exclude stock photo sites and unrelated content
    const excludeSources = [
      'shutterstock', 'getty', 'istockphoto', 'alamy', 'dreamstime',
      'pinterest', 'facebook', 'instagram', 'twitter'
    ];
    
    for (const exclude of excludeSources) {
      if (source.includes(exclude)) {
        return false;
      }
    }

    // Exclude irrelevant images
    const excludeKeywords = [
      'logo', 'icon', 'template', 'vector', 'illustration',
      'stock photo', 'clipart', 'cartoon', 'drawing'
    ];
    
    for (const keyword of excludeKeywords) {
      if (title.includes(keyword)) {
        return false;
      }
    }

    return true;
  }

  private removeDuplicateImages(images: any[]): any[] {
    const seen = new Set();
    return images.filter(img => {
      const key = `${img.url}_${img.width}_${img.height}`;
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }

  private selectBestImages(images: any[], maxCount: number): any[] {
    // Prioritize by image quality and relevance
    return images
      .sort((a, b) => {
        // Prefer larger images
        const aSize = a.width * a.height;
        const bSize = b.width * b.height;
        
        // Prefer images from reputable sources
        const aSourceScore = this.getSourceScore(a.source);
        const bSourceScore = this.getSourceScore(b.source);
        
        // Combined scoring
        const aScore = (aSize / 100000) + aSourceScore;
        const bScore = (bSize / 100000) + bSourceScore;
        
        return bScore - aScore;
      })
      .slice(0, maxCount);
  }

  private getSourceScore(source: string): number {
    const preferredSources = [
      'yelp.com', 'tripadvisor.com', 'zomato.com', 'opentable.com',
      'foursquare.com', 'timeout.com', 'eater.com'
    ];
    
    for (const preferred of preferredSources) {
      if (source.includes(preferred)) {
        return 10;
      }
    }
    
    return 0;
  }

  async searchGeneralImages(query: string, maxResults: number = 10): Promise<{
    url: string;
    title: string;
    source: string;
    width: number;
    height: number;
  }[]> {
    if (!this.apiKey) {
      throw new Error('SERP API key not found');
    }

    try {
      const response = await axios.get(this.baseUrl, {
        params: {
          api_key: this.apiKey,
          engine: 'google',
          q: query,
          tbm: 'isch',
          hl: 'en',
          gl: 'us',
          safe: 'active',
          num: maxResults
        }
      });

      const data: SerpImageResponse = response.data;
      
      if (!data.images_results) {
        return [];
      }

      return data.images_results
        .filter(img => img.original_width >= 200 && img.original_height >= 150)
        .map(img => ({
          url: img.original,
          title: img.title,
          source: img.source,
          width: img.original_width,
          height: img.original_height
        }))
        .slice(0, maxResults);
    } catch (error) {
      console.error('SERP general image search error:', error);
      return [];
    }
  }
}

export const serpService = new SerpService();