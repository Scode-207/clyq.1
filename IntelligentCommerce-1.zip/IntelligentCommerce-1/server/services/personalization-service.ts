// Hyper-personalization service that integrates all commerce platforms
import { amazonService } from './amazon-service';
import { zomatoService } from './zomato-service';
import { makeMyTripService } from './makemytrip-service';
import type { User } from '@shared/schema';

interface UserBehaviorProfile {
  foodPreferences: {
    favoriteCuisines: string[];
    dietaryRestrictions: string[];
    orderFrequency: number;
    avgOrderValue: number;
    preferredMealTimes: string[];
    spicePreference: string;
  };
  travelPreferences: {
    preferredDestinations: string[];
    budgetRange: { min: number; max: number };
    travelFrequency: number;
    accommodationType: string[];
    transportPreference: string[];
    seasonalPreferences: string[];
  };
  shoppingPreferences: {
    favoriteCategories: string[];
    brandLoyalty: string[];
    pricePointPreference: string;
    sustainabilityImportance: number;
    shoppingFrequency: number;
    preferredShoppingTimes: string[];
  };
  contextualFactors: {
    currentLocation: { lat: number; lng: number; city: string };
    timeOfDay: string;
    dayOfWeek: string;
    season: string;
    weatherCondition: string;
    socialContext: string; // alone, family, friends, business
  };
}

interface PersonalizedRecommendation {
  type: 'food' | 'travel' | 'shopping';
  items: any[];
  reasoning: string;
  confidence: number;
  urgency: 'low' | 'medium' | 'high';
  personalizedMessage: string;
}

export class PersonalizationService {
  
  async generateUserBehaviorProfile(user: User, interactionHistory: any[]): Promise<UserBehaviorProfile> {
    // Analyze user's interaction history to build comprehensive behavior profile
    const foodInteractions = interactionHistory.filter(i => i.domain === 'food');
    const travelInteractions = interactionHistory.filter(i => i.domain === 'travel');
    const shoppingInteractions = interactionHistory.filter(i => i.domain === 'marketplace');

    // Use actual user preferences from database
    const userFoodPrefs = user.foodPreferences || {};
    const userTravelPrefs = user.travelPreferences || {};
    const userShoppingPrefs = user.shoppingPreferences || {};
    const userLocation = user.location || {};

    return {
      foodPreferences: {
        favoriteCuisines: userFoodPrefs.favoriteCuisines || this.extractCuisinePreferences(foodInteractions, user.preferences?.cuisine),
        dietaryRestrictions: userFoodPrefs.dietaryRestrictions || [],
        orderFrequency: this.calculateOrderFrequency(foodInteractions),
        avgOrderValue: this.calculateAvgOrderValue(foodInteractions),
        preferredMealTimes: this.extractMealTimePreferences(foodInteractions),
        spicePreference: userFoodPrefs.spicePreference || this.extractSpicePreference(foodInteractions)
      },
      travelPreferences: {
        preferredDestinations: userTravelPrefs.preferredDestinations || this.extractDestinationPreferences(travelInteractions),
        budgetRange: userTravelPrefs.budget ? { min: 0, max: parseInt(userTravelPrefs.budget.replace(/[^0-9]/g, '')) } : this.extractBudgetRange(travelInteractions),
        travelFrequency: this.calculateTravelFrequency(travelInteractions),
        accommodationType: userTravelPrefs.accommodationType || [],
        transportPreference: this.extractTransportPreferences(travelInteractions),
        seasonalPreferences: this.extractSeasonalPreferences(travelInteractions)
      },
      shoppingPreferences: {
        favoriteCategories: userShoppingPrefs.favoriteCategories || this.extractShoppingCategories(shoppingInteractions),
        brandLoyalty: this.extractBrandLoyalty(shoppingInteractions),
        pricePointPreference: userShoppingPrefs.budgetRange || this.extractPricePreference(shoppingInteractions),
        sustainabilityImportance: userShoppingPrefs.sustainabilityImportance || this.calculateSustainabilityScore(user.preferences, shoppingInteractions),
        shoppingFrequency: this.calculateShoppingFrequency(shoppingInteractions),
        preferredShoppingTimes: this.extractShoppingTimes(shoppingInteractions)
      },
      contextualFactors: {
        currentLocation: { 
          lat: userLocation.latitude || 37.7749, 
          lng: userLocation.longitude || -122.4194, 
          city: userLocation.city || 'San Francisco' 
        },
        timeOfDay: this.getCurrentTimeOfDay(),
        dayOfWeek: this.getCurrentDayOfWeek(),
        season: this.getCurrentSeason(),
        weatherCondition: 'mild', // Would integrate with weather API
        socialContext: 'alone' // Would be determined by user input or pattern recognition
      }
    };
  }

  async getHyperPersonalizedRecommendations(
    user: User, 
    behaviorProfile: UserBehaviorProfile,
    context: { domain?: string; intent?: string; currentQuery?: string }
  ): Promise<PersonalizedRecommendation[]> {
    const recommendations: PersonalizedRecommendation[] = [];

    // Food recommendations with real-time personalization
    if (!context.domain || context.domain === 'food') {
      const foodRecs = await this.getFoodRecommendations(user, behaviorProfile, context);
      if (foodRecs) recommendations.push(foodRecs);
    }

    // Travel recommendations with contextual awareness
    if (!context.domain || context.domain === 'travel') {
      const travelRecs = await this.getTravelRecommendations(user, behaviorProfile, context);
      if (travelRecs) recommendations.push(travelRecs);
    }

    // Shopping recommendations with predictive analysis
    if (!context.domain || context.domain === 'marketplace') {
      const shoppingRecs = await this.getShoppingRecommendations(user, behaviorProfile, context);
      if (shoppingRecs) recommendations.push(shoppingRecs);
    }

    return recommendations.sort((a, b) => b.confidence - a.confidence);
  }

  private async getFoodRecommendations(
    user: User, 
    profile: UserBehaviorProfile, 
    context: any
  ): Promise<PersonalizedRecommendation | null> {
    try {
      const restaurants = await zomatoService.getPersonalizedRecommendations(
        user.preferences,
        [], // Would pass actual order history
        profile.contextualFactors.currentLocation.city
      );

      const timeBasedMessage = this.getTimeBasedFoodMessage(profile.contextualFactors.timeOfDay);
      const personalizedMessage = `${timeBasedMessage} Based on your love for ${profile.foodPreferences.favoriteCuisines.join(' and ')} cuisine, here are some perfect matches:`;

      return {
        type: 'food',
        items: restaurants,
        reasoning: `Recommended based on your dietary preferences (${profile.foodPreferences.dietaryRestrictions.join(', ')}), favorite cuisines, and current time of day`,
        confidence: 0.85,
        urgency: this.calculateFoodUrgency(profile.contextualFactors.timeOfDay),
        personalizedMessage
      };
    } catch (error) {
      console.error('Food recommendation error:', error);
      return null;
    }
  }

  private async getTravelRecommendations(
    user: User, 
    profile: UserBehaviorProfile, 
    context: any
  ): Promise<PersonalizedRecommendation | null> {
    try {
      const hotels = await makeMyTripService.getPersonalizedHotelRecommendations(
        user.preferences,
        [], // Would pass actual booking history
        'San Francisco'
      );

      const seasonalMessage = this.getSeasonalTravelMessage(profile.contextualFactors.season);
      const personalizedMessage = `${seasonalMessage} Since you prefer ${profile.travelPreferences.accommodationType.join(' and ')} accommodations, these options are curated for you:`;

      return {
        type: 'travel',
        items: hotels,
        reasoning: `Selected based on your travel style preferences, budget range ($${profile.travelPreferences.budgetRange.min}-$${profile.travelPreferences.budgetRange.max}), and seasonal patterns`,
        confidence: 0.78,
        urgency: this.calculateTravelUrgency(profile.contextualFactors.season),
        personalizedMessage
      };
    } catch (error) {
      console.error('Travel recommendation error:', error);
      return null;
    }
  }

  private async getShoppingRecommendations(
    user: User, 
    profile: UserBehaviorProfile, 
    context: any
  ): Promise<PersonalizedRecommendation | null> {
    try {
      const products = await amazonService.getPersonalizedRecommendations(
        user.preferences,
        [] // Would pass actual browsing history
      );

      const sustainabilityMessage = profile.shoppingPreferences.sustainabilityImportance > 7 
        ? "As someone who values sustainability, " 
        : "";
      const personalizedMessage = `${sustainabilityMessage}Based on your interest in ${profile.shoppingPreferences.favoriteCategories.join(' and ')}, here are some products you might love:`;

      return {
        type: 'shopping',
        items: products,
        reasoning: `Curated based on your brand preferences, sustainability score (${profile.shoppingPreferences.sustainabilityImportance}/10), and shopping patterns`,
        confidence: 0.82,
        urgency: this.calculateShoppingUrgency(profile.contextualFactors.dayOfWeek),
        personalizedMessage
      };
    } catch (error) {
      console.error('Shopping recommendation error:', error);
      return null;
    }
  }

  // Helper methods for behavior analysis
  private extractCuisinePreferences(interactions: any[], userCuisines?: string[]): string[] {
    const extractedCuisines = interactions
      .filter(i => i.metadata?.suggestions?.some((s: any) => s.type === 'restaurant'))
      .flatMap(i => i.metadata.suggestions.filter((s: any) => s.type === 'restaurant'))
      .map(s => s.data?.cuisine || '')
      .filter(Boolean);
    
    return [...new Set([...(userCuisines || []), ...extractedCuisines])];
  }

  private calculateOrderFrequency(interactions: any[]): number {
    // Calculate orders per week based on interaction history
    return Math.min(interactions.length * 0.3, 7); // Max 7 orders per week
  }

  private calculateAvgOrderValue(interactions: any[]): number {
    // Mock calculation - would analyze actual order values
    return 25 + Math.random() * 15; // $25-40 average
  }

  private extractMealTimePreferences(interactions: any[]): string[] {
    // Analyze interaction timestamps to determine preferred meal times
    return ['lunch', 'dinner']; // Mock data
  }

  private extractSpicePreference(interactions: any[]): string {
    // Analyze spice level preferences from order history
    return 'medium'; // Mock data
  }

  private extractDestinationPreferences(interactions: any[]): string[] {
    return ['San Francisco', 'Seattle', 'Portland']; // Mock data
  }

  private extractBudgetRange(interactions: any[]): { min: number; max: number } {
    return { min: 150, max: 400 }; // Mock data
  }

  private calculateTravelFrequency(interactions: any[]): number {
    return Math.min(interactions.length * 0.1, 2); // Max 2 trips per month
  }

  private extractTransportPreferences(interactions: any[]): string[] {
    return ['flight', 'train']; // Mock data
  }

  private extractSeasonalPreferences(interactions: any[]): string[] {
    return ['spring', 'fall']; // Mock data
  }

  private extractShoppingCategories(interactions: any[]): string[] {
    return ['outdoor gear', 'electronics', 'home']; // Mock data
  }

  private extractBrandLoyalty(interactions: any[]): string[] {
    return ['patagonia', 'apple', 'amazon']; // Mock data
  }

  private extractPricePreference(interactions: any[]): string {
    return 'mid-range'; // Mock data
  }

  private calculateSustainabilityScore(preferences: any, interactions: any[]): number {
    if (preferences?.shoppingStyle?.includes('eco-friendly')) return 9;
    return 5; // Default moderate concern
  }

  private calculateShoppingFrequency(interactions: any[]): number {
    return Math.min(interactions.length * 0.2, 5); // Max 5 purchases per week
  }

  private extractShoppingTimes(interactions: any[]): string[] {
    return ['evening', 'weekend']; // Mock data
  }

  // Contextual helper methods
  private getCurrentTimeOfDay(): string {
    const hour = new Date().getHours();
    if (hour < 12) return 'morning';
    if (hour < 17) return 'afternoon';
    if (hour < 21) return 'evening';
    return 'night';
  }

  private getCurrentDayOfWeek(): string {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    return days[new Date().getDay()];
  }

  private getCurrentSeason(): string {
    const month = new Date().getMonth();
    if (month >= 2 && month <= 4) return 'spring';
    if (month >= 5 && month <= 7) return 'summer';
    if (month >= 8 && month <= 10) return 'fall';
    return 'winter';
  }

  // Message generation methods
  private getTimeBasedFoodMessage(timeOfDay: string): string {
    const messages = {
      morning: "Good morning! Ready for a healthy start to your day?",
      afternoon: "Afternoon fuel time!",
      evening: "Evening dining awaits!",
      night: "Late night cravings?"
    };
    return messages[timeOfDay as keyof typeof messages] || "Ready to eat?";
  }

  private getSeasonalTravelMessage(season: string): string {
    const messages = {
      spring: "Spring is perfect for travel!",
      summer: "Summer adventures calling!",
      fall: "Fall colors and cozy getaways await!",
      winter: "Winter escapes and warm destinations!"
    };
    return messages[season as keyof typeof messages] || "Time for your next adventure!";
  }

  // Urgency calculation methods
  private calculateFoodUrgency(timeOfDay: string): 'low' | 'medium' | 'high' {
    if (timeOfDay === 'morning' || timeOfDay === 'evening') return 'high';
    if (timeOfDay === 'afternoon') return 'medium';
    return 'low';
  }

  private calculateTravelUrgency(season: string): 'low' | 'medium' | 'high' {
    if (season === 'spring' || season === 'fall') return 'high';
    return 'medium';
  }

  private calculateShoppingUrgency(dayOfWeek: string): 'low' | 'medium' | 'high' {
    if (dayOfWeek === 'friday' || dayOfWeek === 'saturday') return 'high';
    if (dayOfWeek === 'sunday') return 'medium';
    return 'low';
  }
}

export const personalizationService = new PersonalizationService();