interface Hotel {
  id: string;
  name: string;
  location: string;
  price: number;
  rating: number;
  reviews: number;
  petFriendly: boolean;
  amenities: string[];
  description: string;
  image?: string;
}

interface Restaurant {
  id: string;
  name: string;
  cuisine: string;
  location: string;
  rating: number;
  reviews: number;
  priceRange: string;
  dietary: string[];
  description: string;
  delivery: boolean;
  image?: string;
}

interface Product {
  id: string;
  name: string;
  category: string;
  brand: string;
  price: number;
  rating: number;
  reviews: number;
  sustainable: boolean;
  description: string;
  features: string[];
  image?: string;
}

export class CommerceService {
  // ENHANCED HOTEL MOCK DATA WITH DETAILED REVIEWS AND PRICING
  private hotels: Hotel[] = [
    {
      id: "westin-sf",
      name: "The Westin St. Francis",
      location: "Union Square, San Francisco",
      price: 285,
      rating: 4.8,
      reviews: 2341,
      petFriendly: true,
      amenities: ["Fitness Center", "Spa", "Room Service", "Pet Walking Service", "Concierge", "WiFi"],
      description: "Historic luxury hotel in the heart of Union Square. $75 pet fee, dog walking service available. Recently renovated rooms with city views.",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=300&fit=crop&auto=format"
    },
    {
      id: "zephyr-sf",
      name: "Hotel Zephyr",
      location: "Fisherman's Wharf, San Francisco",
      price: 195,
      rating: 4.6,
      reviews: 1892,
      petFriendly: true,
      amenities: ["Waterfront Location", "Nautical Theme", "Dog Parks Nearby", "Restaurant", "Bar"],
      description: "Boutique waterfront hotel with nautical theme. No pet fees, near dog parks. Unique maritime decor.",
      image: "https://images.unsplash.com/photo-1561409037-c7be81613c1f?w=500&h=300&fit=crop&auto=format"
    },
    {
      id: "fairmont-sf",
      name: "Fairmont San Francisco",
      location: "Nob Hill, San Francisco",
      price: 350,
      rating: 4.7,
      reviews: 3156,
      petFriendly: true,
      amenities: ["Historic Landmark", "City Views", "Luxury Spa", "Pet Amenities", "Multiple Restaurants"],
      description: "Iconic luxury hotel atop Nob Hill with stunning city views and premium pet services. Classic elegance meets modern luxury.",
      image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=500&h=300&fit=crop&auto=format"
    },
    {
      id: "ritz-sf",
      name: "The Ritz-Carlton San Francisco",
      location: "Nob Hill, San Francisco", 
      price: 495,
      rating: 4.9,
      reviews: 4532,
      petFriendly: true,
      amenities: ["Luxury Spa", "Fine Dining", "Butler Service", "City Views", "Pet Program"],
      description: "Ultra-luxury hotel with legendary service. Comprehensive pet program with gourmet pet menu and walking services.",
      image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=500&h=300&fit=crop&auto=format"
    },
    {
      id: "palace-sf",
      name: "Palace Hotel San Francisco",
      location: "SoMa, San Francisco",
      price: 320,
      rating: 4.5,
      reviews: 2876,
      petFriendly: true,
      amenities: ["Historic Garden Court", "Indoor Pool", "Fitness Center", "Pet Services"],
      description: "Historic landmark hotel with stunning Garden Court. Pet-friendly with dedicated amenities and nearby parks.",
      image: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=500&h=300&fit=crop&auto=format"
    },
    {
      id: "kimpton-sf",
      name: "Kimpton Alton Hotel",
      location: "Fisherman's Wharf, San Francisco",
      price: 225,
      rating: 4.4,
      reviews: 1654,
      petFriendly: true,
      amenities: ["Rooftop Bar", "Fitness Center", "Pet Program", "Eco-Friendly"],
      description: "Modern boutique hotel with no pet fees. Complimentary pet beds, bowls, and treats. Rooftop bar with bay views.",
      image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=500&h=300&fit=crop&auto=format"
    },
    {
      id: "hyatt-sf",
      name: "Grand Hyatt San Francisco",
      location: "Union Square, San Francisco",
      price: 275,
      rating: 4.6,
      reviews: 3421,
      petFriendly: true,
      amenities: ["Union Square Location", "Business Center", "Fitness Center", "Pet Policy"],
      description: "Contemporary luxury in Union Square. Pet-friendly rooms available with advance notice. Walking distance to parks.",
      image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=500&h=300&fit=crop&auto=format"
    },
    {
      id: "w-sf",
      name: "W San Francisco",
      location: "SoMa, San Francisco",
      price: 380,
      rating: 4.3,
      reviews: 2198,
      petFriendly: true,
      amenities: ["Modern Design", "Bliss Spa", "Pet Program", "Restaurant"],
      description: "Trendy luxury hotel with pet program. Special pet amenities including beds, toys, and treats. Modern urban style.",
      image: "https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=500&h=300&fit=crop&auto=format"
    }
  ];

  private restaurants: Restaurant[] = [
    {
      id: "state-bird",
      name: "State Bird Provisions",
      cuisine: "American, Farm-to-Table",
      location: "Western Addition, San Francisco",
      rating: 4.9,
      reviews: 1247,
      priceRange: "$$$",
      dietary: ["Vegetarian Options", "Locally Sourced", "Organic"],
      description: "Farm-to-table restaurant featuring locally sourced ingredients and innovative California cuisine.",
      delivery: false
    },
    {
      id: "greens",
      name: "Greens Restaurant",
      cuisine: "Vegetarian Fine Dining",
      location: "Marina District, San Francisco",
      rating: 4.7,
      reviews: 891,
      priceRange: "$$$",
      dietary: ["Vegetarian", "Vegan Options", "Organic", "Sustainable"],
      description: "Vegetarian fine dining with stunning bay views and commitment to sustainable practices.",
      delivery: true
    },
    {
      id: "green-table",
      name: "Green Table",
      cuisine: "Healthy California",
      location: "Mission District, San Francisco",
      rating: 4.5,
      reviews: 567,
      priceRange: "$$",
      dietary: ["Healthy", "Organic", "Vegan Options", "Gluten-Free"],
      description: "Health-focused California cuisine with organic ingredients and sustainable practices.",
      delivery: true
    }
  ];

  private products: Product[] = [
    {
      id: "patagonia-daypack",
      name: "Patagonia Refugio Daypack 28L",
      category: "Outdoor Gear",
      brand: "Patagonia",
      price: 89,
      rating: 4.8,
      reviews: 1543,
      sustainable: true,
      description: "Versatile daypack made from recycled materials with laptop compartment and organizational pockets.",
      features: ["Recycled Materials", "Laptop Compartment", "Lifetime Repair", "Fair Trade Certified"]
    },
    {
      id: "hydro-flask",
      name: "Hydro Flask Standard Mouth 32oz",
      category: "Water Bottles",
      brand: "Hydro Flask",
      price: 45,
      rating: 4.9,
      reviews: 3421,
      sustainable: true,
      description: "Insulated stainless steel water bottle that keeps drinks cold for 24 hours or hot for 12 hours.",
      features: ["BPA-Free", "Dishwasher Safe", "Lifetime Warranty", "Temperature Retention"]
    },
    {
      id: "allbirds-runners",
      name: "Allbirds Tree Runners",
      category: "Footwear",
      brand: "Allbirds",
      price: 98,
      rating: 4.6,
      reviews: 2156,
      sustainable: true,
      description: "Comfortable running shoes made from eucalyptus tree fiber with carbon-negative sole.",
      features: ["Eucalyptus Fiber", "Carbon Negative", "Machine Washable", "Moisture Wicking"]
    }
  ];

  async searchHotels(location?: string, filters?: { petFriendly?: boolean; maxPrice?: number }): Promise<Hotel[]> {
    let results = [...this.hotels];

    if (location) {
      const locationLower = location.toLowerCase();
      results = results.filter(hotel => 
        hotel.location.toLowerCase().includes(locationLower) ||
        hotel.name.toLowerCase().includes(locationLower)
      );
    }

    if (filters?.petFriendly) {
      results = results.filter(hotel => hotel.petFriendly);
    }

    if (filters?.maxPrice) {
      results = results.filter(hotel => hotel.price <= filters.maxPrice);
    }

    return results.sort((a, b) => b.rating - a.rating);
  }

  async searchRestaurants(cuisine?: string, filters?: { dietary?: string[]; delivery?: boolean }): Promise<Restaurant[]> {
    let results = [...this.restaurants];

    if (cuisine) {
      const cuisineLower = cuisine.toLowerCase();
      results = results.filter(restaurant => 
        restaurant.cuisine.toLowerCase().includes(cuisineLower)
      );
    }

    if (filters?.dietary) {
      results = results.filter(restaurant =>
        filters.dietary!.some(diet => 
          restaurant.dietary.some(restDiet => 
            restDiet.toLowerCase().includes(diet.toLowerCase())
          )
        )
      );
    }

    if (filters?.delivery !== undefined) {
      results = results.filter(restaurant => restaurant.delivery === filters.delivery);
    }

    return results.sort((a, b) => b.rating - a.rating);
  }

  async searchProducts(category?: string, filters?: { sustainable?: boolean; maxPrice?: number; brand?: string }): Promise<Product[]> {
    let results = [...this.products];

    if (category) {
      const categoryLower = category.toLowerCase();
      results = results.filter(product => 
        product.category.toLowerCase().includes(categoryLower) ||
        product.name.toLowerCase().includes(categoryLower)
      );
    }

    if (filters?.sustainable) {
      results = results.filter(product => product.sustainable);
    }

    if (filters?.maxPrice) {
      results = results.filter(product => product.price <= filters.maxPrice);
    }

    if (filters?.brand) {
      const brandLower = filters.brand.toLowerCase();
      results = results.filter(product => 
        product.brand.toLowerCase().includes(brandLower)
      );
    }

    return results.sort((a, b) => b.rating - a.rating);
  }

  async getHotel(id: string): Promise<Hotel | undefined> {
    return this.hotels.find(hotel => hotel.id === id);
  }

  async getRestaurant(id: string): Promise<Restaurant | undefined> {
    return this.restaurants.find(restaurant => restaurant.id === id);
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.find(product => product.id === id);
  }
}

export const commerceService = new CommerceService();
