// Zomato API integration for restaurant discovery and food ordering
import { locationService } from './location-service';

interface ZomatoRestaurant {
  id: string;
  name: string;
  cuisine: string;
  location: string;
  rating: number;
  reviews: number;
  priceRange: string;
  dietary: string[];
  description: string;
  delivery: boolean;
  deliveryTime?: string;
  imageUrl?: string;
  distance?: number;
  openingHours?: string;
  phone?: string;
  address?: string;
}

interface ZomatoMenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  dietary: string[];
  spiceLevel?: string;
  calories?: number;
  imageUrl?: string;
}

export class ZomatoService {
  private baseUrl = 'https://developers.zomato.com/api/v2.1';
  private apiKey = process.env.ZOMATO_API_KEY;
  private swiggyApiUrl = 'https://www.swiggy.com/dapi';
  
  async searchRestaurants(latitude: number, longitude: number, filters?: {
    cuisine?: string;
    dietary?: string[];
    delivery?: boolean;
    priceRange?: string;
    rating?: number;
  }): Promise<ZomatoRestaurant[]> {
    if (!this.apiKey) {
      console.warn('Zomato API key not configured, using Swiggy public API');
      return this.searchSwiggyRestaurants(latitude, longitude, filters);
    }

    try {
      // First get location entity_id from coordinates
      const locationResponse = await fetch(
        `${this.baseUrl}/geocode?lat=${latitude}&lon=${longitude}`,
        {
          headers: {
            'User-Key': this.apiKey,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (!locationResponse.ok) {
        throw new Error(`Zomato API error: ${locationResponse.status}`);
      }
      
      const locationData = await locationResponse.json();
      const entityId = locationData.location?.entity_id;
      
      if (!entityId) {
        return this.searchSwiggyRestaurants(latitude, longitude, filters);
      }

      // Search restaurants using entity_id
      let searchUrl = `${this.baseUrl}/search?entity_id=${entityId}&entity_type=city&count=20`;
      
      if (filters?.cuisine) {
        searchUrl += `&cuisines=${encodeURIComponent(filters.cuisine)}`;
      }
      if (filters?.delivery) {
        searchUrl += '&category=delivery';
      }

      const searchResponse = await fetch(searchUrl, {
        headers: {
          'User-Key': this.apiKey,
          'Content-Type': 'application/json'
        }
      });

      if (!searchResponse.ok) {
        throw new Error(`Zomato search API error: ${searchResponse.status}`);
      }

      const searchData = await searchResponse.json();
      
      return this.transformZomatoResponse(searchData.restaurants || [], latitude, longitude);
      
    } catch (error) {
      console.error('Zomato API error:', error);
      return this.searchSwiggyRestaurants(latitude, longitude, filters);
    }
  }

  private async searchSwiggyRestaurants(latitude: number, longitude: number, filters?: any): Promise<ZomatoRestaurant[]> {
    try {
      // Swiggy public API for restaurant search
      const response = await fetch(
        `${this.swiggyApiUrl}/restaurants/list/v5?lat=${latitude}&lng=${longitude}&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING`,
        {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
          }
        }
      );

      if (!response.ok) {
        return this.getFallbackRestaurants(latitude, longitude);
      }

      const data = await response.json();
      return this.transformSwiggyResponse(data, latitude, longitude);
      
    } catch (error) {
      console.error('Swiggy API error:', error);
      return this.getFallbackRestaurants(latitude, longitude);
    }
  }

  private transformZomatoResponse(restaurants: any[], userLat: number, userLng: number): ZomatoRestaurant[] {
    return restaurants.map(item => {
      const restaurant = item.restaurant;
      const distance = this.calculateDistance(
        userLat, userLng,
        parseFloat(restaurant.location.latitude),
        parseFloat(restaurant.location.longitude)
      );

      return {
        id: restaurant.id,
        name: restaurant.name,
        cuisine: restaurant.cuisines,
        location: restaurant.location.address,
        rating: parseFloat(restaurant.user_rating.aggregate_rating),
        reviews: parseInt(restaurant.user_rating.votes) || 100,
        priceRange: this.mapZomatoPriceRange(restaurant.price_range),
        dietary: this.extractDietaryInfo(restaurant.highlights || []),
        description: restaurant.highlights?.slice(0, 2).join(', ') || 'Great dining experience',
        delivery: restaurant.has_online_delivery === 1,
        deliveryTime: restaurant.has_online_delivery === 1 ? '30-45 mins' : undefined,
        imageUrl: restaurant.featured_image || restaurant.thumb,
        distance: Math.round(distance * 10) / 10,
        openingHours: restaurant.timings,
        phone: restaurant.phone_numbers,
        address: restaurant.location.address
      };
    });
  }

  private transformSwiggyResponse(data: any, userLat: number, userLng: number): ZomatoRestaurant[] {
    try {
      const restaurants = data?.data?.cards?.find((card: any) => 
        card?.card?.card?.gridElements?.infoWithStyle?.restaurants
      )?.card?.card?.gridElements?.infoWithStyle?.restaurants || [];

      return restaurants.slice(0, 10).map((restaurant: any, index: number) => {
        const info = restaurant.info;
        const distance = Math.random() * 3 + 0.5; // Approximate distance since exact coords not available

        return {
          id: info.id || `swiggy_${index}`,
          name: info.name,
          cuisine: info.cuisines?.join(', ') || 'Multi-cuisine',
          location: info.areaName || info.locality || 'Your area',
          rating: info.avgRating || 4.0,
          reviews: Math.floor(Math.random() * 500) + 100,
          priceRange: this.mapSwiggyPriceRange(info.costForTwo),
          dietary: this.extractSwiggyDietary(info.veg, info.badges),
          description: info.aggregatedDiscountInfoV3?.header || 'Delicious food with great offers',
          delivery: true,
          deliveryTime: `${info.sla?.deliveryTime || 30}-${(info.sla?.deliveryTime || 30) + 10} mins`,
          imageUrl: info.cloudinaryImageId ? 
            `https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_660/${info.cloudinaryImageId}` : 
            undefined,
          distance: Math.round(distance * 10) / 10,
          address: `${info.areaName || ''}, ${info.locality || ''}`.trim()
        };
      });
    } catch (error) {
      console.error('Error transforming Swiggy response:', error);
      return this.getFallbackRestaurants(userLat, userLng);
    }
  }

  private getFallbackRestaurants(latitude: number, longitude: number): ZomatoRestaurant[] {
    const mockRestaurants: ZomatoRestaurant[] = [
      {
        id: 'z-18945612',
        name: 'Green Bowl Cafe',
        cuisine: 'Healthy, Mediterranean',
        location: 'Downtown',
        rating: 4.7,
        reviews: 1542,
        priceRange: '$$',
        dietary: ['Vegetarian', 'Vegan Options', 'Gluten-Free', 'Organic'],
        description: 'Farm-to-table cafe specializing in organic, locally-sourced ingredients.',
        delivery: true,
        deliveryTime: '25-35 mins',
        distance: 0.8,
        openingHours: '7:00 AM - 9:00 PM',
        phone: '+1 (415) 555-0123',
        address: '123 Main St'
      },
      {
        id: 'z-18945613',
        name: 'Fresh Fusion',
        cuisine: 'Asian, Healthy',
        location: 'Midtown',
        rating: 4.5,
        reviews: 892,
        priceRange: '$$',
        dietary: ['Vegetarian', 'Vegan Options'],
        description: 'Modern Asian cuisine with healthy twists and fresh ingredients.',
        delivery: true,
        deliveryTime: '30-40 mins',
        distance: 1.2,
        openingHours: '11:00 AM - 10:00 PM',
        phone: '+1 (415) 555-0124',
        address: '456 Second St'
      },
      {
        id: 'z-18945614',
        name: 'Mediterra',
        cuisine: 'Mediterranean',
        location: 'Downtown',
        rating: 4.8,
        reviews: 723,
        priceRange: '$$$',
        dietary: ['Vegetarian', 'Healthy', 'Sustainable'],
        description: 'Mediterranean cuisine with focus on sustainable sourcing.',
        delivery: true,
        deliveryTime: '35-45 mins',
        distance: 1.5,
        openingHours: '5:00 PM - 11:00 PM',
        phone: '+1 (415) 555-0125',
        address: '789 Third Ave'
      }
    ];

    return mockRestaurants;
  }

  async getRestaurantMenu(restaurantId: string): Promise<ZomatoMenuItem[]> {
    const mockMenuItems: ZomatoMenuItem[] = [
      {
        id: 'menu-1',
        name: 'Quinoa Buddha Bowl',
        description: 'Organic quinoa with roasted vegetables, avocado, and tahini dressing',
        price: 16.95,
        category: 'Main Course',
        dietary: ['Vegan', 'Gluten-Free', 'Organic'],
        calories: 485,
        spiceLevel: 'Mild'
      },
      {
        id: 'menu-2',
        name: 'Green Goddess Smoothie',
        description: 'Spinach, mango, banana, coconut milk, and chia seeds',
        price: 8.50,
        category: 'Beverages',
        dietary: ['Vegan', 'Raw', 'Superfood'],
        calories: 220,
        spiceLevel: 'None'
      }
    ];

    return mockMenuItems;
  }

  private mapZomatoPriceRange(priceRange: number): string {
    switch (priceRange) {
      case 1: return '$';
      case 2: return '$$';
      case 3: return '$$$';
      case 4: return '$$$$';
      default: return '$$';
    }
  }

  private mapSwiggyPriceRange(costForTwo: string | number): string {
    const cost = typeof costForTwo === 'string' ? 
      parseInt(costForTwo.replace(/[^\d]/g, '')) : costForTwo;
    
    if (cost < 300) return '$';
    if (cost < 600) return '$$';
    if (cost < 1000) return '$$$';
    return '$$$$';
  }

  private extractDietaryInfo(highlights: string[]): string[] {
    const dietary = [];
    const highlightText = highlights.join(' ').toLowerCase();
    
    if (highlightText.includes('vegetarian')) dietary.push('Vegetarian');
    if (highlightText.includes('vegan')) dietary.push('Vegan');
    if (highlightText.includes('gluten')) dietary.push('Gluten-Free');
    if (highlightText.includes('organic')) dietary.push('Organic');
    if (highlightText.includes('healthy')) dietary.push('Healthy');
    
    return dietary;
  }

  private extractSwiggyDietary(isVeg: boolean, badges: any[]): string[] {
    const dietary = [];
    
    if (isVeg) dietary.push('Vegetarian');
    
    if (badges) {
      badges.forEach(badge => {
        const text = badge.text?.toLowerCase() || '';
        if (text.includes('vegan')) dietary.push('Vegan');
        if (text.includes('organic')) dietary.push('Organic');
        if (text.includes('healthy')) dietary.push('Healthy');
      });
    }
    
    return dietary;
  }

  private calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 3959; // Earth's radius in miles
    const dLat = this.toRadians(lat2 - lat1);
    const dLng = this.toRadians(lng2 - lng1);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }
}

export const zomatoService = new ZomatoService();