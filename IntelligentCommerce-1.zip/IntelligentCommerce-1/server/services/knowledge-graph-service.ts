import { db } from "../db";
import { 
  userInterests, 
  userBehavior, 
  productRelationships, 
  knowledgeNodes, 
  knowledgeEdges,
  users,
  type InsertUserInterest,
  type InsertUserBehavior,
  type InsertProductRelationship,
  type InsertKnowledgeNode,
  type InsertKnowledgeEdge,
  type UserInterest,
  type UserBehavior,
  type KnowledgeNode,
  type KnowledgeEdge
} from "../../shared/schema";
import { eq, and, desc, sql, gt, lt } from "drizzle-orm";

interface GraphNode {
  id: string;
  type: string;
  label: string;
  properties: any;
  x?: number;
  y?: number;
  size?: number;
  color?: string;
}

interface GraphEdge {
  from: string;
  to: string;
  type: string;
  weight: number;
  properties: any;
  color?: string;
  width?: number;
}

interface UserProfile {
  interests: UserInterest[];
  recentBehavior: UserBehavior[];
  recommendations: any[];
  behaviorPatterns: {
    mostActiveHours: string[];
    favoriteCategories: string[];
    purchasePatterns: string[];
    searchPatterns: string[];
  };
}

export class KnowledgeGraphService {
  
  // Track user behavior and update knowledge graph
  async trackUserBehavior(
    userId: number, 
    action: string, 
    entityType: string, 
    entityId: string, 
    entityName: string, 
    metadata: any = {}
  ): Promise<void> {
    try {
      // Record behavior
      await db.insert(userBehavior).values({
        userId,
        action,
        entityType,
        entityId,
        entityName,
        metadata
      });

      // Update or create interest based on behavior
      await this.updateUserInterests(userId, entityType, entityName, action, metadata);

      // Create or strengthen knowledge graph relationships
      await this.updateKnowledgeGraph(userId, action, entityType, entityId, entityName, metadata);

      // Update product relationships if relevant
      if (entityType === 'product' && (action === 'view' || action === 'purchase' || action === 'analyze')) {
        await this.updateProductRelationships(userId, entityId, entityName, metadata);
      }

    } catch (error) {
      console.error('Error tracking user behavior:', error);
    }
  }

  // Update user interests based on behavior
  private async updateUserInterests(
    userId: number, 
    entityType: string, 
    entityName: string, 
    action: string, 
    metadata: any
  ): Promise<void> {
    const category = this.extractCategory(entityType, entityName, metadata);
    const subcategory = this.extractSubcategory(entityName, metadata);
    
    // Calculate strength boost based on action
    const strengthBoost = this.getActionStrength(action);

    try {
      // Check if interest already exists
      const existingInterest = await db
        .select()
        .from(userInterests)
        .where(and(
          eq(userInterests.userId, userId),
          eq(userInterests.category, category),
          eq(userInterests.subcategory, subcategory)
        ))
        .limit(1);

      if (existingInterest.length > 0) {
        // Update existing interest
        const newStrength = Math.min(10.0, existingInterest[0].strength + strengthBoost);
        await db
          .update(userInterests)
          .set({ 
            strength: newStrength,
            lastUpdated: new Date()
          })
          .where(eq(userInterests.id, existingInterest[0].id));
      } else {
        // Create new interest
        await db.insert(userInterests).values({
          userId,
          category,
          subcategory,
          strength: strengthBoost
        });
      }
    } catch (error) {
      console.error('Error updating user interests:', error);
    }
  }

  // Update knowledge graph nodes and edges
  private async updateKnowledgeGraph(
    userId: number, 
    action: string, 
    entityType: string, 
    entityId: string, 
    entityName: string, 
    metadata: any
  ): Promise<void> {
    try {
      const userNodeId = `user_${userId}`;
      const entityNodeId = `${entityType}_${entityId}`;

      // Create or update user node
      await this.upsertKnowledgeNode(userNodeId, 'user', `User ${userId}`, {
        userId,
        lastActive: new Date()
      });

      // Create or update entity node
      await this.upsertKnowledgeNode(entityNodeId, entityType, entityName, {
        entityId,
        category: this.extractCategory(entityType, entityName, metadata),
        ...metadata
      });

      // Create or strengthen edge between user and entity
      await this.upsertKnowledgeEdge(
        userNodeId, 
        entityNodeId, 
        action, 
        this.getActionStrength(action),
        { timestamp: new Date(), metadata }
      );

      // Create category relationships
      const category = this.extractCategory(entityType, entityName, metadata);
      if (category) {
        const categoryNodeId = `category_${category}`;
        await this.upsertKnowledgeNode(categoryNodeId, 'category', category, { category });
        await this.upsertKnowledgeEdge(entityNodeId, categoryNodeId, 'belongs_to', 1.0, {});
        await this.upsertKnowledgeEdge(userNodeId, categoryNodeId, 'interested_in', 0.5, {});
      }

      // Create brand relationships if available
      if (metadata.brand) {
        const brandNodeId = `brand_${metadata.brand}`;
        await this.upsertKnowledgeNode(brandNodeId, 'brand', metadata.brand, { brand: metadata.brand });
        await this.upsertKnowledgeEdge(entityNodeId, brandNodeId, 'made_by', 1.0, {});
        await this.upsertKnowledgeEdge(userNodeId, brandNodeId, 'prefers', 0.3, {});
      }

    } catch (error) {
      console.error('Error updating knowledge graph:', error);
    }
  }

  // Upsert knowledge node
  private async upsertKnowledgeNode(nodeId: string, nodeType: string, label: string, properties: any): Promise<void> {
    try {
      const existing = await db
        .select()
        .from(knowledgeNodes)
        .where(eq(knowledgeNodes.nodeId, nodeId))
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(knowledgeNodes)
          .set({ 
            label,
            properties,
            updatedAt: new Date()
          })
          .where(eq(knowledgeNodes.nodeId, nodeId));
      } else {
        await db.insert(knowledgeNodes).values({
          nodeId,
          nodeType,
          label,
          properties
        });
      }
    } catch (error) {
      console.error('Error upserting knowledge node:', error);
    }
  }

  // Upsert knowledge edge
  private async upsertKnowledgeEdge(
    fromNode: string, 
    toNode: string, 
    edgeType: string, 
    weight: number, 
    properties: any
  ): Promise<void> {
    try {
      const existing = await db
        .select()
        .from(knowledgeEdges)
        .where(and(
          eq(knowledgeEdges.fromNode, fromNode),
          eq(knowledgeEdges.toNode, toNode),
          eq(knowledgeEdges.edgeType, edgeType)
        ))
        .limit(1);

      if (existing.length > 0) {
        const newWeight = Math.min(10.0, existing[0].weight + weight);
        await db
          .update(knowledgeEdges)
          .set({ 
            weight: newWeight,
            properties,
            lastStrengthened: new Date()
          })
          .where(eq(knowledgeEdges.id, existing[0].id));
      } else {
        await db.insert(knowledgeEdges).values({
          fromNode,
          toNode,
          edgeType,
          weight,
          properties
        });
      }
    } catch (error) {
      console.error('Error upserting knowledge edge:', error);
    }
  }

  // Update product relationships based on user behavior
  private async updateProductRelationships(
    userId: number, 
    productId: string, 
    productName: string, 
    metadata: any
  ): Promise<void> {
    try {
      // Get user's recent product interactions
      const recentProducts = await db
        .select()
        .from(userBehavior)
        .where(and(
          eq(userBehavior.userId, userId),
          eq(userBehavior.entityType, 'product'),
          gt(userBehavior.timestamp, new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)) // Last 7 days
        ))
        .orderBy(desc(userBehavior.timestamp))
        .limit(10);

      // Create relationships with recently viewed products
      for (const product of recentProducts) {
        if (product.entityId !== productId) {
          await this.upsertProductRelationship(
            productId,
            product.entityId,
            'viewed_together',
            0.5
          );
        }
      }

      // Create category-based relationships
      if (metadata.category) {
        const categoryProducts = await db
          .select()
          .from(userBehavior)
          .where(and(
            eq(userBehavior.entityType, 'product'),
            sql`metadata->>'category' = ${metadata.category}`
          ))
          .limit(5);

        for (const product of categoryProducts) {
          if (product.entityId !== productId) {
            await this.upsertProductRelationship(
              productId,
              product.entityId,
              'similar_category',
              0.3
            );
          }
        }
      }

    } catch (error) {
      console.error('Error updating product relationships:', error);
    }
  }

  // Upsert product relationship
  private async upsertProductRelationship(
    productA: string, 
    productB: string, 
    relationshipType: string, 
    strength: number
  ): Promise<void> {
    try {
      const existing = await db
        .select()
        .from(productRelationships)
        .where(and(
          eq(productRelationships.productA, productA),
          eq(productRelationships.productB, productB),
          eq(productRelationships.relationshipType, relationshipType)
        ))
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(productRelationships)
          .set({ 
            strength: Math.min(10.0, existing[0].strength + strength),
            userCount: existing[0].userCount + 1
          })
          .where(eq(productRelationships.id, existing[0].id));
      } else {
        await db.insert(productRelationships).values({
          productA,
          productB,
          relationshipType,
          strength
        });
      }
    } catch (error) {
      console.error('Error upserting product relationship:', error);
    }
  }

  // Get comprehensive user profile with knowledge graph data
  async getUserProfile(userId: number): Promise<UserProfile> {
    try {
      const [interests, recentBehavior] = await Promise.all([
        db.select().from(userInterests).where(eq(userInterests.userId, userId)).orderBy(desc(userInterests.strength)),
        db.select().from(userBehavior).where(eq(userBehavior.userId, userId)).orderBy(desc(userBehavior.timestamp)).limit(50)
      ]);

      const behaviorPatterns = this.analyzeBehaviorPatterns(recentBehavior);
      const recommendations = await this.generateRecommendations(userId, interests, recentBehavior);

      return {
        interests,
        recentBehavior,
        recommendations,
        behaviorPatterns
      };
    } catch (error) {
      console.error('Error getting user profile:', error);
      return {
        interests: [],
        recentBehavior: [],
        recommendations: [],
        behaviorPatterns: {
          mostActiveHours: [],
          favoriteCategories: [],
          purchasePatterns: [],
          searchPatterns: []
        }
      };
    }
  }

  // Get knowledge graph visualization data
  async getKnowledgeGraphVisualization(userId: number): Promise<{ nodes: GraphNode[], edges: GraphEdge[] }> {
    try {
      const userNodeId = `user_${userId}`;
      
      // Get nodes connected to user
      const userEdges = await db
        .select()
        .from(knowledgeEdges)
        .where(eq(knowledgeEdges.fromNode, userNodeId))
        .orderBy(desc(knowledgeEdges.weight))
        .limit(50);

      const nodeIds = [userNodeId, ...userEdges.map(edge => edge.toNode)];
      
      const nodes = await db
        .select()
        .from(knowledgeNodes)
        .where(sql`node_id = ANY(${nodeIds})`);

      // Get edges between these nodes
      const edges = await db
        .select()
        .from(knowledgeEdges)
        .where(and(
          sql`from_node = ANY(${nodeIds})`,
          sql`to_node = ANY(${nodeIds})`
        ));

      // Transform for visualization
      const graphNodes: GraphNode[] = nodes.map(node => ({
        id: node.nodeId,
        type: node.nodeType,
        label: node.label,
        properties: node.properties,
        size: this.getNodeSize(node.nodeType),
        color: this.getNodeColor(node.nodeType),
        x: Math.random() * 800,
        y: Math.random() * 600
      }));

      const graphEdges: GraphEdge[] = edges.map(edge => ({
        from: edge.fromNode,
        to: edge.toNode,
        type: edge.edgeType,
        weight: edge.weight,
        properties: edge.properties,
        width: Math.max(1, edge.weight * 2),
        color: this.getEdgeColor(edge.edgeType)
      }));

      return { nodes: graphNodes, edges: graphEdges };
    } catch (error) {
      console.error('Error getting knowledge graph visualization:', error);
      return { nodes: [], edges: [] };
    }
  }

  // Generate intelligent recommendations based on knowledge graph
  private async generateRecommendations(
    userId: number, 
    interests: UserInterest[], 
    recentBehavior: UserBehavior[]
  ): Promise<any[]> {
    const recommendations = [];

    try {
      // Interest-based recommendations
      for (const interest of interests.slice(0, 3)) {
        const similarUsers = await this.findSimilarUsers(userId, interest.category);
        const categoryRecommendations = await this.getPopularInCategory(interest.category, similarUsers);
        recommendations.push({
          type: 'interest_based',
          category: interest.category,
          items: categoryRecommendations,
          reason: `Based on your ${interest.strength.toFixed(1)}/10 interest in ${interest.category}`
        });
      }

      // Behavioral pattern recommendations
      const behaviorPatterns = this.analyzeBehaviorPatterns(recentBehavior);
      if (behaviorPatterns.favoriteCategories.length > 0) {
        const trendingInCategory = await this.getTrendingInCategories(behaviorPatterns.favoriteCategories);
        recommendations.push({
          type: 'trending',
          items: trendingInCategory,
          reason: 'Trending in your favorite categories'
        });
      }

      return recommendations;
    } catch (error) {
      console.error('Error generating recommendations:', error);
      return [];
    }
  }

  // Helper methods
  private extractCategory(entityType: string, entityName: string, metadata: any): string {
    if (metadata.category) return metadata.category;
    
    // Simple category extraction based on keywords
    const name = entityName.toLowerCase();
    if (name.includes('phone') || name.includes('smartphone')) return 'electronics';
    if (name.includes('shoe') || name.includes('sneaker')) return 'fashion';
    if (name.includes('laptop') || name.includes('computer')) return 'electronics';
    if (name.includes('pizza') || name.includes('burger')) return 'food';
    if (name.includes('hotel') || name.includes('resort')) return 'travel';
    
    return entityType;
  }

  private extractSubcategory(entityName: string, metadata: any): string {
    if (metadata.subcategory) return metadata.subcategory;
    return entityName.split(' ')[0].toLowerCase();
  }

  private getActionStrength(action: string): number {
    const strengths = {
      'view': 0.1,
      'search': 0.2,
      'analyze': 0.5,
      'compare': 0.7,
      'purchase': 2.0,
      'favorite': 1.5
    };
    return strengths[action] || 0.1;
  }

  private analyzeBehaviorPatterns(behaviors: UserBehavior[]) {
    const hours = behaviors.map(b => new Date(b.timestamp).getHours());
    const categories = behaviors.map(b => b.metadata?.category).filter(Boolean);
    
    return {
      mostActiveHours: this.getMostFrequent(hours).map(h => `${h}:00`),
      favoriteCategories: this.getMostFrequent(categories),
      purchasePatterns: behaviors.filter(b => b.action === 'purchase').map(b => b.entityName),
      searchPatterns: behaviors.filter(b => b.action === 'search').map(b => b.entityName)
    };
  }

  private getMostFrequent(arr: any[]): any[] {
    const counts = arr.reduce((acc, item) => {
      acc[item] = (acc[item] || 0) + 1;
      return acc;
    }, {});
    
    return Object.entries(counts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([item]) => item);
  }

  private getNodeSize(nodeType: string): number {
    const sizes = {
      'user': 30,
      'product': 20,
      'category': 25,
      'brand': 15,
      'feature': 10
    };
    return sizes[nodeType] || 15;
  }

  private getNodeColor(nodeType: string): string {
    const colors = {
      'user': '#3b82f6',
      'product': '#10b981',
      'category': '#8b5cf6',
      'brand': '#f59e0b',
      'feature': '#6b7280'
    };
    return colors[nodeType] || '#6b7280';
  }

  private getEdgeColor(edgeType: string): string {
    const colors = {
      'likes': '#10b981',
      'purchased': '#ef4444',
      'viewed': '#3b82f6',
      'similar_to': '#8b5cf6',
      'belongs_to': '#6b7280'
    };
    return colors[edgeType] || '#6b7280';
  }

  private async findSimilarUsers(userId: number, category: string): Promise<number[]> {
    // Simplified implementation - would be more sophisticated in production
    return [];
  }

  private async getPopularInCategory(category: string, userIds: number[]): Promise<any[]> {
    // Simplified implementation - would query actual product data
    return [];
  }

  private async getTrendingInCategories(categories: string[]): Promise<any[]> {
    // Simplified implementation - would query trending products
    return [];
  }
}

export const knowledgeGraphService = new KnowledgeGraphService();