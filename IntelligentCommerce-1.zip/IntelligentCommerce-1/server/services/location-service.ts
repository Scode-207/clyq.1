interface UserLocation {
  latitude: number;
  longitude: number;
  city: string;
  state: string;
  country: string;
  zipCode?: string;
  address?: string;
}

interface LocationFromIP {
  ip: string;
  city: string;
  region: string;
  country: string;
  loc: string; // "lat,lng"
  timezone: string;
}

export class LocationService {
  private ipInfoToken = process.env.IPINFO_TOKEN;

  async getUserLocationFromIP(ip: string): Promise<UserLocation | null> {
    try {
      const response = await fetch(`https://ipinfo.io/${ip}?token=${this.ipInfoToken}`);
      const data: LocationFromIP = await response.json();
      
      if (data.loc) {
        const [lat, lng] = data.loc.split(',').map(Number);
        return {
          latitude: lat,
          longitude: lng,
          city: data.city,
          state: data.region,
          country: data.country,
          address: `${data.city}, ${data.region}, ${data.country}`
        };
      }
      return null;
    } catch (error) {
      console.error('Error getting location from IP:', error);
      return null;
    }
  }

  async reverseGeocode(latitude: number, longitude: number): Promise<UserLocation | null> {
    try {
      // Using OpenStreetMap Nominatim for reverse geocoding (free)
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`
      );
      const data = await response.json();
      
      if (data && data.address) {
        return {
          latitude,
          longitude,
          city: data.address.city || data.address.town || data.address.village,
          state: data.address.state,
          country: data.address.country,
          zipCode: data.address.postcode,
          address: data.display_name
        };
      }
      return null;
    } catch (error) {
      console.error('Error in reverse geocoding:', error);
      return null;
    }
  }

  calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 3959; // Earth's radius in miles
    const dLat = this.toRadians(lat2 - lat1);
    const dLng = this.toRadians(lng2 - lng1);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }
}

export const locationService = new LocationService();
export type { UserLocation };