import Groq from "groq-sdk";
import { amazonService } from './amazon-service';
import { zomatoService } from './zomato-service';
import { makeMyTripService } from './makemytrip-service';
import { personalizationService } from './personalization-service';
import { tavilyService } from './tavily-service';
import { serpService } from './serp-service';
import { locationService } from './location-service';
import { geminiConversationalService } from './gemini-conversational-service';

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY || "default_key"
});

interface ChatContext {
  userId: number;
  userPreferences?: any;
  conversationHistory: Array<{ role: "user" | "assistant"; content: string }>;
  domain?: "food" | "travel" | "marketplace" | "medical" | "general";
}

interface AgentResponse {
  content: string;
  suggestions?: Array<{
    type: "hotel" | "restaurant" | "product" | "medical_facility" | "medication" | "action";
    title: string;
    description: string;
    data: any;
  }>;
  domain?: "food" | "travel" | "marketplace" | "medical";
  thinking?: string;
}

export class GroqService {
  async generateResponse(message: string, context: ChatContext, recentBooking?: any): Promise<AgentResponse> {
    try {
      // Check if this is a post-booking context
      if (recentBooking && this.isPostBookingMessage(message)) {
        return await this.generatePostBookingResponse(message, context, recentBooking);
      }
      
      // Step 1: Generate thinking process using Groq
      const thinking = await this.generateThinking(message, context);
      
      // Step 2: Detect if user wants specific items/recommendations
      const wantsItems = this.detectItemRequest(message);
      
      // Step 3: Analyze user intent and get suggestions only if they want items
      let suggestions: any[] = [];
      let domain = "general";
      
      if (wantsItems) {
        const intentAnalysis = await this.analyzeUserIntent(message);
        domain = intentAnalysis.domain;
        suggestions = await this.getRealTimeSuggestions(message, intentAnalysis, context);
      }
      
      // Step 4: Generate conversational response using Gemini
      const content = await geminiConversationalService.generateConversationalResponse(
        message,
        thinking,
        context,
        wantsItems,
        suggestions
      );
      
      return {
        content: content,
        suggestions: wantsItems ? suggestions.slice(0, 3) : [],
        domain: domain as "food" | "travel" | "marketplace" | "general",
        thinking: thinking
      };
    } catch (error) {
      console.error("Groq API error:", error);
      return {
        content: "I'm experiencing some technical difficulties. Please try again in a moment.",
        suggestions: [],
        domain: "general",
        thinking: `Error occurred: ${error.message}. Attempted to process user query but encountered API limitations.`
      };
    }
  }

  private detectItemRequest(message: string): boolean {
    // Keywords that indicate user wants specific recommendations/items
    const itemRequestKeywords = [
      'find', 'show me', 'suggest', 'recommend', 'look for', 'search for',
      'book', 'reserve', 'order', 'buy', 'get me', 'i want', 'i need',
      'compare', 'vs', 'between', 'which is better', 'help me choose',
      'best', 'good', 'top', 'popular', 'nearby', 'around here'
    ];
    
    // Specific domain indicators
    const domainIndicators = [
      'restaurant', 'food', 'meal', 'dinner', 'lunch', 'eat',
      'hotel', 'flight', 'travel', 'trip', 'stay', 'vacation',
      'product', 'buy', 'purchase', 'shop', 'item'
    ];
    
    const lowerMsg = message.toLowerCase();
    
    // Check for direct item requests
    const hasItemKeyword = itemRequestKeywords.some(keyword => lowerMsg.includes(keyword));
    const hasDomainKeyword = domainIndicators.some(keyword => lowerMsg.includes(keyword));
    
    // Questions that imply wanting suggestions
    const isQuestionForItems = (lowerMsg.includes('what') || lowerMsg.includes('where') || lowerMsg.includes('which')) 
                              && hasDomainKeyword;
    
    return hasItemKeyword || isQuestionForItems;
  }

  private async generateThinking(message: string, context: ChatContext): Promise<string> {
    // Generate thinking process locally for faster response
    const userPrefs = context.userPreferences || {};
    const domain = this.quickDomainDetection(message);
    
    return `THINKING PROCESS:

1. ANALYZING USER REQUEST:
   • Query: "${message}"
   • Detected domain: ${domain}
   • User seems to want: ${this.interpretIntent(message)}

2. APPLYING USER PREFERENCES:
   • Food preferences: ${JSON.stringify(userPrefs.dietary || ['healthy', 'vegetarian-friendly'])}
   • Shopping style: ${JSON.stringify(userPrefs.shoppingStyle || ['sustainable', 'mid-range'])}
   • Travel preferences: ${JSON.stringify(userPrefs.travelStyle || ['eco-friendly', 'pet-friendly'])}

3. PERSONALIZING APPROACH:
   • Will filter for user's preferred price range and dietary needs
   • Considering time of day and urgency level
   • Integrating real-time data from ${domain === 'food' ? 'Zomato' : domain === 'travel' ? 'MakeMyTrip' : 'Amazon'} API

4. RESPONSE STRATEGY:
   • Fetch real data from integrated APIs
   • Present top 2-3 personalized recommendations
   • Include specific details like ratings, prices, and availability
   • Format as conversational response with actionable suggestions`;
  }

  private quickDomainDetection(message: string): string {
    const medicalKeywords = ['doctor', 'hospital', 'clinic', 'medicine', 'medication', 'prescription', 'pharmacy', 'medical', 'health', 'symptom', 'treatment'];
    const foodKeywords = ['restaurant', 'food', 'eat', 'meal', 'dinner', 'lunch', 'delivery', 'cuisine', 'sushi', 'thai', 'pizza'];
    const travelKeywords = ['hotel', 'flight', 'travel', 'book', 'vacation', 'trip', 'stay', 'accommodation'];
    const shoppingKeywords = ['buy', 'product', 'gear', 'shop', 'price', 'amazon', 'purchase', 'sustainable'];
    
    const lowerMsg = message.toLowerCase();
    
    if (medicalKeywords.some(keyword => lowerMsg.includes(keyword))) return 'medical';
    if (foodKeywords.some(keyword => lowerMsg.includes(keyword))) return 'food';
    if (travelKeywords.some(keyword => lowerMsg.includes(keyword))) return 'travel';
    if (shoppingKeywords.some(keyword => lowerMsg.includes(keyword))) return 'marketplace';
    
    return 'general';
  }

  private interpretIntent(message: string): string {
    const lowerMsg = message.toLowerCase();
    
    if (lowerMsg.includes('find') || lowerMsg.includes('show')) return 'discovery/search';
    if (lowerMsg.includes('book') || lowerMsg.includes('reserve')) return 'booking/reservation';
    if (lowerMsg.includes('recommend') || lowerMsg.includes('suggest')) return 'personalized recommendations';
    if (lowerMsg.includes('compare') || lowerMsg.includes('vs')) return 'comparison';
    if (lowerMsg.includes('cheap') || lowerMsg.includes('budget')) return 'budget-conscious search';
    if (lowerMsg.includes('expensive') || lowerMsg.includes('luxury')) return 'premium/luxury search';
    
    return 'general inquiry';
  }

  private formatAsMarkdown(content: string, domain: string, suggestions: any[]): string {
    const domainEmoji = domain === 'food' ? '🍽️' : domain === 'travel' ? '✈️' : '🛍️';
    const domainName = domain === 'food' ? 'Restaurant' : domain === 'travel' ? 'Travel' : 'Product';
    
    // Clean up content - remove only JSON blocks and malformed trailing JSON
    const cleanContent = content
      .replace(/```json[\s\S]*?```/g, '')
      .replace(/\n\s*\}\s*,?\s*\n\s*\}\s*,?\s*\n[\s\S]*$/g, '') // Remove trailing JSON fragments
      .replace(/##\s*🍽️\s*Restaurant\s*Recommendations\s*/g, '')
      .replace(/##\s*✈️\s*Travel\s*Recommendations\s*/g, '')
      .replace(/##\s*🛍️\s*Product\s*Recommendations\s*/g, '')
      .trim();
    
    let markdown = `## ${domainEmoji} ${domainName} Recommendations\n\n`;
    
    if (cleanContent) {
      markdown += `${cleanContent}\n\n`;
    }
    
    if (suggestions.length > 0) {
      markdown += `### 🎯 Top Picks for You:\n\n`;
      suggestions.forEach((suggestion, index) => {
        const data = suggestion.data;
        markdown += `**${index + 1}. ${suggestion.title}**\n`;
        markdown += `- ${suggestion.description}\n`;
        if (data.price) markdown += `- 💰 Price: ${data.price}\n`;
        if (data.rating) markdown += `- ⭐ Rating: ${data.rating}\n`;
        if (data.distance !== undefined) markdown += `- 📍 Distance: ${data.distance} miles\n`;
        if (data.deliveryTime) markdown += `- 🚚 Delivery: ${data.deliveryTime}\n`;
        markdown += `\n`;
      });
    }
    
    return markdown;
  }

  private buildEnhancedSystemPrompt(context: ChatContext, thinking: string, intentAnalysis: any, realSuggestions: any[]): string {
    const preferences = context.userPreferences || {};
    const location = preferences?.location;
    const foodPrefs = preferences?.foodPreferences;
    const personalInfo = preferences?.personalInfo;
    
    return `You are an AI-powered personal commerce agent for OmniAgent, specializing in personalized food recommendations.

USER PROFILE:
- Name: ${personalInfo?.firstName || 'User'}
- Location: ${location?.city || 'Unknown'}, ${location?.state || ''} ${location?.country || ''}
- Food Preferences: ${foodPrefs ? `
  - Favorite Cuisines: ${foodPrefs.favoriteCuisines?.join(', ') || 'None specified'}
  - Dietary Restrictions: ${foodPrefs.dietaryRestrictions?.join(', ') || 'None'}
  - Spice Preference: ${foodPrefs.spicePreference || 'Not specified'}
  - Budget: ${foodPrefs.budget || 'Not specified'}
` : 'Not set up yet'}

THINKING PROCESS:
${thinking}

ANALYSIS RESULTS:
- Domain: ${intentAnalysis.domain}
- Intent: ${intentAnalysis.intent}
- Entities: ${JSON.stringify(intentAnalysis.entities)}

AVAILABLE REAL DATA WITH IMAGES:
${realSuggestions.length > 0 ? realSuggestions.map((item, i) => 
  `${i + 1}. ${item.title} (${item.type})
   Description: ${item.description}
   Image URL: ${item.imageUrl || 'No image available'}
   Location Data: ${item.data?.location ? JSON.stringify(item.data.location) : 'Not available'}
   Full Details: ${JSON.stringify(item.data, null, 2)}`
).join('\n\n') : 'No specific data available'}

CRITICAL: You must respond ONLY with clean markdown text. Absolutely NO JSON, NO code blocks, NO structured data format.

Write a natural, conversational response in plain markdown format. Include:
- A header with emoji (## 🍽️ title)
- Brief introduction mentioning ${personalInfo?.firstName || 'User'}'s actual location (${location?.city || 'their area'}) and preferences
- 2-3 specific recommendations with details including images using ![Alt text](image_url)
- Include real addresses, phone numbers, delivery times, and distances
- Explanation of why these match their needs based on location and specific preferences (dietary restrictions: ${foodPrefs?.dietaryRestrictions?.join(', ') || 'None'}, favorite cuisines: ${foodPrefs?.favoriteCuisines?.join(', ') || 'None specified'}, spice preference: ${foodPrefs?.spicePreference || 'Not specified'})
- Friendly closing question

Example response (use this exact structure):

## 🍽️ Perfect Healthy Options Found!

I found some excellent restaurants that match your preference for healthy, sustainable dining:

### Top Recommendations:

**Green Bowl Cafe** - Organic Farm-to-Table  
![Green Bowl Cafe](image_url_here)  
Price: $16-25 per dish | Rating: 4.7★ | Distance: 0.8 miles  
📍 123 Main St, Your City | ☎️ (555) 123-4567  
🚚 Delivery in 25-35 minutes. Specializes in locally sourced organic ingredients.

**Vitality Bistro** - Plant-Based Excellence  
![Vitality Bistro](image_url_here)  
Price: $15-28 per meal | Rating: 4.5★ | Distance: 1.2 miles  
📍 456 Second Ave, Your City | ☎️ (555) 234-5678  
🚚 Delivery in 30-40 minutes. Features extensive vegan and gluten-free options.

### Why These Match Your Preferences:
- Sustainable sourcing and ethical practices
- Vegetarian-friendly menu options
- High-quality ingredients with transparency
- Excellent customer reviews and ratings

Would you like me to help you explore the menu or get more details about these restaurants?`;
  }

  async generateEnhancedRestaurantResponse(message: string, context: ChatContext, userLocation?: { latitude: number; longitude: number; city: string }): Promise<AgentResponse> {
    try {
      // Get user's current location if not provided
      let location = userLocation;
      if (!location && context.userId) {
        // Use IP-based location detection
        location = { latitude: 0, longitude: 0, city: 'Current Location' };
      }

      const locationString = location ? location.city : 'near you';
      
      // Step 1: Use Tavily for comprehensive restaurant data
      const tavilyResults = await tavilyService.searchRestaurants(message, locationString);
      
      // Step 2: Get images for top restaurants using SERP API
      const restaurantsWithImages = [];
      for (const restaurant of tavilyResults.restaurants.slice(0, 3)) {
        try {
          const images = await serpService.getRestaurantImages(restaurant.name, locationString);
          restaurantsWithImages.push({
            ...restaurant,
            images: images.images.slice(0, 3) // Get top 3 images
          });
        } catch (error) {
          console.error(`Failed to get images for ${restaurant.name}:`, error);
          restaurantsWithImages.push({
            ...restaurant,
            images: []
          });
        }
      }

      // Step 3: Use Groq to format the response
      const formattedResponse = await this.formatRestaurantResponse(
        message,
        restaurantsWithImages,
        tavilyResults.summary,
        context
      );

      return {
        content: formattedResponse,
        suggestions: restaurantsWithImages.map(restaurant => ({
          type: "restaurant" as const,
          title: restaurant.name,
          description: `${restaurant.cuisine || 'Restaurant'} • ${restaurant.rating ? restaurant.rating + '/5' : 'No rating'} • ${restaurant.priceRange || 'Price not available'}`,
          data: restaurant
        })),
        domain: "food",
        thinking: `Enhanced restaurant search combining Tavily data with SERP images for ${restaurantsWithImages.length} restaurants in ${locationString}`
      };
    } catch (error) {
      console.error('Enhanced restaurant search error:', error);
      return {
        content: "I'm having trouble finding restaurants right now. Please try again in a moment.",
        suggestions: [],
        domain: "food"
      };
    }
  }

  private async formatRestaurantResponse(
    query: string,
    restaurants: any[],
    summary: string,
    context: ChatContext
  ): Promise<string> {
    const systemPrompt = `You are a helpful restaurant discovery assistant. Format the restaurant information in a conversational, engaging way.

User query: "${query}"
Search summary: "${summary}"

Available restaurants with complete data and images:
${restaurants.map(r => `
- ${r.name}
  Rating: ${r.rating || 'Not rated'}
  Price: ${r.priceRange || 'Not specified'}
  Cuisine: ${r.cuisine || 'Not specified'}
  Address: ${r.address}
  Features: ${r.features.join(', ') || 'None listed'}
  Description: ${r.description}
  Images available: ${r.images.length} photos
`).join('\n')}

Format your response to:
1. Acknowledge the user's request
2. Present the top restaurants in an engaging way
3. Highlight key features and ratings
4. Mention that photos and details are available
5. Be conversational but informative
6. Keep it concise but thorough`;

    try {
      const completion = await groq.chat.completions.create({
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Please format a response for these restaurants based on the user's query: "${query}"` }
        ],
        model: "llama-3.3-70b-versatile",
        temperature: 0.7,
        max_tokens: 800
      });

      return completion.choices[0]?.message?.content || summary;
    } catch (error) {
      console.error('Error formatting restaurant response:', error);
      return summary;
    }
  }

  private async getRealTimeSuggestions(message: string, intent: any, context: ChatContext): Promise<any[]> {
    const suggestions: any[] = [];
    
    try {
      const domain = intent.domain;
      const userPreferences = context.userPreferences || {};
      
      if (domain === 'food') {
        // Get user's real location first
        const { locationService } = await import('./location-service');
        const userLocation = await locationService.getUserLocationFromIP('127.0.0.1');
        
        const latitude = userLocation?.latitude || 40.7128;
        const longitude = userLocation?.longitude || -74.0060;
        const locationString = userLocation?.city || 'San Francisco';
        
        console.log('Using location for restaurant search:', { latitude, longitude, locationString });
        
        // Search restaurants using real coordinates
        const restaurants = await zomatoService.searchRestaurants(latitude, longitude, {
          dietary: userPreferences.dietary,
          delivery: true
        });

        // Get images and enhanced data using SERP API
        const { serpService } = await import('./serp-service');
        
        for (const restaurant of restaurants.slice(0, 3)) {
          try {
            // Search for restaurant images
            const images = await serpService.searchImages(`${restaurant.name} restaurant ${locationString} food`);
            
            suggestions.push({
              type: 'restaurant',
              title: restaurant.name,
              description: `${restaurant.cuisine} • ${restaurant.priceRange} • ${restaurant.rating}★ (${restaurant.reviews} reviews) • ${restaurant.distance}mi away`,
              imageUrl: images[0]?.url || restaurant.imageUrl,
              data: {
                ...restaurant,
                location: userLocation,
                images: images.slice(0, 3),
                realTimeData: true
              }
            });
          } catch (error) {
            console.error('Error fetching images for restaurant:', restaurant.name, error);
            suggestions.push({
              type: 'restaurant',
              title: restaurant.name,
              description: `${restaurant.cuisine} • ${restaurant.priceRange} • ${restaurant.rating}★ (${restaurant.reviews} reviews)`,
              data: restaurant
            });
          }
        }
      }
      
      if (domain === 'travel') {
        // Use ENHANCED MOCK DATA for hotels - detailed cards with reviews
        const { commerceService } = await import('./commerce-service');
        const hotels = await commerceService.searchHotels();
        
        for (const hotel of hotels.slice(0, 4)) {
          suggestions.push({
            type: 'hotel',
            title: hotel.name,
            description: `${hotel.location} • $${hotel.price}/night • ${hotel.rating}★ (${hotel.reviews} reviews) • ${hotel.petFriendly ? 'Pet-Friendly' : 'Standard'}`,
            imageUrl: hotel.image,
            data: {
              ...hotel,
              amenitiesHighlight: hotel.amenities.slice(0, 3).join(', '),
              mockData: true // Flag to indicate this is our enhanced mock data
            }
          });
        }
      }
      
      if (domain === 'marketplace') {
        // Get real product recommendations from Amazon
        const { amazonService } = await import('./amazon-service');
        const products = await amazonService.searchProducts(message, {
          sustainable: userPreferences.shoppingStyle?.includes('eco-friendly'),
          maxPrice: 200
        });
        
        suggestions.push(...products.slice(0, 3).map(product => ({
          type: 'product',
          title: product.name,
          description: `${product.brand} • $${product.price} • ${product.rating}★ (${product.reviews} reviews) ${product.sustainable ? '• Sustainable' : ''}`,
          data: product
        })));
      }
      
      // Add flight suggestions when user mentions flights
      if (message.toLowerCase().includes('flight') || message.toLowerCase().includes('book flight')) {
        const { makeMyTripService } = await import('./makemytrip-service');
        const flights = await makeMyTripService.searchFlights('San Francisco', 'Seattle');
        
        suggestions.push(...flights.slice(0, 3).map(f => ({
          type: 'flight' as const,
          title: `${f.airline} ${f.flightNumber}`,
          description: `${f.departure.city} → ${f.arrival.city} • $${f.price} • ${f.rating}⭐ (${f.reviews} reviews)`,
          data: f
        })));
      }
      
      // Add medical suggestions for MediGroq domain
      if (domain === 'medical') {
        // Get user's location for medical facility search
        const { locationService } = await import('./location-service');
        const userLocation = await locationService.getUserLocationFromIP('127.0.0.1');
        const locationString = userLocation?.city || 'San Francisco';
        
        // Medical facility search
        if (message.toLowerCase().includes('hospital') || message.toLowerCase().includes('clinic') || 
            message.toLowerCase().includes('doctor') || message.toLowerCase().includes('medical facility')) {
          const { zenSerpMedicalService } = await import('./zenserp-medical-service');
          const facilities = await zenSerpMedicalService.searchMedicalFacilities(locationString, 'hospital');
          
          suggestions.push(...facilities.slice(0, 3).map(f => ({
            type: 'medical_facility' as const,
            title: f.name,
            description: `${f.type} • ${f.distance.toFixed(1)}mi • $${f.priceRange} • ${f.rating}⭐ (${f.reviews} reviews)`,
            data: f
          })));
        }
        
        // Medication search
        if (message.toLowerCase().includes('medication') || message.toLowerCase().includes('medicine') || 
            message.toLowerCase().includes('prescription') || message.toLowerCase().includes('pharmacy')) {
          const { zenSerpMedicalService } = await import('./zenserp-medical-service');
          const products = await zenSerpMedicalService.searchMedicalProducts('medication', locationString);
          
          suggestions.push(...products.slice(0, 3).map(p => ({
            type: 'medication' as const,
            title: p.name,
            description: `${p.pharmacy} • $${p.price} • ${p.distance.toFixed(1)}mi • ${p.inStock ? 'In Stock' : 'Out of Stock'}`,
            data: p
          })));
        }
      }
      
      return suggestions;
    } catch (error) {
      console.error('Real-time suggestions error:', error);
      return [];
    }
  }

  private buildSystemPrompt(context: ChatContext): string {
    const preferences = context.userPreferences || {};
    
    // Extract detailed user data for personalization
    const location = preferences?.location;
    const foodPrefs = preferences?.foodPreferences;
    const shoppingPrefs = preferences?.shoppingPreferences;
    const travelPrefs = preferences?.travelPreferences;
    const personalInfo = preferences?.personalInfo;
    
    // Get current time context
    const now = new Date();
    const timeOfDay = now.getHours() < 12 ? 'morning' : now.getHours() < 17 ? 'afternoon' : 'evening';
    const dayOfWeek = now.toLocaleDateString('en-US', { weekday: 'long' });
    
    return `You are an AI-powered personal commerce agent for OmniAgent, specializing in food ordering, travel booking, and marketplace shopping. You provide HIGHLY PERSONALIZED, context-aware assistance across all domains.

COMPREHENSIVE USER PROFILE:
- User ID: ${context.userId}
- Full Name: ${personalInfo?.firstName || 'User'} ${personalInfo?.lastName || ''}
- Username: ${personalInfo?.username || 'Not specified'}
- Email: ${personalInfo?.email || 'Not specified'}
- Current Location: ${location?.city || 'Unknown'}, ${location?.state || ''} ${location?.country || ''}
- Time Context: ${timeOfDay} on ${dayOfWeek}

DETAILED FOOD PREFERENCES: ${foodPrefs ? `
  - Favorite Cuisines: ${foodPrefs.favoriteCuisines?.join(', ') || 'None specified'}
  - Dietary Restrictions: ${foodPrefs.dietaryRestrictions?.join(', ') || 'None'}
  - Spice Preference: ${foodPrefs.spicePreference || 'Not specified'}
  - Budget Range: ${foodPrefs.budget || 'Not specified'}
  - Meal Timing: Prefers ${timeOfDay} ${foodPrefs.favoriteCuisines?.includes('coffee') ? 'coffee and light meals' : 'full meals'}
` : 'Not configured - ask about preferences when food-related topics come up'}

DETAILED SHOPPING PREFERENCES: ${shoppingPrefs ? `
  - Favorite Categories: ${shoppingPrefs.favoriteCategories?.join(', ') || 'None specified'}
  - Budget Range: ${shoppingPrefs.budgetRange || 'Not specified'}
  - Sustainability Importance: ${shoppingPrefs.sustainabilityImportance || 'Not specified'}/10
  - Brand Loyalty: ${shoppingPrefs.favoriteCategories?.length > 3 ? 'High' : 'Moderate'}
` : 'Not configured - learn preferences through interactions'}

DETAILED TRAVEL PREFERENCES: ${travelPrefs ? `
  - Preferred Destinations: ${travelPrefs.preferredDestinations?.join(', ') || 'None specified'}
  - Accommodation Types: ${travelPrefs.accommodationType?.join(', ') || 'Not specified'}
  - Travel Budget: ${travelPrefs.budget || 'Not specified'}
  - Travel Style: ${travelPrefs.accommodationType?.includes('luxury') ? 'Luxury traveler' : 'Value-conscious traveler'}
` : 'Not configured - gather travel preferences when needed'}

CAPABILITIES:
1. FOOD ORDERING: Restaurant discovery, menu browsing, order placement
2. TRAVEL BOOKING: Flight searches, hotel reservations, itinerary planning  
3. MARKETPLACE: Product search, price comparison, purchase assistance

RESPONSE FORMAT:
You must respond with valid JSON in this exact format:
{
  "content": "Your conversational response to the user",
  "suggestions": [
    {
      "type": "hotel|restaurant|product|action",
      "title": "Suggestion title",
      "description": "Brief description",
      "data": {
        "name": "Item name",
        "price": "Price if applicable",
        "rating": "Rating if applicable",
        "details": "Additional details object"
      }
    }
  ],
  "domain": "food|travel|marketplace|general"
}

IMPORTANT: Your response must be valid JSON only, no additional text or formatting.

ADVANCED PERSONALIZATION RULES:
- ALWAYS address user by name: ${personalInfo?.firstName || personalInfo?.username || 'User'}
- Use SPECIFIC location data for local recommendations in ${location?.city || 'their area'}
- STRICTLY respect dietary restrictions: ${foodPrefs?.dietaryRestrictions?.join(', ') || 'None specified'}
- Consider budget constraints in ALL recommendations: ${foodPrefs?.budget || shoppingPrefs?.budgetRange || travelPrefs?.budget || 'Budget-conscious'}
- Factor in sustainability preferences (${shoppingPrefs?.sustainabilityImportance || 5}/10 importance)
- Adapt spice levels to user's preference: ${foodPrefs?.spicePreference || 'Not specified'}
- Prioritize user's favorite cuisines: ${foodPrefs?.favoriteCuisines?.join(', ') || 'None specified'}
- Remember conversation history and build on previous interactions
- Use time context: It's ${timeOfDay} on ${dayOfWeek} - adjust recommendations accordingly
- Show deep understanding of user's lifestyle and preferences
- Proactively suggest improvements and alternatives based on user profile

ADVANCED BEHAVIORAL GUIDELINES:
- Be conversational, warm, and highly proactive with ${personalInfo?.firstName || personalInfo?.username || 'the user'}
- Use the user's specific preferences to create DEEPLY personalized recommendations
- For hotels: Include pet-friendly options if user travels with pets, match accommodation style preferences
- For restaurants: Prioritize healthy, sustainable options, respect dietary restrictions, match cuisine preferences
- For products: Focus on eco-friendly brands (${shoppingPrefs?.sustainabilityImportance || 5}/10 importance), match favorite categories
- Always provide specific, actionable suggestions with realistic pricing and details
- Learn from conversation history and build cumulative knowledge
- Proactively suggest complementary items (if booking hotel, suggest restaurants nearby)
- Use contextual awareness: ${timeOfDay} suggestions, ${dayOfWeek} appropriate recommendations
- Show memory of past preferences and conversations
- Ask intelligent follow-up questions to gather more preference data
- Demonstrate understanding of user's lifestyle patterns

MEMORY & LEARNING:
- Build on previous conversation context: ${context.conversationHistory?.length || 0} previous messages
- Remember user's preferred communication style and response length
- Track what recommendations they liked/disliked
- Learn from their interaction patterns and timing

Remember: You're ${personalInfo?.firstName || personalInfo?.username || 'this user'}'s personal commerce assistant who knows them deeply and anticipates their needs across food, travel, and shopping domains.`;
  }

  private generateStructuredResponse(domain: string, suggestions: any[], emoji: string, message: string): string {
    if (domain === 'food' && suggestions.length > 0) {
      const restaurants = suggestions.slice(0, 3);
      let response = `## ${emoji} Perfect Healthy Options Found!

I found some excellent restaurants that match your preference for healthy, sustainable dining:

### Top Recommendations:

`;

      restaurants.forEach((restaurant, index) => {
        response += `**${restaurant.name || `Local Favorite ${index + 1}`}** - ${restaurant.cuisine || 'Healthy Cuisine'}  
Price: ${restaurant.priceRange || '$15-25'} per dish | Rating: ${restaurant.rating || '4.5'}★ | Distance: ${restaurant.distance || '1.2'} miles  
${restaurant.delivery ? `Delivery in ${restaurant.deliveryTime || '30-40'} minutes.` : 'Dine-in available.'} ${restaurant.description || `Features ${restaurant.dietary?.join(', ') || 'vegetarian-friendly'} options.`}

`;
      });

      response += `### Why These Match Your Preferences:
- Focus on healthy, sustainable ingredients
- Vegetarian and dietary-friendly options  
- High customer ratings and reviews
- Convenient locations with great service

Would you like me to help you explore the menu or find more restaurant options?`;
      return response;
    }
    
    if (domain === 'travel' && suggestions.length > 0) {
      const hotels = suggestions.slice(0, 4);
      let response = `## ${emoji} Premium Hotel Selection Found!

I found excellent accommodations with detailed reviews and pricing:

### Featured Hotels:

`;

      hotels.forEach(hotel => {
        const hotelData = hotel.data;
        response += `**${hotelData.name}** - ${hotelData.location}  
💰 **$${hotelData.price}/night** | ⭐ **${hotelData.rating} stars** | 📝 **${hotelData.reviews} reviews** | ${hotelData.petFriendly ? '🐕 Pet-Friendly' : '🏨 Standard'}  
🏨 **Amenities:** ${hotelData.amenities.slice(0, 4).join(', ')}  
📍 ${hotelData.description}

`;
      });

      response += `### 🎯 Why These Hotels Stand Out:
- **Premium locations** with excellent accessibility
- **Verified guest reviews** and high ratings
- **Pet-friendly policies** with dedicated services
- **Comprehensive amenities** for comfort and convenience

💡 **Booking Tip:** These hotels offer the best value in their categories. Would you like me to show more options or help with specific amenities?`;
      return response;
    }
    
    if ((domain === 'travel' && suggestions.some(s => s.type === 'flight')) || 
        message.toLowerCase().includes('book flight') || 
        message.toLowerCase().includes('find flight')) {
      // Show enhanced flight options with detailed information from suggestions
      const flightSuggestions = suggestions.filter(s => s.type === 'flight');
      
      let response = `## ${emoji} Premium Flight Options Found!

I found excellent flight options with detailed reviews and pricing:

### Featured Flights:

`;

      flightSuggestions.forEach(suggestion => {
        const flight = suggestion.data;
        response += `**${flight.airline} ${flight.flightNumber}** - ${flight.departure.city} → ${flight.arrival.city}  
💰 **$${flight.price}** | ⏱️ **${flight.duration}** | ⭐ **${flight.rating} stars** | 📝 **${flight.reviews} reviews**  
🛫 **Departure:** ${flight.departure.time} from ${flight.departure.airport}  
🛬 **Arrival:** ${flight.arrival.time} at ${flight.arrival.airport}  
✈️ **Aircraft:** ${flight.aircraft} | 🎒 **Baggage:** ${flight.baggage}  
🎯 **Amenities:** ${flight.amenities.join(', ')}

`;
      });

      response += `### ✈️ Why These Flights Stand Out:
- **Verified passenger reviews** and ratings
- **Comprehensive amenities** for comfort
- **Competitive pricing** with transparent baggage policies
- **Reliable airlines** with excellent safety records

💡 **Booking Tip:** Book directly with airlines for best customer service and flexibility. Would you like me to show more flight options or help with specific preferences?`;
      
      if (flightSuggestions.length > 0) {
        return response;
      }
    }
    
    if (domain === 'medical' && suggestions.length > 0) {
      const medicalSuggestions = suggestions.slice(0, 4);
      let response = `## ${emoji} Medical Services & Facilities Found!

I found excellent medical resources and facilities for your needs:

### Available Services:

`;

      medicalSuggestions.forEach(suggestion => {
        if (suggestion.type === 'medical_facility') {
          const facility = suggestion.data;
          response += `**${facility.name}** - ${facility.type}  
📍 **${facility.distance.toFixed(1)} miles** | ⭐ **${facility.rating} stars** | 📝 **${facility.reviews} reviews**  
💰 **Price Range:** ${facility.priceRange} | ⏰ **Wait Time:** ${facility.waitTime}  
🏥 **Services:** ${facility.services.slice(0, 3).join(', ')}  
📞 **Contact:** ${facility.phone}

`;
        } else if (suggestion.type === 'medication') {
          const medication = suggestion.data;
          response += `**${medication.name}** - ${medication.type}  
🏪 **${medication.pharmacy}** | 💰 **$${medication.price}** | 📍 **${medication.distance.toFixed(1)} miles**  
✅ **${medication.inStock ? 'In Stock' : 'Out of Stock'}** ${medication.genericAvailable ? '• Generic Available' : ''}

`;
        }
      });

      response += `### 🏥 Medical Assistance Features:
- **Real facility data** with verified contact information
- **Price comparisons** and insurance acceptance details
- **Wait time estimates** for better planning
- **Location-based search** for convenient access

⚠️ **Medical Disclaimer:** This information is for reference only. Always consult with qualified healthcare professionals for medical decisions and treatment.`;
      return response;
    }
    
    return `## ${emoji} Great Options Found!

I found some excellent recommendations that match your preferences. These options focus on quality, sustainability, and great customer reviews.

Would you like me to provide more specific details or help you explore other options?`;
  }

  private isComparisonRequest(message: string): boolean {
    const comparisonKeywords = [
      'compare', 'comparison', 'vs', 'versus', 'difference', 'better', 'best', 
      'cheapest', 'most expensive', 'higher rated', 'reviews', 'pricing',
      'which is better', 'what\'s the difference', 'side by side'
    ];
    
    return comparisonKeywords.some(keyword => 
      message.toLowerCase().includes(keyword.toLowerCase())
    );
  }

  async generateComparisonResponse(message: string, context: ChatContext): Promise<AgentResponse> {
    try {
      // Determine comparison domain
      const domain = this.detectComparisonDomain(message);
      
      // Get comparison data based on domain
      let comparisonData = [];
      let comparisonTitle = '';
      
      if (domain === 'food') {
        const { commerceService } = await import('./commerce-service');
        const restaurants = await commerceService.searchRestaurants();
        comparisonData = restaurants.slice(0, 4);
        comparisonTitle = '🍽️ Restaurant Comparison Analysis';
      } else if (domain === 'travel') {
        const { commerceService } = await import('./commerce-service');
        const hotels = await commerceService.searchHotels();
        comparisonData = hotels.slice(0, 4);
        comparisonTitle = '🏨 Hotel Comparison Analysis';
      } else if (domain === 'marketplace') {
        comparisonData = await amazonService.searchProducts('popular items', {});
        comparisonTitle = '🛍️ Product Comparison Analysis';
      }

      // Generate comprehensive comparison
      const comparisonResponse = this.formatComparisonResponse(comparisonData, domain, comparisonTitle);
      
      // Convert to suggestions format
      const suggestions = comparisonData.map((item: any, index: number) => ({
        type: domain === 'food' ? 'restaurant' : domain === 'travel' ? 'hotel' : 'product',
        title: item.name,
        description: this.formatComparisonDescription(item, domain),
        data: item
      }));

      return {
        content: comparisonResponse,
        suggestions: suggestions.slice(0, 4),
        domain: domain as any,
        thinking: `Generated detailed comparison analysis for ${domain} category with pricing, reviews, and feature breakdown.`
      };
      
    } catch (error) {
      console.error('Comparison generation error:', error);
      return {
        content: "I can help you compare options! Please specify what you'd like to compare - restaurants, hotels, or products.",
        suggestions: [],
        domain: 'general'
      };
    }
  }

  private detectComparisonDomain(message: string): string {
    const messageLower = message.toLowerCase();
    
    if (messageLower.includes('restaurant') || messageLower.includes('food') || 
        messageLower.includes('dining') || messageLower.includes('eat')) {
      return 'food';
    } else if (messageLower.includes('hotel') || messageLower.includes('travel') || 
               messageLower.includes('booking') || messageLower.includes('stay')) {
      return 'travel';
    } else if (messageLower.includes('product') || messageLower.includes('buy') || 
               messageLower.includes('price') || messageLower.includes('shop')) {
      return 'marketplace';
    }
    
    return 'food'; // Default to restaurants
  }

  private formatComparisonResponse(data: any[], domain: string, title: string): string {
    if (!data || data.length === 0) {
      return `## ${title}\n\nI don't have enough data to make a meaningful comparison right now. Please try being more specific about what you'd like to compare.`;
    }

    let response = `## ${title}\n\nHere's a detailed comparison to help you make the best choice:\n\n`;
    
    // Add comparison table
    response += `| **Criteria** | **${data[0]?.name || 'Option 1'}** | **${data[1]?.name || 'Option 2'}** | **${data[2]?.name || 'Option 3'}** | **${data[3]?.name || 'Option 4'}** |\n`;
    response += `|--------------|${'-'.repeat(20)}|${'-'.repeat(20)}|${'-'.repeat(20)}|${'-'.repeat(20)}|\n`;
    
    if (domain === 'food') {
      response += `| **Rating** | ${data[0]?.rating || 'N/A'}★ (${data[0]?.reviews || 0} reviews) | ${data[1]?.rating || 'N/A'}★ (${data[1]?.reviews || 0} reviews) | ${data[2]?.rating || 'N/A'}★ (${data[2]?.reviews || 0} reviews) | ${data[3]?.rating || 'N/A'}★ (${data[3]?.reviews || 0} reviews) |\n`;
      response += `| **Cuisine** | ${data[0]?.cuisine || 'Various'} | ${data[1]?.cuisine || 'Various'} | ${data[2]?.cuisine || 'Various'} | ${data[3]?.cuisine || 'Various'} |\n`;
      response += `| **Price Range** | ${data[0]?.priceRange || 'N/A'} | ${data[1]?.priceRange || 'N/A'} | ${data[2]?.priceRange || 'N/A'} | ${data[3]?.priceRange || 'N/A'} |\n`;
      response += `| **Delivery** | ${data[0]?.delivery ? '✅ Available' : '❌ Not Available'} | ${data[1]?.delivery ? '✅ Available' : '❌ Not Available'} | ${data[2]?.delivery ? '✅ Available' : '❌ Not Available'} | ${data[3]?.delivery ? '✅ Available' : '❌ Not Available'} |\n`;
    } else if (domain === 'travel') {
      response += `| **Rating** | ${data[0]?.rating || 'N/A'}★ (${data[0]?.reviews || 0} reviews) | ${data[1]?.rating || 'N/A'}★ (${data[1]?.reviews || 0} reviews) | ${data[2]?.rating || 'N/A'}★ (${data[2]?.reviews || 0} reviews) | ${data[3]?.rating || 'N/A'}★ (${data[3]?.reviews || 0} reviews) |\n`;
      response += `| **Price/Night** | $${data[0]?.price || 'N/A'} | $${data[1]?.price || 'N/A'} | $${data[2]?.price || 'N/A'} | $${data[3]?.price || 'N/A'} |\n`;
      response += `| **Location** | ${data[0]?.location || 'N/A'} | ${data[1]?.location || 'N/A'} | ${data[2]?.location || 'N/A'} | ${data[3]?.location || 'N/A'} |\n`;
      response += `| **Pet Friendly** | ${data[0]?.petFriendly ? '✅ Yes' : '❌ No'} | ${data[1]?.petFriendly ? '✅ Yes' : '❌ No'} | ${data[2]?.petFriendly ? '✅ Yes' : '❌ No'} | ${data[3]?.petFriendly ? '✅ Yes' : '❌ No'} |\n`;
    } else {
      response += `| **Rating** | ${data[0]?.rating || 'N/A'}★ (${data[0]?.reviews || 0} reviews) | ${data[1]?.rating || 'N/A'}★ (${data[1]?.reviews || 0} reviews) | ${data[2]?.rating || 'N/A'}★ (${data[2]?.reviews || 0} reviews) | ${data[3]?.rating || 'N/A'}★ (${data[3]?.reviews || 0} reviews) |\n`;
      response += `| **Price** | $${data[0]?.price || 'N/A'} | $${data[1]?.price || 'N/A'} | $${data[2]?.price || 'N/A'} | $${data[3]?.price || 'N/A'} |\n`;
      response += `| **Brand** | ${data[0]?.brand || 'N/A'} | ${data[1]?.brand || 'N/A'} | ${data[2]?.brand || 'N/A'} | ${data[3]?.brand || 'N/A'} |\n`;
      response += `| **Sustainable** | ${data[0]?.sustainable ? '✅ Yes' : '❌ No'} | ${data[1]?.sustainable ? '✅ Yes' : '❌ No'} | ${data[2]?.sustainable ? '✅ Yes' : '❌ No'} | ${data[3]?.sustainable ? '✅ Yes' : '❌ No'} |\n`;
    }
    
    response += `\n### 💡 **Comparison Insights**\n\n`;
    
    // Best value analysis
    if (domain === 'food') {
      const bestRated = data.reduce((prev, current) => (prev.rating > current.rating) ? prev : current);
      const bestValue = data.find(item => item.priceRange === '$' || item.priceRange === '$$');
      response += `- **Highest Rated**: ${bestRated.name} (${bestRated.rating}★) - Excellent customer satisfaction\n`;
      response += `- **Best Value**: ${bestValue?.name || data[0].name} - Great quality for the price\n`;
      response += `- **Delivery Options**: ${data.filter(item => item.delivery).length}/${data.length} offer delivery\n`;
    } else if (domain === 'travel') {
      const bestRated = data.reduce((prev, current) => (prev.rating > current.rating) ? prev : current);
      const cheapest = data.reduce((prev, current) => (prev.price < current.price) ? prev : current);
      response += `- **Highest Rated**: ${bestRated.name} (${bestRated.rating}★) - Top customer experience\n`;
      response += `- **Most Affordable**: ${cheapest.name} ($${cheapest.price}/night) - Budget-friendly choice\n`;
      response += `- **Pet-Friendly Options**: ${data.filter(item => item.petFriendly).length}/${data.length} welcome pets\n`;
    } else {
      const bestRated = data.reduce((prev, current) => (prev.rating > current.rating) ? prev : current);
      const cheapest = data.reduce((prev, current) => (prev.price < current.price) ? prev : current);
      response += `- **Highest Rated**: ${bestRated.name} (${bestRated.rating}★) - Best customer reviews\n`;
      response += `- **Most Affordable**: ${cheapest.name} ($${cheapest.price}) - Best price point\n`;
      response += `- **Sustainable Options**: ${data.filter(item => item.sustainable).length}/${data.length} are eco-friendly\n`;
    }
    
    response += `\n**Need more specific comparisons?** Ask me to compare specific features, prices, or locations!`;
    
    return response;
  }

  private formatComparisonDescription(item: any, domain: string): string {
    if (domain === 'food') {
      return `${item.cuisine} • ${item.priceRange} • ${item.rating}★ (${item.reviews} reviews) • ${item.delivery ? 'Delivery Available' : 'Dine-in Only'}`;
    } else if (domain === 'travel') {
      return `${item.location} • $${item.price}/night • ${item.rating}★ (${item.reviews} reviews) • ${item.petFriendly ? 'Pet-Friendly' : 'Standard'}`;
    } else {
      return `${item.brand} • $${item.price} • ${item.rating}★ (${item.reviews} reviews) • ${item.sustainable ? 'Eco-Friendly' : 'Standard'}`;
    }
  }

  async analyzeUserIntent(message: string): Promise<{ domain: string; intent: string; entities: any[] }> {
    try {
      const response = await groq.chat.completions.create({
        model: "llama-3.3-70b-versatile",
        messages: [
          {
            role: "system",
            content: `Analyze the user's message and extract:
1. Domain: food, travel, marketplace, or general
2. Intent: search, book, order, compare, question, etc.
3. Entities: locations, dates, preferences, product types, etc.

Respond with JSON: {"domain": "...", "intent": "...", "entities": [...]}`
          },
          { role: "user", content: message }
        ],
        temperature: 0.3,
      });

      try {
        return JSON.parse(response.choices[0].message.content || '{"domain": "general", "intent": "question", "entities": []}');
      } catch (parseError) {
        return { domain: "general", intent: "question", entities: [] };
      }
    } catch (error) {
      console.error("Intent analysis error:", error);
      return { domain: "general", intent: "question", entities: [] };
    }
  }

  private isPostBookingMessage(message: string): boolean {
    const postBookingIndicators = [
      'back', 'returned', 'booked', 'confirmed', 'next', 'what now',
      'taxi', 'cab', 'transport', 'itinerary', 'restaurant', 'dinner'
    ];
    return postBookingIndicators.some(indicator => 
      message.toLowerCase().includes(indicator)
    ) || message.length < 20; // Short messages likely are post-booking
  }

  async generatePostBookingResponse(message: string, context: ChatContext, booking: any): Promise<AgentResponse> {
    const nextStepSuggestions = [
      {
        type: "action" as const,
        title: "Book Airport Transfer",
        description: `Taxi to ${booking.hotel} - $25-35 estimated`,
        data: { type: "taxi", destination: booking.hotel, price: "25-35" }
      },
      {
        type: "action" as const,
        title: "Create Itinerary",
        description: `Day plan for ${booking.location}`,
        data: { type: "itinerary", location: booking.location }
      },
      {
        type: "restaurant" as const,
        title: "Dinner Reservations",
        description: `Top restaurants near ${booking.hotel}`,
        data: { type: "dining", area: booking.location }
      }
    ];

    const responseContent = `Perfect! I see your booking at **${booking.hotel}** is all confirmed (${booking.confirmationNumber})! 🎉

You're checking in ${booking.checkIn} at ${booking.location}. What would you like to arrange next?

## Next Steps Available:

🚗 **Transportation**: Book a taxi from airport to your hotel ($25-35)
📋 **Itinerary**: Create a personalized day plan for ${booking.location}  
🍽️ **Dining**: Reserve dinner at top restaurants near your hotel

Just let me know what you'd prefer, and I'll get it sorted for you!`;

    return {
      content: responseContent,
      suggestions: nextStepSuggestions,
      domain: "travel"
    };
  }
}

export const groqService = new GroqService();
