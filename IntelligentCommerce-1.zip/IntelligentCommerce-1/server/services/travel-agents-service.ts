import { GoogleGenAI } from "@google/genai";
import { Groq } from "groq-sdk";

interface TravelRequest {
  destination: string;
  dates: string;
  budget: string;
  preferences: string;
}

interface DebateContext {
  request: TravelRequest;
  round: number;
  previousMessages: any[];
}

export class TravelAgentsService {
  private gemini: GoogleGenAI;
  private groq: Groq;
  private fetchAIKey: string;

  constructor() {
    this.gemini = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
    this.groq = new Groq({ apiKey: process.env.GROQ_API_KEY || "" });
    this.fetchAIKey = process.env.FETCH_AI_API_KEY || "";
  }

  async processUserRequest(message: string, userId: number) {
    // Extract travel request details using Gemini
    const travelRequest = await this.extractTravelRequest(message);
    
    // Get initial responses from each agent
    const [flightResponse, travelResponse, budgetResponse] = await Promise.all([
      this.getFlightAgentResponse(travelRequest),
      this.getTravelAgentResponse(travelRequest),
      this.getBudgetAgentResponse(travelRequest)
    ]);

    return {
      travelRequest,
      flightResponse,
      travelResponse,
      budgetResponse
    };
  }

  private async extractTravelRequest(message: string): Promise<TravelRequest> {
    try {
      const response = await this.gemini.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              destination: { type: "string" },
              dates: { type: "string" },
              budget: { type: "string" },
              preferences: { type: "string" }
            },
            required: ["destination", "dates", "budget", "preferences"]
          }
        },
        contents: `Extract travel details from this message: "${message}". 
        Return JSON with destination, dates, budget, and preferences. 
        If any detail is missing, make reasonable assumptions or use "Not specified".`
      });

      return JSON.parse(response.text || '{}');
    } catch (error) {
      console.error('Error extracting travel request:', error);
      return {
        destination: "Not specified",
        dates: "Flexible",
        budget: "Not specified", 
        preferences: "Standard travel preferences"
      };
    }
  }

  private async getFlightAgentResponse(request: TravelRequest): Promise<string> {
    try {
      const prompt = `You are FlightAgent - practical and efficiency-focused. 
      
      User request: ${JSON.stringify(request)}
      
      Respond in markdown format with:
      ## Flight Recommendations
      ### Best Route: [specific route]
      ### Price: $[amount] 
      ### Key Points:
      - [point 1]
      - [point 2]
      
      Keep response under 100 words. Be direct and practical.`;

      const completion = await this.groq.chat.completions.create({
        messages: [{ role: "user", content: prompt }],
        model: "llama-3.3-70b-versatile",
        temperature: 0.7,
        max_tokens: 300
      });

      return completion.choices[0]?.message?.content || "FlightAgent is analyzing flight options...";
    } catch (error) {
      console.error('FlightAgent error:', error);
      return "FlightAgent: I'm having trouble accessing flight data right now, but I'd typically recommend checking direct flights and comparing layover options for the best value.";
    }
  }

  private async getTravelAgentResponse(request: TravelRequest): Promise<string> {
    try {
      const prompt = `You are TravelAgent - experience-focused and quality-oriented.
      
      User request: ${JSON.stringify(request)}
      
      Respond in markdown format with:
      ## Hotel & Experience Recommendations
      ### Accommodation: [hotel name]
      ### Must-Do: [top experience]
      ### Why Quality Matters:
      - [reason 1]
      - [reason 2]
      
      Keep response under 100 words. Focus on memorable experiences.`;

      const response = await this.gemini.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt
      });

      return response.text || "TravelAgent is curating the perfect experience for you...";
    } catch (error) {
      console.error('TravelAgent error:', error);
      return "TravelAgent: I'm working on finding the perfect accommodations and experiences for your trip. I always prioritize quality and memorable experiences over just cost savings.";
    }
  }

  private async getBudgetAgentResponse(request: TravelRequest): Promise<string> {
    try {
      // Using Fetch AI API for BudgetAgent
      const response = await fetch('https://api.fetch.ai/v1/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.fetchAIKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: "fetch-ai-agent",
          prompt: `You are BudgetAgent - analytical and money-conscious.
          
          User request: ${JSON.stringify(request)}
          
          Respond in markdown format with:
          ## Cost Analysis
          ### Total Budget: $[amount]
          ### Savings Opportunities:
          - [saving 1]
          - [saving 2]
          ### Best Value: [recommendation]
          
          Keep response under 100 words. Focus on smart spending.`,
          max_tokens: 300,
          temperature: 0.6
        })
      });

      if (!response.ok) {
        throw new Error(`Fetch AI API error: ${response.status}`);
      }

      const data = await response.json();
      return data.choices?.[0]?.text || `## Cost Analysis
### Budget: Analyzing...
### Strategy: Finding best deals
- Comparing package options
- Identifying savings opportunities`;
    } catch (error) {
      console.error('BudgetAgent error:', error);
      return `## Cost Analysis  
### Budget: Processing...
### Strategy: Value optimization
- Analyzing pricing options
- Finding package deals`;
    }
  }

  async generateDebateRound(context: DebateContext): Promise<any> {
    const { request, round } = context;
    
    // Generate debate prompts based on round
    const debates = [];
    
    if (round === 1) {
      // FlightAgent challenges TravelAgent about hotel location vs airport proximity
      const flightDebate = await this.getDebateResponse('flight', 'travel', 
        `FlightAgent challenges TravelAgent: The hotel you recommended might be too far from the airport. Consider the transit time and cost for the user.`, 
        request);
      
      debates.push({
        agentId: 'flight',
        targetAgent: 'travel',
        content: flightDebate
      });

      // TravelAgent responds defending experience quality
      const travelDebate = await this.getDebateResponse('travel', 'flight',
        `TravelAgent responds to FlightAgent: Experience quality matters more than just proximity. The location I chose offers better cultural immersion.`,
        request);
      
      debates.push({
        agentId: 'travel', 
        targetAgent: 'flight',
        content: travelDebate
      });

      // BudgetAgent introduces cost analysis
      const budgetDebate = await this.getDebateResponse('budget', 'both',
        `BudgetAgent interjects: Both of you are missing the bigger picture. Let me show you the total cost implications of each approach.`,
        request);
      
      debates.push({
        agentId: 'budget',
        targetAgent: 'both',
        content: budgetDebate
      });
    }
    
    else if (round === 2) {
      // Second round - more specific disagreements
      const travelDebate = await this.getDebateResponse('travel', 'budget',
        `TravelAgent to BudgetAgent: Your cost-cutting approach compromises the entire travel experience. Some things are worth paying for.`,
        request);
      
      debates.push({
        agentId: 'travel',
        targetAgent: 'budget', 
        content: travelDebate
      });

      const budgetCounter = await this.getDebateResponse('budget', 'travel',
        `BudgetAgent to TravelAgent: I found package deals that maintain quality while saving money. Smart spending doesn't mean cheap experiences.`,
        request);
      
      debates.push({
        agentId: 'budget',
        targetAgent: 'travel',
        content: budgetCounter
      });
    }
    
    else {
      // Final round - seeking consensus
      const consensusDebate = await this.getDebateResponse('flight', 'all',
        `FlightAgent: Let's find middle ground. I can adjust flight timing to work with both the hotel location and budget constraints.`,
        request);
      
      debates.push({
        agentId: 'flight',
        targetAgent: 'all',
        content: consensusDebate
      });
    }

    return { debates };
  }

  private async getDebateResponse(fromAgent: string, toAgent: string, prompt: string, request: TravelRequest): Promise<string> {
    try {
      if (fromAgent === 'flight') {
        const completion = await this.groq.chat.completions.create({
          messages: [{ 
            role: "user", 
            content: `${prompt} 
            
            Context: ${JSON.stringify(request)}
            
            Respond as FlightAgent in markdown format. Keep under 80 words. Be practical and direct.` 
          }],
          model: "llama-3.3-70b-versatile",
          temperature: 0.8,
          max_tokens: 200
        });
        return completion.choices[0]?.message?.content || "FlightAgent is thinking...";
      }
      
      else if (fromAgent === 'travel') {
        const response = await this.gemini.models.generateContent({
          model: "gemini-2.5-flash",
          contents: `${prompt}
          
          Context: ${JSON.stringify(request)}
          
          Respond as TravelAgent in markdown format. Keep under 80 words. Focus on quality experiences.`
        });
        return response.text || "TravelAgent is considering...";
      }
      
      else if (fromAgent === 'budget') {
        // Fallback to Groq if Fetch AI fails in debate
        const completion = await this.groq.chat.completions.create({
          messages: [{ 
            role: "user", 
            content: `${prompt}
            
            Context: ${JSON.stringify(request)}
            
            Respond as BudgetAgent in markdown format. Keep under 80 words. Focus on value and savings.` 
          }],
          model: "llama-3.3-70b-versatile",
          temperature: 0.7,
          max_tokens: 200
        });
        return completion.choices[0]?.message?.content || "BudgetAgent is calculating...";
      }
      
      return "Agent is processing...";
    } catch (error) {
      console.error(`${fromAgent} debate error:`, error);
      return `${fromAgent} is having trouble responding right now...`;
    }
  }

  async generateFinalTripPlan(request: TravelRequest, userId: number) {
    try {
      const destination = this.extractDestination(request.destination || 'Tokyo');
      const prompt = `Generate a comprehensive ${destination} trip plan based on these requirements:
      ${JSON.stringify(request)}
      
      Create a detailed JSON response with:
      - destination: "${destination}"
      - totalCost, duration, season
      - flights: {outbound: {route, time, duration, price}, return: {route, time, duration, price}}
      - hotel: {name, description, location, roomType, checkIn, checkOut, price, amenities[]}
      - itinerary: [{day, theme, activities: [{name, time, description, cost}]}]
      - scenicLocations: [{name, description, bestTime, duration}]
      - transportation: [{type, brand, route, time, price}] (local buses, trains, taxis with actual brand names)
      - mockBills: [{company, type, address, receiptNumber, date, time, items: [{description, amount}], subtotal, tax, total}] (authentic receipts)
      - costBreakdown: {flights, hotel, activities, food}
      
      Make it realistic for ${destination} with actual prices, locations, and authentic local transportation brands.`;

      const response = await this.gemini.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          responseMimeType: "application/json"
        },
        contents: prompt
      });

      const tripPlan = JSON.parse(response.text || '{}');
      return { tripPlan };
    } catch (error) {
      console.error('Error generating trip plan:', error);
      return this.getFallbackTripPlan(destination);
    }
  }

  private extractDestination(input: string): string {
    // Extract destination from travel request - more comprehensive search
    const destinations = [
      'Tokyo', 'Japan', 'Paris', 'France', 'New York', 'London', 'UK', 'England', 
      'Dubai', 'UAE', 'Bangkok', 'Thailand', 'Singapore', 'Barcelona', 'Spain', 
      'Amsterdam', 'Netherlands', 'Rome', 'Italy', 'Berlin', 'Germany', 'Sydney', 
      'Australia', 'Seoul', 'Korea', 'Mumbai', 'India', 'Bali', 'Indonesia',
      'Istanbul', 'Turkey', 'Cairo', 'Egypt', 'Rio', 'Brazil', 'Mexico City',
      'Mexico', 'Vancouver', 'Canada', 'Stockholm', 'Sweden', 'Athens', 'Greece'
    ];
    
    const inputLower = input.toLowerCase();
    const found = destinations.find(dest => inputLower.includes(dest.toLowerCase()));
    
    // Map country names to major cities
    const countryToCityMap: {[key: string]: string} = {
      'japan': 'Tokyo',
      'france': 'Paris', 
      'uk': 'London',
      'england': 'London',
      'uae': 'Dubai',
      'thailand': 'Bangkok',
      'spain': 'Barcelona',
      'netherlands': 'Amsterdam',
      'italy': 'Rome',
      'germany': 'Berlin',
      'australia': 'Sydney',
      'korea': 'Seoul',
      'india': 'Mumbai',
      'indonesia': 'Bali',
      'turkey': 'Istanbul',
      'egypt': 'Cairo',
      'brazil': 'Rio',
      'mexico': 'Mexico City',
      'canada': 'Vancouver',
      'sweden': 'Stockholm',
      'greece': 'Athens'
    };
    
    if (found) {
      return countryToCityMap[found.toLowerCase()] || found;
    }
    
    // Extract any capitalized words that might be destinations
    const words = input.split(/\s+/);
    for (const word of words) {
      const cleanWord = word.replace(/[^a-zA-Z]/g, '');
      if (cleanWord.length > 2 && cleanWord[0] === cleanWord[0].toUpperCase()) {
        return cleanWord;
      }
    }
    
    return 'Tokyo'; // Default fallback only if no destination found
  }

  private getFallbackTripPlan(destination: string) {
    const destinationData = this.getDestinationData(destination);
    return {
      tripPlan: {
        destination,
        totalCost: destinationData.totalCost,
        duration: "5 days",
        season: destinationData.season,
        flights: destinationData.flights,
        hotel: destinationData.hotel,
        itinerary: destinationData.itinerary,
        scenicLocations: destinationData.scenicLocations,
        transportation: destinationData.transportation,
        mockBills: destinationData.mockBills,
        costBreakdown: destinationData.costBreakdown
      }
    };
  }

  private getDestinationData(destination: string) {
    const baseData: {[key: string]: any} = {
      Tokyo: {
        totalCost: "$2,800",
        season: "Spring",
        flights: {
          outbound: { route: "LAX → NRT", time: "11:30 PM - 5:05 AM +1", duration: "11h 35m", price: "$850" },
          return: { route: "NRT → LAX", time: "6:20 PM - 11:50 AM", duration: "9h 30m", price: "$850" }
        },
        hotel: {
          name: "Park Hyatt Tokyo",
          description: "Luxury hotel in Shinjuku with stunning city views",
          location: "Shinjuku, Tokyo",
          roomType: "Deluxe Room with City View",
          checkIn: "March 15, 2025",
          checkOut: "March 20, 2025",
          price: "$400/night",
          amenities: ["Free WiFi", "Fitness Center", "Spa", "City Views", "Fine Dining"]
        },
        transportation: [
          { type: "JR Yamanote Line", brand: "JR East", route: "Shinjuku → Shibuya", time: "6 min", price: "¥160" },
          { type: "Tokyo Metro", brand: "Ginza Line", route: "Asakusa → Ginza", time: "12 min", price: "¥200" },
          { type: "Airport Express", brand: "Skyliner", route: "Narita → Ueno", time: "41 min", price: "¥2,470" }
        ],
        mockBills: [
          {
            company: "Sukiyabashi Jiro",
            type: "Restaurant",
            address: "4-2-15 Ginza, Chuo City, Tokyo",
            receiptNumber: "SJ-20250315-001247",
            date: "March 15, 2025",
            time: "7:30 PM",
            items: [
              { description: "Omakase Sushi Course", amount: "¥30,000" },
              { description: "Sake Pairing", amount: "¥8,000" }
            ],
            subtotal: "¥38,000",
            tax: "¥3,800",
            total: "¥41,800"
          },
          {
            company: "Tokyo Skytree",
            type: "Attraction",
            address: "1-1-2 Oshiage, Sumida City, Tokyo",
            receiptNumber: "TS-20250316-002891",
            date: "March 16, 2025",
            time: "2:15 PM",
            items: [
              { description: "Tokyo Skytree Deck Tour", amount: "¥2,100" },
              { description: "Fast Skytree Entry", amount: "¥1,000" }
            ],
            subtotal: "¥3,100",
            tax: "¥310",
            total: "¥3,410"
          }
        ]
      },
      Paris: {
        totalCost: "$3,200",
        season: "Summer",
        flights: {
          outbound: { route: "JFK → CDG", time: "10:20 PM - 12:15 PM +1", duration: "7h 55m", price: "$950" },
          return: { route: "CDG → JFK", time: "1:30 PM - 4:45 PM", duration: "8h 15m", price: "$950" }
        },
        hotel: {
          name: "Le Bristol Paris",
          description: "Palace hotel on Rue du Faubourg Saint-Honoré",
          location: "8th Arrondissement, Paris",
          roomType: "Superior Room",
          checkIn: "June 20, 2025",
          checkOut: "June 25, 2025",
          price: "€500/night",
          amenities: ["Free WiFi", "Spa", "Michelin Restaurant", "Palace Service"]
        },
        transportation: [
          { type: "Metro Line 1", brand: "RATP", route: "Châtelet → Charles de Gaulle", time: "35 min", price: "€1.90" },
          { type: "RER B", brand: "SNCF", route: "CDG Airport → Châtelet", time: "32 min", price: "€10.30" },
          { type: "Taxi", brand: "G7", route: "Hotel → Eiffel Tower", time: "15 min", price: "€18" }
        ],
        mockBills: [
          {
            company: "Le Jules Verne",
            type: "Restaurant",
            address: "Tour Eiffel, Avenue Gustave Eiffel, Paris",
            receiptNumber: "JV-20250621-004532",
            date: "June 21, 2025",
            time: "8:00 PM",
            items: [
              { description: "Menu Dégustation", amount: "€290" },
              { description: "Wine Pairing", amount: "€120" }
            ],
            subtotal: "€410",
            tax: "€41",
            total: "€451"
          }
        ],
        itinerary: [
          {
            day: 1,
            theme: "Arrival & Traditional Tokyo",
            activities: [
              { name: "Arrival at Narita", time: "5:05 AM", description: "Airport transfer to hotel", cost: "$60" },
              { name: "Senso-ji Temple", time: "2:00 PM", description: "Historic Buddhist temple in Asakusa", cost: "Free" },
              { name: "Traditional Dinner", time: "7:00 PM", description: "Authentic kaiseki experience", cost: "$120" }
            ]
          },
          {
            day: 2,
            theme: "Modern Tokyo & Shopping",
            activities: [
              { name: "Shibuya Crossing", time: "10:00 AM", description: "World's busiest pedestrian crossing", cost: "Free" },
              { name: "Harajuku District", time: "12:00 PM", description: "Youth culture and street fashion", cost: "$50" },
              { name: "Tokyo Skytree", time: "4:00 PM", description: "Panoramic city views", cost: "$25" }
            ]
          }
        ],
        scenicLocations: [
          {
            name: "Mount Fuji View from Lake Kawaguchi",
            description: "Breathtaking views of Japan's iconic mountain with cherry blossoms",
            bestTime: "Early morning",
            duration: "Half day"
          },
          {
            name: "Imperial Palace East Gardens",
            description: "Serene gardens with traditional Japanese landscaping",
            bestTime: "Afternoon",
            duration: "2-3 hours"
          },
          {
            name: "Meiji Shrine Forest",
            description: "Sacred Shinto shrine surrounded by ancient forest",
            bestTime: "Morning",
            duration: "2 hours"
          }
        ],
        costBreakdown: {
          flights: "$1,700",
          hotel: "$800",
          activities: "$200",
          food: "$300"
        }
      },
      Paris: {
        totalCost: "$3,200",
        season: "Summer",
        flights: {
          outbound: { route: "JFK → CDG", time: "10:20 PM - 12:15 PM +1", duration: "7h 55m", price: "$950" },
          return: { route: "CDG → JFK", time: "1:30 PM - 4:45 PM", duration: "8h 15m", price: "$950" }
        },
        hotel: {
          name: "Le Bristol Paris",
          description: "Palace hotel on Rue du Faubourg Saint-Honoré",
          location: "8th Arrondissement, Paris",
          roomType: "Superior Room",
          checkIn: "June 20, 2025",
          checkOut: "June 25, 2025",
          price: "€500/night",
          amenities: ["Free WiFi", "Spa", "Michelin Restaurant", "Palace Service"]
        },
        transportation: [
          { type: "Metro Line 1", brand: "RATP", route: "Châtelet → Charles de Gaulle", time: "35 min", price: "€1.90" },
          { type: "RER B", brand: "SNCF", route: "CDG Airport → Châtelet", time: "32 min", price: "€10.30" },
          { type: "Taxi", brand: "G7", route: "Hotel → Eiffel Tower", time: "15 min", price: "€18" }
        ],
        mockBills: [
          {
            company: "Le Jules Verne",
            type: "Restaurant",
            address: "Tour Eiffel, Avenue Gustave Eiffel, Paris",
            receiptNumber: "JV-20250621-004532",
            date: "June 21, 2025",
            time: "8:00 PM",
            items: [
              { description: "Menu Dégustation", amount: "€290" },
              { description: "Wine Pairing", amount: "€120" }
            ],
            subtotal: "€410",
            tax: "€41",
            total: "€451"
          }
        ],
        itinerary: [
          {
            day: 1,
            theme: "Classic Paris",
            activities: [
              { name: "Eiffel Tower", time: "10:00 AM", description: "Iconic tower with city views", cost: "€25" },
              { name: "Seine River Cruise", time: "2:00 PM", description: "Scenic boat tour", cost: "€18" },
              { name: "Louvre Museum", time: "4:00 PM", description: "World's largest art museum", cost: "€15" }
            ]
          }
        ],
        scenicLocations: [
          {
            name: "Montmartre & Sacré-Cœur",
            description: "Historic hilltop district with stunning basilica",
            bestTime: "Sunset",
            duration: "3 hours"
          }
        ],
        costBreakdown: {
          flights: "$1,900",
          hotel: "$1,000",
          activities: "$200",
          food: "$100"
        }
      },
      Bali: {
        totalCost: "$1,800",
        season: "Dry Season",
        flights: {
          outbound: { route: "LAX → DPS", time: "11:45 PM - 5:30 AM +2", duration: "17h 45m", price: "$650" },
          return: { route: "DPS → LAX", time: "8:20 PM - 8:55 PM", duration: "15h 35m", price: "$650" }
        },
        hotel: {
          name: "The Mulia Resort",
          description: "Luxury beachfront resort in Nusa Dua",
          location: "Nusa Dua, Bali",
          roomType: "Ocean View Suite",
          checkIn: "July 10, 2025",
          checkOut: "July 15, 2025",
          price: "IDR 2,500,000/night",
          amenities: ["Private Beach", "Spa", "Infinity Pool", "Butler Service"]
        },
        transportation: [
          { type: "Airport Transfer", brand: "Blue Bird Taxi", route: "DPS → Hotel", time: "45 min", price: "IDR 150,000" },
          { type: "Scooter Rental", brand: "Bali Bike Rental", route: "Daily", time: "Full day", price: "IDR 50,000" },
          { type: "Private Driver", brand: "Bali Driver", route: "Ubud Tour", time: "8 hours", price: "IDR 600,000" }
        ],
        mockBills: [
          {
            company: "Locavore Restaurant",
            type: "Restaurant",
            address: "Jl. Dewisita, Ubud, Bali",
            receiptNumber: "LC-20250711-003421",
            date: "July 11, 2025",
            time: "7:00 PM",
            items: [
              { description: "Tasting Menu", amount: "IDR 850,000" },
              { description: "Wine Pairing", amount: "IDR 450,000" }
            ],
            subtotal: "IDR 1,300,000",
            tax: "IDR 130,000",
            total: "IDR 1,430,000"
          }
        ],
        itinerary: [
          {
            day: 1,
            theme: "Beach & Culture",
            activities: [
              { name: "Uluwatu Temple", time: "10:00 AM", description: "Clifftop temple with sunset views", cost: "IDR 30,000" },
              { name: "Kecak Fire Dance", time: "6:00 PM", description: "Traditional Balinese performance", cost: "IDR 100,000" },
              { name: "Jimbaran Beach Dinner", time: "8:00 PM", description: "Seafood dinner on the beach", cost: "IDR 300,000" }
            ]
          }
        ],
        scenicLocations: [
          {
            name: "Tegallalang Rice Terraces",
            description: "UNESCO World Heritage rice terraces with stunning views",
            bestTime: "Early morning",
            duration: "2-3 hours"
          }
        ],
        costBreakdown: {
          flights: "$1,300",
          hotel: "$400",
          activities: "$100",
          food: "$200"
        }
      }
    };
    
    return baseData[destination] || this.generateGenericDestinationData(destination);
  }

  private generateGenericDestinationData(destination: string) {
    return {
      totalCost: "$2,200",
      season: "Peak Season",
      flights: {
        outbound: { route: `LAX → ${destination}`, time: "10:00 PM - 8:00 AM +1", duration: "12h 00m", price: "$800" },
        return: { route: `${destination} → LAX`, time: "6:00 PM - 10:00 PM", duration: "11h 00m", price: "$800" }
      },
      hotel: {
        name: `Premium Hotel ${destination}`,
        description: `Luxury accommodation in the heart of ${destination}`,
        location: `Central ${destination}`,
        roomType: "Deluxe Room",
        checkIn: "June 15, 2025",
        checkOut: "June 20, 2025",
        price: "$250/night",
        amenities: ["Free WiFi", "Fitness Center", "Restaurant", "City Views"]
      },
      transportation: [
        { type: "Airport Transfer", brand: "Local Taxi", route: `Airport → Hotel`, time: "30 min", price: "$40" },
        { type: "City Metro", brand: "Public Transport", route: "City Center", time: "Variable", price: "$3" }
      ],
      mockBills: [
        {
          company: `${destination} Fine Dining`,
          type: "Restaurant",
          address: `Main Street, ${destination}`,
          receiptNumber: `${destination.substring(0,2).toUpperCase()}-20250616-001234`,
          date: "June 16, 2025",
          time: "7:30 PM",
          items: [
            { description: "Chef's Special", amount: "$45" },
            { description: "Local Wine", amount: "$25" }
          ],
          subtotal: "$70",
          tax: "$7",
          total: "$77"
        }
      ],
      itinerary: [
        {
          day: 1,
          theme: `Discover ${destination}`,
          activities: [
            { name: `${destination} City Tour`, time: "10:00 AM", description: "Explore the main attractions", cost: "$30" },
            { name: "Local Museum", time: "2:00 PM", description: "Learn about local culture", cost: "$15" },
            { name: "Traditional Dinner", time: "7:00 PM", description: "Authentic local cuisine", cost: "$50" }
          ]
        }
      ],
      scenicLocations: [
        {
          name: `${destination} Viewpoint`,
          description: `Panoramic views of ${destination} city`,
          bestTime: "Sunset",
          duration: "1-2 hours"
        }
      ],
      costBreakdown: {
        flights: "$1,600",
        hotel: "$500",
        activities: "$100",
        food: "$200"
      }
    };
  }
}

export const travelAgentsService = new TravelAgentsService();