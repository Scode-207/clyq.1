import { GoogleGenAI } from "@google/genai";

export class GeminiConversationalService {
  private ai: GoogleGenAI;

  constructor() {
    const apiKey = process.env.GOOGLE_AI_API_KEY || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GOOGLE_AI_API_KEY is required for conversational responses");
    }
    this.ai = new GoogleGenAI({ apiKey });
  }

  async generateConversationalResponse(
    userMessage: string,
    thinking: string,
    context: any,
    shouldShowItems: boolean = false,
    suggestions: any[] = []
  ): Promise<string> {
    try {
      const systemPrompt = this.buildConversationalSystemPrompt(context, shouldShowItems);
      
      const contentToAnalyze = `
User Message: "${userMessage}"
AI Thinking Process: ${thinking}
${shouldShowItems && suggestions.length > 0 ? `Available Suggestions: ${JSON.stringify(suggestions.slice(0, 3))}` : ''}
Context: User preferences include ${JSON.stringify(context.userPreferences)}
`;

      const response = await this.ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          {
            role: "user",
            parts: [{ text: `${systemPrompt}\n\n${contentToAnalyze}` }]
          }
        ],
        config: {
          temperature: 0.7,
          maxOutputTokens: 800
        }
      });

      let content = response.text || "I'm here to help! What would you like to know?";
      
      // Format content in Perplexity style with clean sections
      if (shouldShowItems && suggestions.length > 0) {
        content = this.formatWithSuggestions(content, suggestions.slice(0, 3), context);
      } else {
        content = this.formatConversationalOnly(content);
      }

      return content;
    } catch (error) {
      console.error("Gemini conversational error:", error);
      return this.generateFallbackResponse(userMessage, context);
    }
  }

  private buildConversationalSystemPrompt(context: any, shouldShowItems: boolean): string {
    return `You are an emotionally intelligent AI assistant that specializes in genuine conversations and personalized recommendations.

## Response Style Guidelines:
- Write in a natural, conversational tone like Perplexity AI
- Be empathetic and emotionally aware
- Use clear headings and bullet points for structured information
- NO decorative elements, borders, or emojis in headings
- Keep responses clean and well-organized

## Conversation Behavior:
${shouldShowItems ? 
  `- The user is asking for specific recommendations, so provide structured suggestions
  - Use clear sections like "Why This Works for You" or "Top Recommendations"
  - Include bullet points with bold labels followed by descriptions` :
  `- The user is having a conversation, NOT asking for specific items
  - Focus on emotional support, understanding, and genuine dialogue
  - Ask follow-up questions to understand their needs better
  - Do NOT show products, restaurants, or travel options unless explicitly requested`
}

## User Context:
- Location: ${context.userPreferences?.location || "Not specified"}
- Food preferences: ${JSON.stringify(context.userPreferences?.food || [])}
- Shopping style: ${JSON.stringify(context.userPreferences?.shopping || [])}
- Travel preferences: ${JSON.stringify(context.userPreferences?.travel || [])}

## Response Format:
- Start with a warm, understanding opening line
- Use clear headings when providing structured information
- Bold key terms within descriptions
- End with a thoughtful question or offer for further help
`;
  }

  private formatWithSuggestions(content: string, suggestions: any[], context: any): string {
    const domain = suggestions[0]?.type || 'general';
    let formattedContent = content;

    // Add structured suggestions section if not already present
    if (!content.includes('##') && suggestions.length > 0) {
      const sectionTitle = domain === 'restaurant' ? 'Great Options for You' :
                          domain === 'hotel' ? 'Perfect Stays' :
                          domain === 'product' ? 'Recommended Items' : 'Top Suggestions';
      
      formattedContent += `\n\n## ${sectionTitle}\n\n`;
      
      suggestions.forEach(suggestion => {
        formattedContent += `• **${suggestion.title}**: ${suggestion.description}\n`;
      });
    }

    return formattedContent;
  }

  private formatConversationalOnly(content: string): string {
    // Ensure conversational responses are clean and empathetic
    if (!content.includes('##')) {
      // Add a gentle structure if the content is too plain
      if (content.length > 200) {
        const lines = content.split('\n').filter(line => line.trim());
        if (lines.length > 2) {
          return lines[0] + '\n\n## Here\'s what I think:\n\n' + lines.slice(1).join('\n\n');
        }
      }
    }
    return content;
  }

  private generateFallbackResponse(userMessage: string, context: any): string {
    const isEmotional = this.detectEmotionalContent(userMessage);
    
    if (isEmotional) {
      return `I can sense there's more to what you're feeling. I'm here to listen and help in whatever way I can. 

## How I Can Support You

• **Understanding**: Share more about what's on your mind
• **Practical help**: I can assist with daily tasks that might ease some stress
• **Personalized suggestions**: Based on your preferences, I can offer tailored recommendations

What would be most helpful for you right now?`;
    }

    return `I'm here to help you with whatever you need. Whether it's finding great food, planning a trip, or just having a conversation, I'm listening.

What's on your mind today?`;
  }

  private detectEmotionalContent(message: string): boolean {
    const emotionalKeywords = [
      'stressed', 'tired', 'excited', 'sad', 'happy', 'worried', 'anxious',
      'frustrated', 'overwhelmed', 'bad day', 'good day', 'feeling'
    ];
    
    return emotionalKeywords.some(keyword => 
      message.toLowerCase().includes(keyword)
    );
  }
}

export const geminiConversationalService = new GeminiConversationalService();