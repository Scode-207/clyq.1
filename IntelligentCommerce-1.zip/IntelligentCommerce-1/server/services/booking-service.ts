import { GoogleGenAI } from "@google/genai";

interface BookingMessage {
  id: string;
  message: string;
  timestamp: Date;
}

export class BookingService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
  }

  async generateBookingMessages(hotelName: string, hotelLocation: string): Promise<BookingMessage[]> {
    try {
      const prompt = `Generate realistic, professional booking status messages for a hotel reservation at "${hotelName}" in ${hotelLocation}. 

Create 11 sequential booking steps that sound authentic and show progression from initiation to completion. Each message should be:
- Professional and reassuring
- Specific to hotel booking
- Progressively showing advancement
- Include technical-sounding but realistic steps

Return as JSON array with this format:
[
  {"id": "step1", "message": "Initiating booking process..."},
  {"id": "step2", "message": "Checking room availability for your dates..."},
  ...
]

Make it sound like a real booking system with realistic hotel industry terminology.`;

      const response = await this.ai.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          responseMimeType: "application/json"
        },
        contents: prompt,
      });

      const rawJson = response.text;
      if (rawJson) {
        const messages = JSON.parse(rawJson);
        return messages.map((msg: any, index: number) => ({
          ...msg,
          timestamp: new Date(Date.now() + index * 1000)
        }));
      }

      // Fallback to default messages if AI fails
      return this.getDefaultBookingMessages();
    } catch (error) {
      console.error("Error generating booking messages:", error);
      return this.getDefaultBookingMessages();
    }
  }

  private getDefaultBookingMessages(): BookingMessage[] {
    return [
      { id: "init", message: "Initiating booking process...", timestamp: new Date() },
      { id: "check", message: "Checking available rooms for your dates...", timestamp: new Date() },
      { id: "pricing", message: "Verifying pricing and availability...", timestamp: new Date() },
      { id: "contact", message: "Contacting hotel reservation system...", timestamp: new Date() },
      { id: "budget", message: "Finding budget-accurate costs...", timestamp: new Date() },
      { id: "secure", message: "Securing your preferred room type...", timestamp: new Date() },
      { id: "payment", message: "Processing payment authorization...", timestamp: new Date() },
      { id: "finalize", message: "Finalizing reservation details...", timestamp: new Date() },
      { id: "confirm", message: "Generating confirmation number...", timestamp: new Date() },
      { id: "email", message: "Sending confirmation email...", timestamp: new Date() },
      { id: "complete", message: "Booking complete!", timestamp: new Date() }
    ];
  }

  generateConfirmationData(hotelName: string, basePrice: number) {
    return {
      confirmationNumber: `HTL${Math.random().toString(36).substr(2, 8).toUpperCase()}`,
      checkIn: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString(),
      checkOut: new Date(Date.now() + 9 * 24 * 60 * 60 * 1000).toLocaleDateString(),
      roomType: "Deluxe King Room",
      guests: 2,
      totalPrice: basePrice * 2,
      bookingDate: new Date().toLocaleDateString(),
      hotelName
    };
  }
}

export const bookingService = new BookingService();