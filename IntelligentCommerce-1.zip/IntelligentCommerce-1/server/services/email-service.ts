import { Resend } from 'resend';

// Initialize Resend only if API key is available
let resend: Resend | null = null;

if (process.env.RESEND_API_KEY) {
  resend = new Resend(process.env.RESEND_API_KEY);
} else {
  console.warn('RESEND_API_KEY environment variable not set. Email functionality will be disabled.');
}

interface BookingEmailData {
  customerName: string;
  customerEmail: string;
  hotelName: string;
  location: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  roomType: string;
  totalAmount: number;
  bookingId: string;
  confirmationNumber: string;
}

interface RestaurantEmailData {
  customerName: string;
  customerEmail: string;
  restaurantName: string;
  orderItems: Array<{
    name: string;
    quantity: number;
    price: number;
  }>;
  totalAmount: number;
  deliveryAddress: string;
  estimatedDelivery: string;
  orderId: string;
}

export class EmailService {
  async sendHotelBookingConfirmation(bookingData: BookingEmailData): Promise<boolean> {
    if (!resend) {
      console.warn('Email service unavailable - RESEND_API_KEY not configured. Hotel booking confirmation would be sent to:', bookingData.customerEmail);
      return true; // Return true to prevent blocking the booking flow
    }

    try {
      const { data, error } = await resend.emails.send({
        from: 'CLYQ Commerce <onboarding@resend.dev>',
        to: [bookingData.customerEmail],
        subject: `Hotel Booking Confirmed - ${bookingData.hotelName}`,
        html: this.generateHotelBookingHTML(bookingData),
      });

      if (error) {
        console.error('Email sending error:', error);
        return false;
      }

      console.log('Hotel booking email sent successfully:', data);
      return true;
    } catch (error) {
      console.error('Failed to send hotel booking email:', error);
      return false;
    }
  }

  async sendRestaurantOrderConfirmation(orderData: RestaurantEmailData): Promise<boolean> {
    if (!resend) {
      console.warn('Email service unavailable - RESEND_API_KEY not configured. Restaurant order confirmation would be sent to:', orderData.customerEmail);
      return true; // Return true to prevent blocking the order flow
    }

    try {
      const { data, error } = await resend.emails.send({
        from: 'CLYQ Commerce <onboarding@resend.dev>',
        to: [orderData.customerEmail],
        subject: `Order Confirmed - ${orderData.restaurantName}`,
        html: this.generateRestaurantOrderHTML(orderData),
      });

      if (error) {
        console.error('Email sending error:', error);
        return false;
      }

      console.log('Restaurant order email sent successfully:', data);
      return true;
    } catch (error) {
      console.error('Failed to send restaurant order email:', error);
      return false;
    }
  }

  private generateHotelBookingHTML(data: BookingEmailData): string {
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Booking Confirmation</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f8f9fa; }
        .container { max-width: 600px; margin: 0 auto; background-color: white; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }
        .content { padding: 30px; }
        .booking-details { background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #e9ecef; }
        .total { background-color: #e3f2fd; padding: 15px; border-radius: 8px; margin: 20px 0; font-weight: bold; }
        .footer { background-color: #343a40; color: white; padding: 20px; text-align: center; font-size: 14px; }
        .confirmation-number { background-color: #28a745; color: white; padding: 10px 15px; border-radius: 5px; display: inline-block; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏨 Booking Confirmed!</h1>
            <p>Your reservation at ${data.hotelName} is confirmed</p>
        </div>
        
        <div class="content">
            <h2>Hello ${data.customerName},</h2>
            <p>Great news! Your hotel booking has been confirmed. Here are your reservation details:</p>
            
            <div class="confirmation-number">
                Confirmation #: ${data.confirmationNumber}
            </div>
            
            <div class="booking-details">
                <h3>Hotel Information</h3>
                <div class="detail-row">
                    <span>Hotel:</span>
                    <span><strong>${data.hotelName}</strong></span>
                </div>
                <div class="detail-row">
                    <span>Location:</span>
                    <span>${data.location}</span>
                </div>
                <div class="detail-row">
                    <span>Room Type:</span>
                    <span>${data.roomType}</span>
                </div>
                
                <h3>Stay Details</h3>
                <div class="detail-row">
                    <span>Check-in:</span>
                    <span><strong>${data.checkIn}</strong></span>
                </div>
                <div class="detail-row">
                    <span>Check-out:</span>
                    <span><strong>${data.checkOut}</strong></span>
                </div>
                <div class="detail-row">
                    <span>Number of Nights:</span>
                    <span>${data.nights}</span>
                </div>
            </div>
            
            <div class="total">
                <div class="detail-row" style="border: none; margin: 0;">
                    <span>Total Amount:</span>
                    <span style="font-size: 1.2em;">$${data.totalAmount.toFixed(2)}</span>
                </div>
            </div>
            
            <p><strong>Booking ID:</strong> ${data.bookingId}</p>
            
            <p>We're excited to host you! If you have any questions, please don't hesitate to contact us.</p>
        </div>
        
        <div class="footer">
            <p>CLYQ Commerce - Your Intelligent Travel Assistant</p>
            <p>This is an automated confirmation email.</p>
        </div>
    </div>
</body>
</html>`;
  }

  private generateRestaurantOrderHTML(data: RestaurantEmailData): string {
    const itemsHTML = data.orderItems.map(item => 
      `<div class="detail-row">
         <span>${item.name} x${item.quantity}</span>
         <span>$${(item.price * item.quantity).toFixed(2)}</span>
       </div>`
    ).join('');

    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f8f9fa; }
        .container { max-width: 600px; margin: 0 auto; background-color: white; }
        .header { background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%); color: white; padding: 30px; text-align: center; }
        .content { padding: 30px; }
        .order-details { background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #e9ecef; }
        .total { background-color: #e8f5e8; padding: 15px; border-radius: 8px; margin: 20px 0; font-weight: bold; }
        .footer { background-color: #343a40; color: white; padding: 20px; text-align: center; font-size: 14px; }
        .delivery-info { background-color: #fff3cd; padding: 15px; border-radius: 8px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🍽️ Order Confirmed!</h1>
            <p>Your order from ${data.restaurantName} is being prepared</p>
        </div>
        
        <div class="content">
            <h2>Hello ${data.customerName},</h2>
            <p>Thank you for your order! Here are your order details:</p>
            
            <div class="order-details">
                <h3>Order Items</h3>
                ${itemsHTML}
            </div>
            
            <div class="total">
                <div class="detail-row" style="border: none; margin: 0;">
                    <span>Total Amount:</span>
                    <span style="font-size: 1.2em;">$${data.totalAmount.toFixed(2)}</span>
                </div>
            </div>
            
            <div class="delivery-info">
                <h3>Delivery Information</h3>
                <p><strong>Delivery Address:</strong> ${data.deliveryAddress}</p>
                <p><strong>Estimated Delivery:</strong> ${data.estimatedDelivery}</p>
            </div>
            
            <p><strong>Order ID:</strong> ${data.orderId}</p>
            
            <p>Your delicious meal is on its way! Track your order status in the CLYQ app.</p>
        </div>
        
        <div class="footer">
            <p>CLYQ Commerce - Your Intelligent Food Assistant</p>
            <p>This is an automated confirmation email.</p>
        </div>
    </div>
</body>
</html>`;
  }
}

export const emailService = new EmailService();