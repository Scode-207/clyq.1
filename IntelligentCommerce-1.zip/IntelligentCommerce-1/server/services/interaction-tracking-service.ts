import { db } from "../db";
import { userBehavior, userSessions, userPreferences, interactionPatterns, type InsertUserBehavior, type InsertUserSession, type InsertUserPreference, type InsertInteractionPattern } from "@shared/schema";
import { eq, and, desc, sql, count, avg, sum } from "drizzle-orm";

export interface SessionInfo {
  sessionId: string;
  deviceType: string;
  browserInfo: string;
  ipAddress?: string;
  referrer?: string;
}

export interface InteractionData {
  action: string;
  entityType: string;
  entityId: string;
  entityName: string;
  metadata?: any;
  sessionData?: any;
  deviceInfo?: any;
}

export class InteractionTrackingService {
  private activeSessions = new Map<number, string>(); // userId -> sessionId

  async trackInteraction(userId: number, interaction: InteractionData, sessionInfo?: SessionInfo): Promise<void> {
    try {
      // Get or create session
      let sessionId = this.activeSessions.get(userId);
      if (!sessionId && sessionInfo) {
        sessionId = await this.createSession(userId, sessionInfo);
        this.activeSessions.set(userId, sessionId);
      }

      // Record the interaction
      await db.insert(userBehavior).values({
        userId,
        action: interaction.action,
        entityType: interaction.entityType,
        entityId: interaction.entityId,
        entityName: interaction.entityName,
        metadata: interaction.metadata || {},
        sessionData: interaction.sessionData || {},
        deviceInfo: interaction.deviceInfo || {},
      });

      // Update session action count
      if (sessionId) {
        await this.updateSessionActivity(sessionId);
      }

      // Update preferences based on interaction
      await this.updateUserPreferences(userId, interaction);

      // Recalculate interaction patterns periodically
      await this.updateInteractionPatterns(userId);

    } catch (error) {
      console.error('Error tracking interaction:', error);
      // Don't throw - interaction tracking is non-critical
    }
  }

  private async createSession(userId: number, sessionInfo: SessionInfo): Promise<string> {
    const [session] = await db.insert(userSessions).values({
      userId,
      sessionId: sessionInfo.sessionId,
      deviceType: sessionInfo.deviceType,
      browserInfo: sessionInfo.browserInfo,
      ipAddress: sessionInfo.ipAddress,
      referrer: sessionInfo.referrer,
      pageViews: 1,
      actionsCount: 0,
    }).returning();

    return session.sessionId;
  }

  private async updateSessionActivity(sessionId: string): Promise<void> {
    await db.update(userSessions)
      .set({ 
        actionsCount: sql`${userSessions.actionsCount} + 1`,
        endTime: new Date()
      })
      .where(eq(userSessions.sessionId, sessionId));
  }

  private async updateUserPreferences(userId: number, interaction: InteractionData): Promise<void> {
    const metadata = interaction.metadata || {};
    
    // Update category preferences
    if (metadata.category) {
      await this.upsertPreference(userId, 'product_category', metadata.category, 'implicit');
    }

    // Update brand preferences
    if (metadata.brand) {
      await this.upsertPreference(userId, 'brand', metadata.brand, 'implicit');
    }

    // Update price range preferences
    if (metadata.price) {
      const priceRange = this.categorizePrice(metadata.price);
      await this.upsertPreference(userId, 'price_range', priceRange, 'implicit');
    }

    // Update time preferences
    const hour = new Date().getHours();
    const timeCategory = this.categorizeTime(hour);
    await this.upsertPreference(userId, 'time_preference', timeCategory, 'implicit');
  }

  private async upsertPreference(userId: number, category: string, preference: string, source: string): Promise<void> {
    // Check if preference exists
    const existing = await db.select()
      .from(userPreferences)
      .where(and(
        eq(userPreferences.userId, userId),
        eq(userPreferences.category, category),
        eq(userPreferences.preference, preference)
      ))
      .limit(1);

    if (existing.length > 0) {
      // Increase strength
      await db.update(userPreferences)
        .set({ 
          strength: sql`LEAST(${userPreferences.strength} + 0.1, 10.0)`,
          lastUpdated: new Date()
        })
        .where(eq(userPreferences.id, existing[0].id));
    } else {
      // Create new preference
      await db.insert(userPreferences).values({
        userId,
        category,
        preference,
        strength: 1.0,
        source,
      });
    }
  }

  private async updateInteractionPatterns(userId: number): Promise<void> {
    // Calculate category affinity pattern
    const categoryAffinity = await db.select({
      category: userBehavior.metadata,
      count: count()
    })
    .from(userBehavior)
    .where(and(
      eq(userBehavior.userId, userId),
      sql`${userBehavior.timestamp} > NOW() - INTERVAL '30 days'`
    ))
    .groupBy(sql`${userBehavior.metadata}->>'category'`)
    .having(sql`COUNT(*) > 2`);

    if (categoryAffinity.length > 0) {
      await this.upsertInteractionPattern(userId, 'category_affinity', {
        categories: categoryAffinity,
        dominantCategory: categoryAffinity[0]?.category || null
      });
    }

    // Calculate time preference pattern
    const timePatterns = await db.select({
      hour: sql`EXTRACT(HOUR FROM ${userBehavior.timestamp})`,
      count: count()
    })
    .from(userBehavior)
    .where(and(
      eq(userBehavior.userId, userId),
      sql`${userBehavior.timestamp} > NOW() - INTERVAL '30 days'`
    ))
    .groupBy(sql`EXTRACT(HOUR FROM ${userBehavior.timestamp})`);

    if (timePatterns.length > 0) {
      await this.upsertInteractionPattern(userId, 'time_preference', {
        hourlyActivity: timePatterns,
        peakHours: timePatterns.slice(0, 3)
      });
    }

    // Calculate price sensitivity
    const priceInteractions = await db.select({
      avgPrice: avg(sql`CAST(${userBehavior.metadata}->>'price' AS NUMERIC)`),
      priceStdDev: sql`STDDEV(CAST(${userBehavior.metadata}->>'price' AS NUMERIC))`
    })
    .from(userBehavior)
    .where(and(
      eq(userBehavior.userId, userId),
      sql`${userBehavior.metadata}->>'price' IS NOT NULL`,
      sql`${userBehavior.timestamp} > NOW() - INTERVAL '30 days'`
    ));

    if (priceInteractions.length > 0 && priceInteractions[0].avgPrice) {
      await this.upsertInteractionPattern(userId, 'price_sensitivity', {
        averagePrice: priceInteractions[0].avgPrice,
        priceVariability: priceInteractions[0].priceStdDev
      });
    }
  }

  private async upsertInteractionPattern(userId: number, patternType: string, patternData: any): Promise<void> {
    const existing = await db.select()
      .from(interactionPatterns)
      .where(and(
        eq(interactionPatterns.userId, userId),
        eq(interactionPatterns.patternType, patternType)
      ))
      .limit(1);

    const confidence = this.calculatePatternConfidence(patternData, patternType);

    if (existing.length > 0) {
      await db.update(interactionPatterns)
        .set({
          patternData,
          confidence,
          lastCalculated: new Date()
        })
        .where(eq(interactionPatterns.id, existing[0].id));
    } else {
      await db.insert(interactionPatterns).values({
        userId,
        patternType,
        patternData,
        confidence,
      });
    }
  }

  private calculatePatternConfidence(patternData: any, patternType: string): number {
    // Calculate confidence based on data quality and quantity
    switch (patternType) {
      case 'category_affinity':
        const totalInteractions = patternData.categories?.reduce((sum: number, cat: any) => sum + cat.count, 0) || 0;
        return Math.min(totalInteractions / 20, 1.0); // Full confidence at 20+ interactions
      
      case 'time_preference':
        const uniqueHours = patternData.hourlyActivity?.length || 0;
        return Math.min(uniqueHours / 12, 1.0); // Full confidence with activity across 12+ hours
      
      case 'price_sensitivity':
        return patternData.priceVariability ? Math.min(1.0, 0.5 + (1 / (patternData.priceVariability + 1))) : 0.5;
      
      default:
        return 0.5;
    }
  }

  private categorizePrice(price: number): string {
    if (price < 50) return 'budget';
    if (price < 200) return 'mid-range';
    if (price < 500) return 'premium';
    return 'luxury';
  }

  private categorizeTime(hour: number): string {
    if (hour < 6) return 'late_night';
    if (hour < 12) return 'morning';
    if (hour < 17) return 'afternoon';
    if (hour < 22) return 'evening';
    return 'night';
  }

  async getUserInsights(userId: number): Promise<{
    preferences: any[];
    patterns: any[];
    recentActivity: any[];
    stats: any;
  }> {
    // Get user preferences
    const preferences = await db.select()
      .from(userPreferences)
      .where(eq(userPreferences.userId, userId))
      .orderBy(desc(userPreferences.strength));

    // Get interaction patterns
    const patterns = await db.select()
      .from(interactionPatterns)
      .where(eq(interactionPatterns.userId, userId))
      .orderBy(desc(interactionPatterns.confidence));

    // Get recent activity
    const recentActivity = await db.select()
      .from(userBehavior)
      .where(eq(userBehavior.userId, userId))
      .orderBy(desc(userBehavior.timestamp))
      .limit(50);

    // Calculate stats
    const stats = await db.select({
      totalInteractions: count(),
      uniqueCategories: sql`COUNT(DISTINCT ${userBehavior.metadata}->>'category')`,
      avgSessionLength: sql`AVG(EXTRACT(EPOCH FROM (${userSessions.endTime} - ${userSessions.startTime})))`,
      totalSessions: sql`COUNT(DISTINCT ${userSessions.id})`
    })
    .from(userBehavior)
    .leftJoin(userSessions, eq(userBehavior.userId, userSessions.userId))
    .where(eq(userBehavior.userId, userId));

    return {
      preferences,
      patterns,
      recentActivity,
      stats: stats[0] || {}
    };
  }

  async endSession(userId: number): Promise<void> {
    const sessionId = this.activeSessions.get(userId);
    if (sessionId) {
      await db.update(userSessions)
        .set({ endTime: new Date() })
        .where(eq(userSessions.sessionId, sessionId));
      
      this.activeSessions.delete(userId);
    }
  }
}

export const interactionTrackingService = new InteractionTrackingService();