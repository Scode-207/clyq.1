import { GoogleGenAI } from "@google/genai";
import * as fs from "fs";

interface PrescriptionAnalysis {
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
    purpose: string;
    sideEffects: string[];
    interactions: string[];
    genericAlternatives: string[];
  }>;
  doctorInfo: {
    name: string;
    specialty: string;
    contact: string;
  };
  patientInfo: {
    name: string;
    dateOfBirth: string;
    allergies: string[];
  };
  analysis: {
    summary: string;
    concerns: string[];
    recommendations: string[];
    costSavingTips: string[];
  };
  disclaimer: string;
}

interface MedicalResearch {
  condition: string;
  overview: string;
  symptoms: string[];
  treatments: Array<{
    name: string;
    type: string;
    effectiveness: string;
    sideEffects: string[];
  }>;
  preventiveMeasures: string[];
  whenToSeekHelp: string[];
  sources: string[];
  disclaimer: string;
}

export class GeminiMedicalService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
  }

  async analyzePrescription(imageData: string): Promise<PrescriptionAnalysis> {
    try {
      const prompt = `Analyze this prescription image and extract the following information in JSON format:

1. All medications listed with dosage, frequency, duration, and purpose
2. Doctor information (name, specialty, contact)
3. Patient information (name, DOB, allergies if listed)
4. Provide analysis including:
   - Summary of prescribed medications
   - Potential concerns or drug interactions
   - Recommendations for cost savings
   - Generic alternatives available

Format as JSON with the structure:
{
  "medications": [...],
  "doctorInfo": {...},
  "patientInfo": {...},
  "analysis": {...}
}

IMPORTANT: Add medical disclaimer about consulting healthcare providers.`;

      const response = await this.ai.models.generateContent({
        model: "gemini-2.5-pro",
        contents: [
          {
            inlineData: {
              data: imageData,
              mimeType: "image/jpeg",
            },
          },
          prompt
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              medications: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    name: { type: "string" },
                    dosage: { type: "string" },
                    frequency: { type: "string" },
                    duration: { type: "string" },
                    purpose: { type: "string" },
                    sideEffects: { type: "array", items: { type: "string" } },
                    interactions: { type: "array", items: { type: "string" } },
                    genericAlternatives: { type: "array", items: { type: "string" } }
                  }
                }
              },
              doctorInfo: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  specialty: { type: "string" },
                  contact: { type: "string" }
                }
              },
              patientInfo: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  dateOfBirth: { type: "string" },
                  allergies: { type: "array", items: { type: "string" } }
                }
              },
              analysis: {
                type: "object",
                properties: {
                  summary: { type: "string" },
                  concerns: { type: "array", items: { type: "string" } },
                  recommendations: { type: "array", items: { type: "string" } },
                  costSavingTips: { type: "array", items: { type: "string" } }
                }
              }
            }
          }
        }
      });

      const analysisData = JSON.parse(response.text || "{}");
      
      return {
        ...analysisData,
        disclaimer: "This analysis is for informational purposes only. Always consult with your healthcare provider before making any changes to your medication regimen. This is not a substitute for professional medical advice."
      };

    } catch (error) {
      console.error('Gemini prescription analysis error:', error);
      throw new Error('Failed to analyze prescription. Please ensure the image is clear and try again.');
    }
  }

  async analyzePrescriptionFromFile(filePath: string): Promise<PrescriptionAnalysis> {
    try {
      const imageBytes = fs.readFileSync(filePath);
      const base64Data = imageBytes.toString("base64");
      return await this.analyzePrescription(base64Data);
    } catch (error) {
      console.error('File analysis error:', error);
      throw new Error('Failed to read prescription file. Please ensure the file is a valid image.');
    }
  }

  async researchMedicalCondition(condition: string): Promise<MedicalResearch> {
    try {
      const prompt = `Provide comprehensive medical research information about "${condition}" in JSON format:

1. Overview of the condition
2. Common symptoms
3. Available treatments with effectiveness ratings
4. Preventive measures
5. When to seek immediate medical help
6. Reliable medical sources

Format as JSON and include medical disclaimer.`;

      const response = await this.ai.models.generateContent({
        model: "gemini-2.5-pro",
        contents: [prompt],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              condition: { type: "string" },
              overview: { type: "string" },
              symptoms: { type: "array", items: { type: "string" } },
              treatments: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    name: { type: "string" },
                    type: { type: "string" },
                    effectiveness: { type: "string" },
                    sideEffects: { type: "array", items: { type: "string" } }
                  }
                }
              },
              preventiveMeasures: { type: "array", items: { type: "string" } },
              whenToSeekHelp: { type: "array", items: { type: "string" } },
              sources: { type: "array", items: { type: "string" } }
            }
          }
        }
      });

      const researchData = JSON.parse(response.text || "{}");
      
      return {
        ...researchData,
        disclaimer: "This information is for educational purposes only and should not replace professional medical advice. Always consult with qualified healthcare professionals for medical decisions."
      };

    } catch (error) {
      console.error('Gemini medical research error:', error);
      throw new Error('Failed to research medical condition. Please try again.');
    }
  }

  async compareMedications(medications: string[]): Promise<{
    comparison: Array<{
      name: string;
      genericAvailable: boolean;
      averageCost: string;
      commonSideEffects: string[];
      effectiveness: string;
      alternatives: string[];
    }>;
    recommendations: string[];
    disclaimer: string;
  }> {
    try {
      const prompt = `Compare these medications and provide cost-effective alternatives: ${medications.join(', ')}

Provide JSON with:
1. Comparison of each medication
2. Generic alternatives
3. Cost-saving recommendations
4. Effectiveness ratings`;

      const response = await this.ai.models.generateContent({
        model: "gemini-2.5-pro",
        contents: [prompt],
        config: {
          responseMimeType: "application/json",
        }
      });

      const comparisonData = JSON.parse(response.text || "{}");
      
      return {
        ...comparisonData,
        disclaimer: "Medication comparisons are for informational purposes only. Never change medications without consulting your healthcare provider."
      };

    } catch (error) {
      console.error('Gemini medication comparison error:', error);
      throw new Error('Failed to compare medications. Please try again.');
    }
  }
}

export const geminiMedicalService = new GeminiMedicalService();