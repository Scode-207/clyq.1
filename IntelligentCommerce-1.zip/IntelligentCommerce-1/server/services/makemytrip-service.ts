// MakeMyTrip API integration for travel booking and hotel reservations
import axios from 'axios';

interface MMTHotel {
  id: string;
  name: string;
  location: string;
  city: string;
  price: number;
  rating: number;
  reviews: number;
  petFriendly: boolean;
  amenities: string[];
  description: string;
  imageUrl?: string;
  starRating: number;
  checkInTime?: string;
  checkOutTime?: string;
  address?: string;
  phone?: string;
  coordinates?: { lat: number; lng: number };
}

interface MMTFlight {
  id: string;
  airline: string;
  flightNumber: string;
  departure: {
    airport: string;
    city: string;
    time: string;
    date: string;
  };
  arrival: {
    airport: string;
    city: string;
    time: string;
    date: string;
  };
  price: number;
  duration: string;
  stops: number;
  aircraft: string;
  class: string;
  baggage: string;
  amenities: string[];
  rating: number;
  reviews: number;
}

interface TravelItinerary {
  id: string;
  destination: string;
  duration: string;
  activities: string[];
  hotels: MMTHotel[];
  flights: MMTFlight[];
  totalCost: number;
  sustainability: {
    carbonFootprint: number;
    ecoFriendlyOptions: string[];
  };
}

import { serpService } from './serp-service';

export class MakeMyTripService {
  private baseUrl = 'https://api.makemytrip.com/v1';
  private apiKey = process.env.MAKEMYTRIP_API_KEY;
  private serpService = serpService;
  private bookingApiUrl = 'https://distribution-xml.booking.com/2.9/json';

  async searchHotels(location: string, filters?: {
    checkIn?: string;
    checkOut?: string;
    guests?: number;
    petFriendly?: boolean;
    maxPrice?: number;
    minRating?: number;
    amenities?: string[];
  }): Promise<MMTHotel[]> {
    try {
      // Mock implementation with realistic MakeMyTrip hotel data
      const mockHotels: MMTHotel[] = [
        {
          id: 'mmt-sf-001',
          name: 'The Ritz-Carlton, San Francisco',
          location: 'Nob Hill, San Francisco',
          city: 'San Francisco',
          price: 495,
          rating: 4.8,
          reviews: 3542,
          petFriendly: true,
          starRating: 5,
          amenities: ['Spa', 'Fitness Center', 'Pet Services', 'Concierge', 'Room Service', 'Valet Parking'],
          description: 'Luxury hotel atop Nob Hill with panoramic city views and world-class service. Pet-friendly with dedicated pet services.',
          checkInTime: '3:00 PM',
          checkOutTime: '12:00 PM',
          address: '600 Stockton St, San Francisco, CA 94108',
          phone: '+1 (415) 296-7465',
          coordinates: { lat: 37.7926, lng: -122.4082 }
        },
        {
          id: 'mmt-sf-002',
          name: 'Hotel Zephyr San Francisco',
          location: 'Fisherman\'s Wharf, San Francisco',
          city: 'San Francisco',
          price: 225,
          rating: 4.6,
          reviews: 2871,
          petFriendly: true,
          starRating: 4,
          amenities: ['Nautical Theme', 'Waterfront Location', 'Pet-Friendly', 'Fitness Center', 'Business Center'],
          description: 'Boutique waterfront hotel with nautical charm. No pet fees and close to dog-friendly areas.',
          checkInTime: '3:00 PM',
          checkOutTime: '11:00 AM',
          address: '250 Beach St, San Francisco, CA 94133',
          phone: '+1 (415) 617-6565',
          coordinates: { lat: 37.8077, lng: -122.4177 }
        },
        {
          id: 'mmt-sf-003',
          name: '1 Hotel San Francisco',
          location: 'SOMA, San Francisco',
          city: 'San Francisco',
          price: 385,
          rating: 4.7,
          reviews: 1923,
          petFriendly: true,
          starRating: 4,
          amenities: ['Eco-Friendly', 'Sustainable Design', 'Pet Services', 'Rooftop Bar', 'Local Sourcing'],
          description: 'Eco-luxury hotel with sustainable design and locally-sourced amenities. Carbon-neutral operations.',
          checkInTime: '4:00 PM',
          checkOutTime: '11:00 AM',
          address: '8 Mission St, San Francisco, CA 94105',
          phone: '+1 (415) 555-0198',
          coordinates: { lat: 37.7896, lng: -122.3974 }
        },
        {
          id: 'mmt-sea-001',
          name: 'The Edgewater Hotel Seattle',
          location: 'Elliott Bay, Seattle',
          city: 'Seattle',
          price: 295,
          rating: 4.5,
          reviews: 2156,
          petFriendly: true,
          starRating: 4,
          amenities: ['Waterfront Views', 'Pet-Friendly', 'Pike Place Market Nearby', 'Fitness Center'],
          description: 'Waterfront hotel on Elliott Bay with stunning views and pet-friendly accommodations.',
          checkInTime: '3:00 PM',
          checkOutTime: '12:00 PM',
          address: '2411 Alaskan Way, Seattle, WA 98121',
          phone: '+1 (206) 728-7000',
          coordinates: { lat: 47.6154, lng: -122.3535 }
        }
      ];

      let filteredHotels = mockHotels;

      if (location) {
        const locationLower = location.toLowerCase();
        filteredHotels = filteredHotels.filter(hotel =>
          hotel.location.toLowerCase().includes(locationLower) ||
          hotel.city.toLowerCase().includes(locationLower) ||
          hotel.name.toLowerCase().includes(locationLower)
        );
      }

      if (filters?.petFriendly) {
        filteredHotels = filteredHotels.filter(hotel => hotel.petFriendly);
      }

      if (filters?.maxPrice) {
        filteredHotels = filteredHotels.filter(hotel => hotel.price <= filters.maxPrice!);
      }

      if (filters?.minRating) {
        filteredHotels = filteredHotels.filter(hotel => hotel.rating >= filters.minRating!);
      }

      if (filters?.amenities) {
        filteredHotels = filteredHotels.filter(hotel =>
          filters.amenities!.some(amenity =>
            hotel.amenities.some(hotelAmenity =>
              hotelAmenity.toLowerCase().includes(amenity.toLowerCase())
            )
          )
        );
      }

      return filteredHotels.sort((a, b) => b.rating - a.rating);
    } catch (error) {
      console.error('MakeMyTrip hotel API error:', error);
      return [];
    }
  }

  async searchFlights(from: string, to: string, filters?: {
    departureDate?: string;
    returnDate?: string;
    passengers?: number;
    class?: string;
    maxPrice?: number;
    directOnly?: boolean;
  }): Promise<MMTFlight[]> {
    try {
      // ENHANCED MOCK FLIGHT DATA WITH DETAILED REVIEWS AND AMENITIES
      const mockFlights: MMTFlight[] = [
        {
          id: 'mmt-fl-001',
          airline: 'United Airlines',
          flightNumber: 'UA 1234',
          departure: {
            airport: 'SFO',
            city: 'San Francisco',
            time: '8:30 AM',
            date: '2025-07-15'
          },
          arrival: {
            airport: 'SEA',
            city: 'Seattle',
            time: '11:15 AM',
            date: '2025-07-15'
          },
          price: 245,
          duration: '2h 45m',
          stops: 0,
          aircraft: 'Boeing 737-900',
          class: 'Economy',
          baggage: '1 carry-on, 1 checked bag',
          amenities: ['WiFi', 'In-flight Entertainment', 'Snacks', 'Power Outlets'],
          rating: 4.2,
          reviews: 1843
        },
        {
          id: 'mmt-fl-002',
          airline: 'Alaska Airlines',
          flightNumber: 'AS 567',
          departure: {
            airport: 'SFO',
            city: 'San Francisco',
            time: '2:15 PM',
            date: '2025-07-15'
          },
          arrival: {
            airport: 'SEA',
            city: 'Seattle',
            time: '5:00 PM',
            date: '2025-07-15'
          },
          price: 195,
          duration: '2h 45m',
          stops: 0,
          aircraft: 'Airbus A320',
          class: 'Economy',
          baggage: '1 carry-on, 1 checked bag',
          amenities: ['WiFi', 'Streaming Entertainment', 'Premium Snacks', 'USB Ports'],
          rating: 4.4,
          reviews: 1567
        },
        {
          id: 'mmt-fl-003',
          airline: 'Delta Air Lines',
          flightNumber: 'DL 891',
          departure: {
            airport: 'SFO',
            city: 'San Francisco',
            time: '6:45 PM',
            date: '2025-07-15'
          },
          arrival: {
            airport: 'SEA',
            city: 'Seattle',
            time: '9:25 PM',
            date: '2025-07-15'
          },
          price: 285,
          duration: '2h 40m',
          stops: 0,
          aircraft: 'Boeing 737-800',
          class: 'Economy',
          baggage: '1 carry-on, 1 checked bag',
          amenities: ['WiFi', 'Seat-back TV', 'Free Snacks', 'Delta Studio', 'Power Outlets'],
          rating: 4.5,
          reviews: 2341
        },
        {
          id: 'mmt-fl-004',
          airline: 'Southwest Airlines',
          flightNumber: 'WN 2156',
          departure: {
            airport: 'SFO',
            city: 'San Francisco',
            time: '12:30 PM',
            date: '2025-07-15'
          },
          arrival: {
            airport: 'SEA',
            city: 'Seattle',
            time: '3:10 PM',
            date: '2025-07-15'
          },
          price: 175,
          duration: '2h 40m',
          stops: 0,
          aircraft: 'Boeing 737-700',
          class: 'Economy',
          baggage: '2 free checked bags',
          amenities: ['WiFi', 'Free Live TV', 'Snacks', 'No Change Fees'],
          rating: 4.1,
          reviews: 3241
        }
      ];

      return mockFlights.filter(flight =>
        flight.departure.city.toLowerCase().includes(from.toLowerCase()) &&
        flight.arrival.city.toLowerCase().includes(to.toLowerCase())
      );
    } catch (error) {
      console.error('MakeMyTrip flight API error:', error);
      return [];
    }
  }

  async generatePersonalizedItinerary(
    destination: string,
    userPreferences: any,
    travelHistory: any[]
  ): Promise<TravelItinerary | null> {
    try {
      const hotels = await this.searchHotels(destination, {
        petFriendly: userPreferences?.travelStyle?.includes('pet-friendly'),
        maxPrice: userPreferences?.budget || 500
      });

      // Hyper-personalized itinerary based on user preferences
      const activities = this.getPersonalizedActivities(destination, userPreferences, travelHistory);
      
      const itinerary: TravelItinerary = {
        id: `itinerary-${Date.now()}`,
        destination,
        duration: '3 days',
        activities,
        hotels: hotels.slice(0, 3),
        flights: [],
        totalCost: hotels.slice(0, 1)[0]?.price * 3 || 0,
        sustainability: {
          carbonFootprint: this.calculateCarbonFootprint(destination, activities),
          ecoFriendlyOptions: this.getEcoFriendlyOptions(destination, userPreferences)
        }
      };

      return itinerary;
    } catch (error) {
      console.error('MakeMyTrip itinerary error:', error);
      return null;
    }
  }

  private getPersonalizedActivities(destination: string, preferences: any, history: any[]): string[] {
    const baseActivities = {
      'san francisco': [
        'Golden Gate Bridge Walk',
        'Alcatraz Island Tour',
        'Fisherman\'s Wharf',
        'Lombard Street',
        'Chinatown Exploration'
      ],
      'seattle': [
        'Pike Place Market',
        'Space Needle',
        'Chihuly Garden and Glass',
        'Underground Tour',
        'Olympic Sculpture Park'
      ]
    };

    let activities = baseActivities[destination.toLowerCase()] || [];

    // Personalize based on preferences
    if (preferences?.travelStyle?.includes('sustainable')) {
      activities = activities.filter(activity => 
        !activity.includes('Car') && !activity.includes('Drive')
      );
      activities.push('Public Transit Exploration', 'Walking Food Tour');
    }

    if (preferences?.interests?.includes('food')) {
      activities.push('Local Cuisine Tour', 'Farm-to-Table Restaurant Experience');
    }

    if (preferences?.travelStyle?.includes('pet-friendly')) {
      activities.push('Dog Park Visit', 'Pet-Friendly Beach Walk');
    }

    return activities.slice(0, 8);
  }

  private calculateCarbonFootprint(destination: string, activities: string[]): number {
    // Simple carbon footprint calculation (kg CO2)
    const baseCO2 = 50; // Base travel CO2
    const activityCO2 = activities.length * 5; // 5kg per activity
    return baseCO2 + activityCO2;
  }

  private getEcoFriendlyOptions(destination: string, preferences: any): string[] {
    const options = [
      'Public transportation passes',
      'Carbon offset programs',
      'Eco-certified accommodations',
      'Local organic restaurant recommendations',
      'Walking and cycling tour options'
    ];

    if (preferences?.travelStyle?.includes('sustainable')) {
      options.push('Electric vehicle rentals', 'Zero-waste travel kit');
    }

    return options;
  }

  async getPersonalizedHotelRecommendations(
    userPreferences: any,
    bookingHistory: any[],
    location: string
  ): Promise<MMTHotel[]> {
    try {
      const allHotels = await this.searchHotels(location);
      
      const recommendedHotels = allHotels.filter(hotel => {
        let score = 0;
        
        // Pet-friendly preference
        if (userPreferences?.travelStyle?.includes('pet-friendly') && hotel.petFriendly) {
          score += 3;
        }
        
        // Sustainable travel preference
        if (userPreferences?.travelStyle?.includes('sustainable')) {
          const ecoAmenities = hotel.amenities.filter(amenity =>
            amenity.toLowerCase().includes('eco') ||
            amenity.toLowerCase().includes('sustainable') ||
            amenity.toLowerCase().includes('green')
          );
          score += ecoAmenities.length;
        }
        
        // Budget preferences
        if (userPreferences?.budget && hotel.price <= userPreferences.budget) {
          score += 2;
        }
        
        // Previous booking patterns
        const similarBookings = bookingHistory.filter(booking =>
          booking.starRating === hotel.starRating ||
          booking.amenities?.some((amenity: string) => hotel.amenities.includes(amenity))
        ).length;
        score += similarBookings;
        
        // High rating preference
        if (hotel.rating >= 4.5) {
          score += 1;
        }
        
        return score >= 3;
      });

      return recommendedHotels.sort((a, b) => b.rating - a.rating).slice(0, 5);
    } catch (error) {
      console.error('MakeMyTrip personalization error:', error);
      return [];
    }
  }
}

export const makeMyTripService = new MakeMyTripService();