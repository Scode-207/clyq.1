import axios from 'axios';

interface TavilySearchResult {
  title: string;
  url: string;
  content: string;
  score: number;
  published_date?: string;
}

interface TavilyResponse {
  query: string;
  follow_up_questions?: string[];
  answer: string;
  images?: string[];
  results: TavilySearchResult[];
  response_time: number;
}

interface RestaurantInfo {
  name: string;
  address: string;
  rating?: number;
  priceRange?: string;
  cuisine?: string;
  hours?: string;
  phone?: string;
  website?: string;
  description: string;
  features: string[];
  reviews: string[];
}

export class TavilyService {
  private apiKey = process.env.TAVILY_API_KEY;
  private baseUrl = 'https://api.tavily.com';

  async searchRestaurants(query: string, location: string): Promise<{
    restaurants: RestaurantInfo[];
    summary: string;
    followUpQuestions: string[];
  }> {
    if (!this.apiKey) {
      throw new Error('Tavily API key not found');
    }

    try {
      const searchQuery = `${query} restaurants in ${location}`;
      
      const response = await axios.post(`${this.baseUrl}/search`, {
        api_key: this.apiKey,
        query: searchQuery,
        search_depth: "advanced",
        include_answer: true,
        include_domains: [
          "yelp.com",
          "tripadvisor.com",
          "zomato.com",
          "opentable.com",
          "foursquare.com",
          "google.com"
        ],
        max_results: 10
      });

      const data: TavilyResponse = response.data;
      
      // Extract restaurant information from search results
      const restaurants = this.extractRestaurantInfo(data.results);
      
      return {
        restaurants,
        summary: data.answer || `Found ${restaurants.length} restaurants matching "${query}" in ${location}`,
        followUpQuestions: data.follow_up_questions || []
      };
    } catch (error) {
      console.error('Tavily search error:', error);
      throw new Error(`Failed to search restaurants: ${error.message}`);
    }
  }

  async getRestaurantDetails(restaurantName: string, location: string): Promise<RestaurantInfo | null> {
    if (!this.apiKey) {
      throw new Error('Tavily API key not found');
    }

    try {
      const detailQuery = `${restaurantName} ${location} restaurant details hours menu contact`;
      
      const response = await axios.post(`${this.baseUrl}/search`, {
        api_key: this.apiKey,
        query: detailQuery,
        search_depth: "advanced",
        include_answer: true,
        include_domains: [
          "yelp.com",
          "tripadvisor.com",
          "zomato.com",
          "opentable.com",
          "foursquare.com"
        ],
        max_results: 5
      });

      const data: TavilyResponse = response.data;
      const restaurants = this.extractRestaurantInfo(data.results);
      
      return restaurants[0] || null;
    } catch (error) {
      console.error('Tavily restaurant details error:', error);
      return null;
    }
  }

  private extractRestaurantInfo(results: TavilySearchResult[]): RestaurantInfo[] {
    const restaurants: RestaurantInfo[] = [];
    
    for (const result of results) {
      // Extract restaurant information from content
      const restaurant = this.parseRestaurantFromContent(result);
      if (restaurant) {
        restaurants.push(restaurant);
      }
    }
    
    return restaurants.slice(0, 5); // Limit to top 5 results
  }

  private parseRestaurantFromContent(result: TavilySearchResult): RestaurantInfo | null {
    const content = result.content.toLowerCase();
    const title = result.title;
    
    // Skip if not restaurant-related
    if (!content.includes('restaurant') && !content.includes('food') && 
        !content.includes('dining') && !content.includes('menu')) {
      return null;
    }

    // Extract restaurant name from title
    const name = this.extractRestaurantName(title);
    if (!name) return null;

    // Extract rating
    const rating = this.extractRating(result.content);
    
    // Extract price range
    const priceRange = this.extractPriceRange(result.content);
    
    // Extract cuisine type
    const cuisine = this.extractCuisine(result.content);
    
    // Extract address
    const address = this.extractAddress(result.content);
    
    // Extract phone
    const phone = this.extractPhone(result.content);
    
    // Extract hours
    const hours = this.extractHours(result.content);
    
    // Extract features/highlights
    const features = this.extractFeatures(result.content);
    
    // Extract reviews/descriptions
    const reviews = this.extractReviews(result.content);

    return {
      name,
      address: address || 'Address not found',
      rating,
      priceRange,
      cuisine,
      hours,
      phone,
      website: result.url,
      description: result.content.substring(0, 300) + '...',
      features,
      reviews
    };
  }

  private extractRestaurantName(title: string): string | null {
    // Remove common suffixes and clean up title
    const cleaned = title
      .replace(/\s*-\s*(Yelp|TripAdvisor|Zomato|OpenTable).*$/i, '')
      .replace(/\s*\|\s*.*$/, '')
      .trim();
    
    return cleaned.length > 0 ? cleaned : null;
  }

  private extractRating(content: string): number | undefined {
    const ratingMatch = content.match(/(\d+\.?\d*)\s*(star|rating|out of)/i);
    if (ratingMatch) {
      const rating = parseFloat(ratingMatch[1]);
      return rating <= 5 ? rating : undefined;
    }
    return undefined;
  }

  private extractPriceRange(content: string): string | undefined {
    if (content.includes('$$$$') || content.includes('expensive')) return '$$$$';
    if (content.includes('$$$') || content.includes('moderate')) return '$$$';
    if (content.includes('$$') || content.includes('affordable')) return '$$';
    if (content.includes('$') || content.includes('cheap')) return '$';
    return undefined;
  }

  private extractCuisine(content: string): string | undefined {
    const cuisines = [
      'italian', 'chinese', 'indian', 'japanese', 'mexican', 'thai', 'french',
      'american', 'mediterranean', 'vietnamese', 'korean', 'greek', 'spanish',
      'turkish', 'lebanese', 'brazilian', 'peruvian', 'ethiopian', 'moroccan'
    ];
    
    for (const cuisine of cuisines) {
      if (content.toLowerCase().includes(cuisine)) {
        return cuisine.charAt(0).toUpperCase() + cuisine.slice(1);
      }
    }
    return undefined;
  }

  private extractAddress(content: string): string | undefined {
    // Look for address patterns
    const addressMatch = content.match(/\d+\s+[^,\n]+(street|st|avenue|ave|road|rd|drive|dr|boulevard|blvd)[^,\n]*/i);
    return addressMatch ? addressMatch[0].trim() : undefined;
  }

  private extractPhone(content: string): string | undefined {
    const phoneMatch = content.match(/(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
    return phoneMatch ? phoneMatch[0] : undefined;
  }

  private extractHours(content: string): string | undefined {
    const hoursMatch = content.match(/(open|hours?|monday|tuesday|wednesday|thursday|friday|saturday|sunday)[^.!?]*(\d{1,2}:\d{2}|\d{1,2}\s*(am|pm))/i);
    return hoursMatch ? hoursMatch[0].trim() : undefined;
  }

  private extractFeatures(content: string): string[] {
    const features: string[] = [];
    const keywords = [
      'outdoor seating', 'delivery', 'takeout', 'reservations', 'wifi',
      'parking', 'wheelchair accessible', 'pet friendly', 'live music',
      'happy hour', 'brunch', 'vegan options', 'gluten-free'
    ];
    
    for (const keyword of keywords) {
      if (content.toLowerCase().includes(keyword)) {
        features.push(keyword);
      }
    }
    
    return features;
  }

  private extractReviews(content: string): string[] {
    // Extract sentences that look like reviews
    const sentences = content.split(/[.!?]+/);
    const reviews: string[] = [];
    
    for (const sentence of sentences) {
      if (sentence.length > 20 && sentence.length < 200 && 
          (sentence.includes('great') || sentence.includes('good') || 
           sentence.includes('excellent') || sentence.includes('amazing') ||
           sentence.includes('delicious') || sentence.includes('recommend'))) {
        reviews.push(sentence.trim());
      }
    }
    
    return reviews.slice(0, 3); // Limit to 3 reviews
  }
}

export const tavilyService = new TavilyService();