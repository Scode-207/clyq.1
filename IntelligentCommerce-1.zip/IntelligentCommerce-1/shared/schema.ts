import { pgTable, text, serial, integer, boolean, timestamp, json, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  profileComplete: boolean("profile_complete").default(false),
  location: json("location").$type<{
    city: string;
    state: string;
    country: string;
    latitude?: number;
    longitude?: number;
    timezone?: string;
  }>(),
  preferences: json("preferences").$type<{
    // Food preferences
    cuisine?: string[];
    dietary?: string[];
    spicePreference?: "mild" | "medium" | "spicy";
    favoriteMealTimes?: string[];
    
    // Shopping preferences
    budgetRange?: { min: number; max: number };
    sustainabilityImportance?: 1 | 2 | 3 | 4 | 5;
    brandPreferences?: string[];
    shoppingFrequency?: "rarely" | "monthly" | "weekly" | "daily";
    favoriteCategories?: string[];
    
    // Travel preferences
    travelStyle?: string[];
    accommodationType?: string[];
    transportPreference?: string[];
    seasonalPreferences?: string[];
    budgetPreference?: "budget" | "mid-range" | "luxury";
    
    // Notification preferences
    notifications?: {
      email: boolean;
      push: boolean;
      marketing: boolean;
    };
  }>().default({}),
  knowledgeGraph: json("knowledge_graph").$type<{
    nodes: Array<{ id: string; type: string; label: string; data: any }>;
    edges: Array<{ from: string; to: string; type: string; weight: number }>;
    interests?: string[];
    recentSearches?: string[];
    behaviorPatterns?: {
      activeHours?: string[];
      preferredDevices?: string[];
      searchPatterns?: string[];
    };
  }>().default({ nodes: [], edges: [] }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").references(() => conversations.id),
  role: text("role").$type<"user" | "assistant">().notNull(),
  content: text("content").notNull(),
  metadata: json("metadata").$type<{
    type?: "text" | "voice" | "image";
    domain?: "food" | "travel" | "marketplace";
    suggestions?: any[];
    thinking?: string;
  }>().default({}),
  createdAt: timestamp("created_at").defaultNow(),
});

// Knowledge Graph Tables
export const userInterests = pgTable("user_interests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  category: text("category").notNull(), // e.g., "electronics", "fashion", "food"
  subcategory: text("subcategory").notNull(), // e.g., "smartphones", "sneakers", "italian"
  strength: real("strength").notNull().default(1.0), // 0.0 to 10.0 interest strength
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const userBehavior = pgTable("user_behavior", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  action: text("action").notNull(), // "view", "search", "purchase", "analyze", "compare", "click", "chat", "fraud_check", "ai_analyze", "like", "bookmark", "share"
  entityType: text("entity_type").notNull(), // "product", "restaurant", "hotel", "post", "marketplace_item", "conversation", "user"
  entityId: text("entity_id").notNull(),
  entityName: text("entity_name").notNull(),
  metadata: jsonb("metadata").notNull().default('{}'), // Additional context like price, category, etc.
  sessionData: jsonb("session_data").notNull().default('{}'), // Current session context
  deviceInfo: jsonb("device_info").notNull().default('{}'), // Device and browser info
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const userSessions = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  sessionId: text("session_id").notNull().unique(),
  startTime: timestamp("start_time").defaultNow().notNull(),
  endTime: timestamp("end_time"),
  pageViews: integer("page_views").default(0),
  actionsCount: integer("actions_count").default(0),
  deviceType: text("device_type"),
  browserInfo: text("browser_info"),
  ipAddress: text("ip_address"),
  referrer: text("referrer"),
});

export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  category: text("category").notNull(), // 'product_type', 'price_range', 'brand', 'color', 'style', 'time_preference'
  preference: text("preference").notNull(),
  strength: real("strength").default(1.0), // 0.0-10.0 preference strength
  source: text("source").notNull(), // 'explicit', 'implicit', 'inferred'
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const interactionPatterns = pgTable("interaction_patterns", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  patternType: text("pattern_type").notNull(), // 'time_preference', 'category_affinity', 'price_sensitivity', 'brand_loyalty'
  patternData: jsonb("pattern_data").notNull(),
  confidence: real("confidence").notNull(), // 0.0-1.0 confidence score
  lastCalculated: timestamp("last_calculated").defaultNow().notNull(),
});

export const productRelationships = pgTable("product_relationships", {
  id: serial("id").primaryKey(),
  productA: text("product_a").notNull(),
  productB: text("product_b").notNull(),
  relationshipType: text("relationship_type").notNull(), // "similar", "complementary", "alternative", "upgrade"
  strength: real("strength").notNull().default(1.0),
  userCount: integer("user_count").notNull().default(1), // How many users exhibit this relationship
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const knowledgeNodes = pgTable("knowledge_nodes", {
  id: serial("id").primaryKey(),
  nodeId: text("node_id").notNull().unique(),
  nodeType: text("node_type").notNull(), // "user", "product", "category", "brand", "feature"
  label: text("label").notNull(),
  properties: jsonb("properties").notNull().default('{}'),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const knowledgeEdges = pgTable("knowledge_edges", {
  id: serial("id").primaryKey(),
  fromNode: text("from_node").references(() => knowledgeNodes.nodeId, { onDelete: "cascade" }).notNull(),
  toNode: text("to_node").references(() => knowledgeNodes.nodeId, { onDelete: "cascade" }).notNull(),
  edgeType: text("edge_type").notNull(), // "likes", "purchased", "viewed", "similar_to", "belongs_to"
  weight: real("weight").notNull().default(1.0),
  properties: jsonb("properties").notNull().default('{}'),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastStrengthened: timestamp("last_strengthened").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const insertUserInterestSchema = createInsertSchema(userInterests).omit({
  id: true,
  lastUpdated: true,
});

export const insertUserBehaviorSchema = createInsertSchema(userBehavior).omit({
  id: true,
  timestamp: true,
});

export const insertProductRelationshipSchema = createInsertSchema(productRelationships).omit({
  id: true,
  createdAt: true,
});

export const insertKnowledgeNodeSchema = createInsertSchema(knowledgeNodes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertKnowledgeEdgeSchema = createInsertSchema(knowledgeEdges).omit({
  id: true,
  createdAt: true,
  lastStrengthened: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertUserInterest = z.infer<typeof insertUserInterestSchema>;
export type UserInterest = typeof userInterests.$inferSelect;
export type InsertUserBehavior = z.infer<typeof insertUserBehaviorSchema>;
export type UserBehavior = typeof userBehavior.$inferSelect;

export const insertUserSessionSchema = createInsertSchema(userSessions).omit({
  id: true,
});
export const insertUserPreferenceSchema = createInsertSchema(userPreferences).omit({
  id: true,
});
export const insertInteractionPatternSchema = createInsertSchema(interactionPatterns).omit({
  id: true,
});

export type InsertUserSession = z.infer<typeof insertUserSessionSchema>;
export type UserSession = typeof userSessions.$inferSelect;
export type InsertUserPreference = z.infer<typeof insertUserPreferenceSchema>;
export type UserPreference = typeof userPreferences.$inferSelect;
export type InsertInteractionPattern = z.infer<typeof insertInteractionPatternSchema>;
export type InteractionPattern = typeof interactionPatterns.$inferSelect;
export type InsertProductRelationship = z.infer<typeof insertProductRelationshipSchema>;
export type ProductRelationship = typeof productRelationships.$inferSelect;
export type InsertKnowledgeNode = z.infer<typeof insertKnowledgeNodeSchema>;
export type KnowledgeNode = typeof knowledgeNodes.$inferSelect;
export type InsertKnowledgeEdge = z.infer<typeof insertKnowledgeEdgeSchema>;
export type KnowledgeEdge = typeof knowledgeEdges.$inferSelect;
